#! /usr/bin/env python
# Copyright (c) 2024 Arista Networks, Inc.
# Use of this source code is governed by the Apache License 2.0
# that can be found in the COPYING file.
#
# usage: python3 createStudioFile.py
# Ensure the studio files (config.yaml, layout.yaml, schema.yaml, tempate.mako)
# from the studio directory of the package, are in the directory from which
# the script is run.

def createStudioYaml():
    description = 'description: Configure device interfaces and interface profiles\n'
    with open('config.yaml') as configFile:
        for line in configFile:
             if line.strip().startswith('description'):
                  description = line.strip() + '\n'
                  break
    with open('interface-manager-v2.yaml', 'w') as studioFile:
        studioFile.write('- service: arista.studio.v1.StudioConfigService\n')
        studioFile.write('  method: Set\n')
        studioFile.write('  body:\n')
        studioFile.write('    value:\n')
        studioFile.write('      key:\n')
        studioFile.write('        studio_id: studio-interface-manager-v2\n')
        studioFile.write('        workspace_id: ws-interface-manager-v2\n')
        studioFile.write('      display_name: Interface Manager v2 (non-package)\n')
        studioFile.write('      ' + description)
        studioFile.write('      template:\n')
        studioFile.write('        type: TEMPLATE_TYPE_MAKO\n')
        studioFile.write('        body: |+\n')
        with open('template.mako') as templateFile:
            for line in templateFile:
                if line.strip():
                    studioFile.write('          ' + line)
                else:
                    studioFile.write('\n')
        studioFile.write('\n')
        studioFile.write('\n')
        studioFile.write('      input_schema:\n')
        studioFile.write('        fields:\n')
        studioFile.write('          values:\n')
        with open('schema.yaml') as schemaFile:
            for line in schemaFile:
                if line.strip():
                    studioFile.write('            ' + line)
                else:
                    studioFile.write('\n')
        studioFile.write('        layout:\n')
        studioFile.write('          value: |\n')
        with open('layout.yaml') as layoutFile:
            for line in layoutFile:
                if line.strip():
                    studioFile.write('            ' + line)
                else:
                    studioFile.write('\n')

if __name__ == '__main__':
    createStudioYaml()
