# Copyright (c) 2024 Arista Networks, Inc.  All rights reserved.
# Arista Networks, Inc. Confidential and Proprietary.
# Subject to Arista Networks, Inc.'s EULA.
# FOR INTERNAL USE ONLY. NOT FOR DISTRIBUTION.
#
# Date written: Mar 12, 2025
#
# READ THIS BEFORE USING:
# ======================
# PURPOSE:
# This is an Action script for the InterfaceManagerV2 studio package.
# It will autofill the Switch Groups' Port table inputs based on one of
# the following options:
# 1) the running-config of a device where there is a matching profile
# 2) specified count of interfaces of a device group to be applied a profile
# 3) specified interfaces of a device group to be applied a profile
# 4) retaining the existing inputs but aggregating or disaggregating the
#    port table interfaces column
# NOTE: Option 1) is ONLY intended when FIRST starting to use the studio
#       in a brownfield deployment, where there are switches already
#       configured by other means, where the intention is to transition into
#       using the InterfaceManagerV2 studio for configuring interfaces.
#       The option helps populate the Port tables of the studio inputs.
# NOTE: for Option 1) and 2), the script will overwrite all existing entries
#       in the device group Ports table.
#       It may be safer to default the action input "source" to "existing".
# NOTE: the script has not been tested at a scale beyond 200 devices, and not
#       yet been optimized for performance.
# SUPPORTED Profiles:
# It currently supports the following profiles:
#    - access switchports
#    - trunk switchports
#    - that's all for now.  Other cases TBD
# NOTE: profileID, interface, attribute args only used when
#       source is generate.
# NOTE: Profiles without vlans (vlans without profiles) will not be
#       auto-filled in the Ports table.
#       TBD: It's assumed that there is only one Profile using a given
#            Access VLAN ID or Native VLAN ID.
# NOTE: devices without Switch Numbers will not be auto-filled in the
#       Ports table.
# NOTE: There are 3 ways to limit the devices impacted:
#           - at switchGroup: applies to all devices in switchGroup
#           - at Switch Number: applies to specific device in switchGroup
#           - using device Arg: applies to only specified device
#       If the script finishes there will be a green pop-up saying Success.
#       Confirm the ports tables of Switch Group has been filled correctly.
# NOTE: If the studio inputs were filled from running config, the build should
#       not result in config changes, and submitting will not create a
#       change-control.
#       Otherwise submitting the config will create a change-control.
#

import datetime
from itertools import dropwhile
import json
from pprint import pformat
import re
from typing import List, Tuple
import requests

# pylint: disable=import-error
import tagsearch_python.tagsearch_pb2_grpc as tsgr
import tagsearch_python.tagsearch_pb2 as tspb
from arista.tag.v2.tag_pb2 import (
   ELEMENT_TYPE_DEVICE,
   ELEMENT_TYPE_INTERFACE,
)

from cloudvision.cvlib import (
   ActionFailed,
   extractStudioInfoFromArgs,
   InputException,
   InputUpdateException,
   InputRequestException,
   InputNotFoundException,
   # setStudioInputs,   TBD - defined locally until rivers release
   getStudioInputs,
)


LOGLEVEL = 0
# Bug 963624 is only resolved in Rivers release (trunk 7/22/24)
bugResolverAction = False


def log(loglevel=0, logstring=''):
   if loglevel <= LOGLEVEL:
      print(logstring)


def convert(text):
   return int(text) if text.isdigit() else text.lower()


def natural_sort(iterable, sort_key=None):
   if iterable is None:
      return []

   def alphanum_key(key):
      if sort_key is not None and isinstance(key, dict):
         return [convert(c) for c in re.split("([0-9]+)",
                 str(key.get(sort_key, key)))]
      return [convert(c) for c in re.split("([0-9]+)", str(key))]
   return sorted(iterable, key=alphanum_key)


# ===========================================================================
# studio utilities - temporary until customer has new quail release
# ===========================================================================
# pylint: disable=wrong-import-position
# pylint: disable=no-member
# pylint: disable=ungrouped-imports
import google.protobuf.wrappers_pb2 as pb
from arista.studio.v1 import models, services
from fmp import wrappers_pb2 as fmp_wrappers
from grpc import RpcError


def setStudioInputs(clientGetter, studioId: str, workspaceId: str,
                    inputs: List[Tuple]):
   '''
   Uses the passed ctx.getApiClient function reference to issue a
   setSome to the Studio inputs rAPI with the associated InputsConfig.
   The inputs list should contain tuples of a fixed size, either with a
   length of 2 or a length of 3.
   Tuple: (Path, Inputs) or (Path, Inputs, Remove)
   A mixed list [(path, value, remove), (path, value),..] is supported.
   The value doesn't matter if the remove flag is True.
   '''
   client = clientGetter(services.InputsConfigServiceStub)
   wid = pb.StringValue(value=workspaceId)
   sid = pb.StringValue(value=studioId)
   inputsConfigs = []
   for entry in inputs:
      if len(entry) == 2:
         path, value = entry
         key = models.InputsKey(studio_id=sid,
                                workspace_id=wid,
                                path=fmp_wrappers.RepeatedString(
                                    values=path))
         try:
            serialized = json.dumps(value)
         except TypeError as e:
            raise InputException(
                    message=f"Cannot set value as input: {e}",
                    inputPath=path) from None
         item = models.InputsConfig(key=key,
                                    inputs=pb.StringValue(
                                        value=serialized))
      elif len(entry) == 3:
         path, value, remove = entry
         key = models.InputsKey(studio_id=sid,
                                workspace_id=wid,
                                path=fmp_wrappers.RepeatedString(
                                    values=path))
         try:
            serialized = json.dumps(value)
         except TypeError as e:
            raise InputException(
                    message=f"Cannot set value as input: {e}",
                    inputPath=path) from None
         if remove:
            item = models.InputsConfig(key=key,
                                       remove=pb.BoolValue(value=remove))
         else:
            item = models.InputsConfig(key=key,
                                       inputs=pb.StringValue(
                                           value=serialized))
      else:
         raise InputException(
            message=f"Invalid entry length: {len(entry)}",
            inputPath=entry[0]) from None
      inputsConfigs.append(item)
   req = services.InputsConfigSetSomeRequest(
        values=inputsConfigs
   )
   try:
      for _ in client.SetSome(request=req):
         pass
   except RpcError as exc:
      raise InputUpdateException(
         err=f"Inputs {inputs} was not set: {exc}") from None


# ===========================================================================
# tagsearch utilities
# ===========================================================================
def tagSearchQuery(ctx, query: str, wrkID: str,
                   elType: int = ELEMENT_TYPE_DEVICE,
                   userTagsOnly: bool = True):
   '''
   Gets the list of devices or interfaces matching a tag query.
   '''
   devices = []
   interfaces = []
   tsclient = ctx.getApiClient(tsgr.TagSearchStub)
   tagmr = tspb.TagMatchRequestV2(
                      query=query,
                      workspace_id=wrkID,
                      type=elType-1,
                      topology_studio_request=userTagsOnly
                     )
   tagmresp = tsclient.GetTagMatchesV2(tagmr)
   if elType == ELEMENT_TYPE_INTERFACE:
      for match in tagmresp.matches:
         interfaces.append(match.interface.interface_name)
      return interfaces
   for match in tagmresp.matches:
      if device_id := match.device.device_id:
         devices.append(device_id)
   return devices


# ===========================================================================
# running config utilities
# ===========================================================================
def httpGetConfig(path: str):
   '''
   Gets the content at a cvp url.
   '''
   # pylint: disable=undefined-variable
   token = str(ctx.user.token)
   url = "https://" + str(ctx.connections.serviceAddr).split(
      ':', maxsplit=1)[0]
   headers = {
      "Content-Type": "application/json",
      "Accept": "application/json",
      "Authorization": f"Bearer {token}"
   }
   try:
      response = requests.get(url+path, headers=headers, verify=False)
      rawConfig = json.loads(response.text).get('config')
      formattedConfig = rawConfig.replace('\\n', '\n').replace('\\t', '\t')
   except RpcError as error:
      raise ActionFailed(f"\nFailed call to HTTP server: {error}") from error
   return formattedConfig


def getRunningConfig(deviceId: str):
   '''
   Gets the running config of a device.
   '''
   now = datetime.datetime.now().isoformat()
   devPath = (f'/api/rest/config/v1/config/{deviceId}?type'
              f'=CONFIG_TYPE_RUNNING_CONFIG&time='
              f'{now}Z')
   config = httpGetConfig(devPath)
   return config


def getRunningMgmtIps(deviceId: str, runningConfig: str):
   '''
   Gets the management IP addresses from the running config of a device.
   '''
   ipV4 = None
   ipV6 = None
   lines = runningConfig.split('\n')
   for line in lines:
      if line.strip().startswith("interface Management1"):
         for next_line in lines[lines.index(line) + 1:]:
            if "ip address" in next_line:
               ipV4 = next_line.split()[2]
            elif "ipv6 address" in next_line:
               ipV6 = next_line.split()[2]
            else:
               break
   log(1, f"running-config management IPs {deviceId}\n"
          f"ipV4: {ipV4}, ipV6: {ipV6}")
   return ipV4, ipV6


# translate legacy 'speed forced' to 'speed'
legacySpeedXlate = {
   '10000full': '10g',
   '1000full': '1g',
   '100gfull': '100g',
   '25gfull': '25g',
   '40gfull': '40g',
   '50gfull': '50g',
}


def getRunningInterfaces(deviceId: str, runningConfig: str):
   '''
   Gets the switchport vlan interfaces from the running config
   of a device.
   Access vlan interfaces are indexed based on access vlan number.
   Trunk vlan interfaces are indexed based on trunk native vlan number.
   Routed Interfaces are indexed together by 'all'.
   Other port attributes are indexed by shared attribute tuple.
   Note: Parsing relies on port-channels preceding ethernet interfaces
         in the running config.
   Returns:
      accessVlanInterfaces: {
         vlan#: [interface1, interface2, ... ],
      }
      trunkVlanInterfaces: {
         vlan#: [interface1, interface2, ... ],
      }
      routedInterfaces: {
         'all': [interface1, interface2, ... ],
      }
      otherAttrInterfaces: {
         (attr1, attr2,..): [interface1, interface2, ... ],
      }
   '''
   # returned mappings
   accessVlanInterfaces = {}
   trunkVlanInterfaces = {}
   routedInterfaces = {}
   otherAttrInterfaces = {}
   # local mappings
   poAccessVlans = {}
   poTrunkVlans = {}
   poRouted = {}
   # primary attributes
   interface = None
   mode = None
   vlan = 0
   # other attributes
   speed = desc = ipv4 = ipv6 = allowed = None
   poNum = mlagEnabled = lacpEnabled = None

   def updateIntf(interface: str, mode: str, vlan: int, poAttrs: Tuple,
                  attrs: Tuple):
      if not interface or not mode:
         return
      log(2, f"\nupdateIntf: {interface}, {mode}, {vlan}, {poAttrs}, "
             f"attrs - {attrs}")
      if interface.startswith('Port-Channel'):
         (poNum, mlagEnabled,) = poAttrs
      elif interface.startswith('Ethernet') and mode:
         otherAttrInterfaces.setdefault(attrs, []).append(
            interface)
      if mode == 'access' and vlan:
         if interface.startswith('Port-Channel') and poNum:
            poAccessVlans[poNum] = (vlan, mlagEnabled,)
         else:
            accessVlanInterfaces.setdefault(int(vlan), []).append(
               interface)
      elif mode == 'trunk' and vlan:
         if interface.startswith('Port-Channel') and poNum:
            poTrunkVlans[poNum] = (vlan, mlagEnabled,)
         else:
            trunkVlanInterfaces.setdefault(int(vlan), []).append(
               interface)
      elif mode == 'routed':
         if interface.startswith('Port-Channel') and poNum:
            poRouted[poNum] = (True, mlagEnabled,)
         else:
            routedInterfaces.setdefault('all', []).append(
               interface)

   lines = runningConfig.split('\n')
   for line in lines:
      if line.strip().startswith("interface Ethernet"):
         # save/clear attrs for the previous switchport interface
         # (repeated here to handle simdevs which don't have !'s)
         attrs = (speed, desc, ipv4, ipv6, int(vlan), allowed,
                  poNum, mlagEnabled, lacpEnabled,)
         poAttrs = (poNum, mlagEnabled,)
         updateIntf(interface, mode, vlan, poAttrs, attrs)
         mode = speed = desc = ipv4 = ipv6 = allowed = None
         poNum = mlagEnabled = lacpEnabled = None
         # start new interface
         interface = line.strip().split()[1]
         continue
      if line.strip().startswith("interface Port-Channel"):
         # save/clear attrs for the previous switchport interface
         # (repeated here to handle simdevs which don't have !'s)
         attrs = (speed, desc, ipv4, ipv6, int(vlan), allowed,
                  poNum, mlagEnabled, lacpEnabled,)
         poAttrs = (poNum, mlagEnabled,)
         updateIntf(interface, mode, vlan, poAttrs, attrs)
         mode = speed = desc = ipv4 = ipv6 = allowed = None
         poNum = mlagEnabled = lacpEnabled = None
         # start new interface
         interface = line.strip().split()[1]
         poNum = ''.join(dropwhile(lambda x: not x.isdigit(), line.strip()))
         continue
      if not interface:
         # not interface config
         continue
      if line.strip() == '!' or line.strip() == 'end':
         # save/clear attrs for the previous switchport interface
         attrs = (speed, desc, ipv4, ipv6, int(vlan), allowed,
                  poNum, mlagEnabled, lacpEnabled,)
         poAttrs = (poNum, mlagEnabled,)
         updateIntf(interface, mode, vlan, poAttrs, attrs)
         interface = mode = speed = desc = ipv4 = ipv6 = allowed = None
         poNum = mlagEnabled = lacpEnabled = None
      if "mlag" in line.strip():
         mlagEnabled = 'enabled'
      if "speed" in line.strip():
         if "auto" in line.strip():
            speed = 'auto'
         else:
            speed = ''.join(dropwhile(lambda x: not x.isdigit(),
                            line.strip()))
         speed = newSpeed if (
            newSpeed := legacySpeedXlate.get(speed)) else speed
      if "ip address" in line.strip():
         ipv4 = ''.join(dropwhile(lambda x: not x.isdigit(),
                            line.strip()))
      if "ipv6 address" in line.strip():
         ipv6 = ''.join(dropwhile(lambda x: not x.isdigit(),
                            line.strip()))
      if "switchport trunk allowed vlan" in line.strip():
         allowed = ''.join(dropwhile(lambda x: not x.isdigit(),
                            line.strip()))
      if line.strip().startswith("description"):
         _, _, desc = line.strip().partition(' ')
      if "switchport access vlan" in line.strip():
         mode = 'access'
         vlan = re.match('.*?([0-9]+)$', line.strip()).group(1)
      if "switchport trunk native vlan" in line.strip():
         mode = 'trunk'
         vlan = re.match('.*?([0-9]+)$', line.strip()).group(1)
      if "switchport mode trunk" in line.strip():
         mode = 'trunk'
         vlan = 1
      if "no switchport" in line.strip():
         mode = 'routed'
         vlan = 0
      if "channel-group" in line.strip():
         if poNum := re.findall(r'\d+', line.strip()):
            poNum = poNum[0]
            if poAttrs := poAccessVlans.get(poNum):
               (vlan, mlagEnabled,) = poAttrs
               mode = 'access'
            elif poAttrs := poTrunkVlans.get(poNum):
               (vlan, mlagEnabled,) = poAttrs
               mode = 'trunk'
            elif poRouted.get(poNum):
               (_, mlagEnabled,) = poAttrs
               mode = 'routed'
            if "mode" in line.strip():
               if line.strip().split('mode ')[1] == 'active':
                  lacpEnabled = 'enabled'
   log(1, f"running-config vlan interfaces {deviceId}\n"
          f"    accessVlanInterfaces: {accessVlanInterfaces}\n"
          f"    trunkVlanInterfaces: {trunkVlanInterfaces}\n"
          f"    routedInterfaces: {routedInterfaces}\n"
          f"    otherAttrInterfaces: {otherAttrInterfaces}")
   return accessVlanInterfaces, trunkVlanInterfaces, routedInterfaces, otherAttrInterfaces


# ===========================================================================
# set inputs utilities
# ===========================================================================
inputSettings = []


def setInput(path: List, value: str, remove=False):
   """
   Set a value at a path in the studio inputs.
   """
   inputSettings.append((path, value, remove))


def sendInputSettings(stdID: str, wrkID: str, inputs: List[Tuple]):
   """
   Send the input settings to update the studio inputs.
   """
   try:
      # pylint: disable=undefined-variable
      setStudioInputs(ctx.getApiClient, stdID, wrkID, inputs)
   except InputUpdateException as error:
      raise ActionFailed(("\nFailed to update inputs associated with "
                          "switch Ids. "
                          "Please assign them manually.")) from error

# ===========================================================================
# InterfaceV2 Specifics below here.
# ===========================================================================
# pylint: disable=too-many-arguments


class Selection:
   def __init__(self, site: int = None, group: int = None):
      self.site = site
      self.group = group


def getIntfRangeIndexPath(siteIdx, groupIdx, intfRangeIdx):
   return ['sites', str(siteIdx), 'inputs', 'sitesGroup', 'devices',
           str(groupIdx), 'inputs', 'devicesGroup', 'interfaceRanges',
           str(intfRangeIdx)]


def getIntfRangeProfilePath(siteIdx, groupIdx, intfRangeIdx):
   return ['sites', str(siteIdx), 'inputs', 'sitesGroup', 'devices',
           str(groupIdx), 'inputs', 'devicesGroup', 'interfaceRanges',
           str(intfRangeIdx), 'profileOfProfileName']


def getIntfRangeMemberPath(siteIdx, groupIdx, intfRangeIdx):
   return ['sites', str(siteIdx), 'inputs', 'sitesGroup', 'devices',
           str(groupIdx), 'inputs', 'devicesGroup', 'interfaceRanges',
           str(intfRangeIdx), 'memberNumberCollection']


def getIntfRangeIntfsPath(siteIdx, groupIdx, intfRangeIdx):
   return ['sites', str(siteIdx), 'inputs', 'sitesGroup', 'devices',
           str(groupIdx), 'inputs', 'devicesGroup', 'interfaceRanges',
           str(intfRangeIdx), 'interfaceName']


def getIntfRangeSpeedPath(siteIdx, groupIdx, intfRangeIdx):
   return ['sites', str(siteIdx), 'inputs', 'sitesGroup', 'devices',
           str(groupIdx), 'inputs', 'devicesGroup', 'interfaceRanges',
           str(intfRangeIdx), 'speed']


def getIntfRangeDescriptionPath(siteIdx, groupIdx, intfRangeIdx):
   return ['sites', str(siteIdx), 'inputs', 'sitesGroup', 'devices',
           str(groupIdx), 'inputs', 'devicesGroup', 'interfaceRanges',
           str(intfRangeIdx), 'description']


def getIntfRangeIpv4Path(siteIdx, groupIdx, intfRangeIdx):
   return ['sites', str(siteIdx), 'inputs', 'sitesGroup', 'devices',
           str(groupIdx), 'inputs', 'devicesGroup', 'interfaceRanges',
           str(intfRangeIdx), 'ipPrefix']


def getIntfRangeIpv6Path(siteIdx, groupIdx, intfRangeIdx):
   return ['sites', str(siteIdx), 'inputs', 'sitesGroup', 'devices',
           str(groupIdx), 'inputs', 'devicesGroup', 'interfaceRanges',
           str(intfRangeIdx), 'ipv6Prefix']


def getIntfRangeVlanPath(siteIdx, groupIdx, intfRangeIdx):
   return ['sites', str(siteIdx), 'inputs', 'sitesGroup', 'devices',
           str(groupIdx), 'inputs', 'devicesGroup', 'interfaceRanges',
           str(intfRangeIdx), 'accessVlan']


def getIntfRangeAllowedPath(siteIdx, groupIdx, intfRangeIdx):
   return ['sites', str(siteIdx), 'inputs', 'sitesGroup', 'devices',
           str(groupIdx), 'inputs', 'devicesGroup', 'interfaceRanges',
           str(intfRangeIdx), 'vlansAllowed']


def getIntfRangeChannelPath(siteIdx, groupIdx, intfRangeIdx):
   return ['sites', str(siteIdx), 'inputs', 'sitesGroup', 'devices',
           str(groupIdx), 'inputs', 'devicesGroup', 'interfaceRanges',
           str(intfRangeIdx), 'channelGroup']


def getIntfRangeMlagEnabledPath(siteIdx, groupIdx, intfRangeIdx):
   return ['sites', str(siteIdx), 'inputs', 'sitesGroup', 'devices',
           str(groupIdx), 'inputs', 'devicesGroup', 'interfaceRanges',
           str(intfRangeIdx), 'mlagEnabled']


def getIntfRangeLacpEnabledPath(siteIdx, groupIdx, intfRangeIdx):
   return ['sites', str(siteIdx), 'inputs', 'sitesGroup', 'devices',
           str(groupIdx), 'inputs', 'devicesGroup', 'interfaceRanges',
           str(intfRangeIdx), 'lacpEnabled']


def expandIntfs(intf_ranges):
   '''
   Given a comma-separated string of interface ranges,
   expand into a list of interfaces
     eg.
     intf_ranges = 'e1-2, e2/1-2/3, e5/2/1-3'
     result = [
               'Ethernet1', 'Ethernet2',
               'Ethernet2/1', 'Ethernet2/2', 'Ethernet2/3',
               'Ethernet5/2/1', 'Ethernet5/2/2', 'Ethernet5/2/3'
              ]
   '''
   result = []
   intf_ranges = intf_ranges.split(',')
   for intf_range in intf_ranges:
      # just the digits, dashes, and slashes
      intf_range = re.sub(r"[a-zA-Z\s]", "", intf_range)
      if '-' in intf_range:
         start, end = intf_range.split('-')
         if '/' in start:
            prefix, start = start.rsplit('/', 1)  # Get the prefix and start value
         else:
            prefix = ''
         if '/' in end:
            _, end = end.rsplit('/', 1)  # Extract just the end value
         for intf in range(int(start), int(end) + 1):
            result.append(f"Ethernet{prefix}/{intf}" if prefix else f"Ethernet{intf}")
      else:
         result.append(f"Ethernet{intf_range}")
   return result


def getMinAttrs(attrIntfs):
   '''
   Used as a temporary shortcut for customers that want running-config option
   to only populate speed for other-attrs.
   Proper way is to always only populate attributes that are different from the profile
   '''
   attrIntfs2 = {}
   for attrs, intfs in attrIntfs.items():
      # (speed, desc, ipv4, ipv6, vlan, allowed, poNum, mlagEnabled, lacpEnabled,)
      (speed, _, _, _, _, _, _, _, _,) = attrs
      if not speed:
         continue
      attrs2 = (speed, None, None, None, 0, None, None, None, None)
      attrIntfs2[attrs2] = natural_sort(list(set(attrIntfs2.get(attrs2, []) + intfs)))
   return attrIntfs2


def getProfiles(inputs, profileId = None):
   '''
   Get the Vlan to Profile mappings from the studio inputs.
   Access vlans are indexed based on access vlan number
   Trunk vlans are indexed based on trunk native vlan number
   Routed interfaces are only indexed by 'all'
   An index of 0/'all' is a default match all, if there is no
      more specific profile match.
   Inputs:
      inputs: beginning studio inputs
      profileId: optional to assert if a profileId is missing/invalid
   Returns:
      profilesToAccessVlans: {profileName: [vlan,...]}
      accessVlansToProfile:  {vlanId: [profileName,...]}
      profilesToTrunkVlans: {profileName: [vlan,...]}
      trunkVlansToProfile:  {vlanId: [profileName,...]}
      profilesToRouted: {profileName: ['all']}
      routedToProfile:  {'all': [profileName,...]}
   '''
   profilesToAccessVlans = {}
   accessVlansToProfile = {}
   profilesToTrunkVlans = {}
   trunkVlansToProfile = {}
   profilesToRouted = {}
   routedToProfile = {}
   allProfiles = inputs.get('profileOfProfiles')
   vlanProfiles = inputs.get('vlanProfiles')
   if not allProfiles or not vlanProfiles:
      return profilesToAccessVlans, accessVlansToProfile, \
         profilesToTrunkVlans, trunkVlansToProfile, \
         profilesToRouted, routedToProfile
   for profile in allProfiles:
      vlan = None
      if not (profileName := profile.get('profileOfProfilesName')):
         continue
      if not (vlanProfileName := profile.get('vlanProfile')):
         if profileName == profileId:
            raise ActionFailed(
                     f"\nThe profileID {profileId} is invalid: "
                     f"missing General Properties.")
         continue
      vlanProfile = next((profile for profile in vlanProfiles if
                          profile.get('name') == vlanProfileName), None)
      if not vlanProfile:
         raise ActionFailed(
                  f"\nThe profileID {profileId} is invalid: "
                  f"uses an undefined General Properties.")
      mode = vlanProfile.get('mode')
      if not mode:
         mode = 'access'
      if mode == 'access':
         vlan = vlanProfile.get('accessVlanId', 0)
         accessVlansToProfile.setdefault(vlan, []).append(profileName)
         profilesToAccessVlans.setdefault(profileName, []).append(vlan)
         if len(profileNames := accessVlansToProfile.get(vlan)) > 1:
            raise ActionFailed(
                     f"\nTwo profiles {profileNames} for the same vlan {vlan}: "
                     f"The script only supports one profile using each vlan.")
      elif mode == 'trunk':
         vlan = vlanProfile.get('nativeVlanId', 0)
         trunkVlansToProfile.setdefault(vlan, []).append(profileName)
         profilesToTrunkVlans.setdefault(profileName, []).append(vlan)
         if len(profileNames := trunkVlansToProfile.get(vlan)) > 1:
            raise ActionFailed(
                     f"\nTwo profiles {profileNames} for the same vlan {vlan}: "
                     f"The script only supports one profile using each vlan.")
      elif mode == 'routed':
         routedToProfile.setdefault('all', []).append(profileName)
         profilesToRouted.setdefault(profileName, []).append('all')
      else:
         raise ActionFailed(
                  f"\nThe profileID {profileId} is invalid: "
                  f"General Properties {vlanProfileName} "
                  f"has autofill unsupported mode {mode}.")
   return profilesToAccessVlans, accessVlansToProfile, \
      profilesToTrunkVlans, trunkVlansToProfile, \
      profilesToRouted, routedToProfile


def getDevIndices(deviceId, switchGroups):
   '''
   Return if successful, the SiteIdx, GroupIdx, SwitchIdx for a device
   '''
   for siteIdx, siteGroup in switchGroups.items():
      for groupIdx, devicesInfo in siteGroup.items():
         if deviceId in devicesInfo:
            switchIdx = devicesInfo[deviceId].get('switchId')
            if not switchIdx:
               return False, -1, -1, -1
            return True, siteIdx, groupIdx, switchIdx
   return False, -1, -1, -1


def getDevicesFromSwitchGroup(switchGroups, getSiteIdx=None,
   getGroupIdx=None, getStackIdx=None):
   '''
   Return the list of devices from switchGroup
   Inputs:
      getSiteIdx : sites to include
      getGroupIdx: groups to include
   '''
   deviceIds = []
   for siteIdx, siteGroup in switchGroups.items():
      if (getSiteIdx is not None and getSiteIdx != [None]) and (
          siteIdx not in getSiteIdx):
         continue
      for groupIdx, groupDevices in siteGroup.items():
         if (getGroupIdx is not None and getGroupIdx != [None]) and (
             groupIdx not in getGroupIdx):
            continue
         for deviceId, deviceInfo in groupDevices.items():
            if (getStackIdx is not None and getStackIdx != [None]) and (
               deviceInfo.get('stackIdx') not in getStackIdx):
               continue
            deviceIds.append(deviceId)
   return deviceIds


def getSwitchGroups(inputs, sel: Selection = Selection()):
   '''
   Get the SwitchGroups information from the studio inputs.
   Inputs:
      inputs: beginning studio inputs
      sel:    filter (optional)
   Returns:
      switchGroups: {
         siteIndex: {
            groupIndex: {
               deviceId: {
                  'switchId': Id,
                  'access-vlans': {},
                  'trunk-vlans': {},
                  'other-attrs': {},
               }
            }
         }
      }
   '''
   switchGroups = {}
   allSites = inputs.get('sites')
   if not allSites:
      return switchGroups
   for siteIdx, site in enumerate(allSites):
      if not (siteInputs := site.get('inputs')) or not (
              site.get('tags')):
         continue
      if sel.site is not None and siteIdx != sel.site:
         continue
      switchGroups.setdefault(siteIdx, {})
      siteGroups = siteInputs.get('sitesGroup', {}).get('devices')
      for groupIdx, siteGroup in enumerate(siteGroups):
         if not (siteGroupInputs := siteGroup.get('inputs')) or not (
                 siteGroup.get('tags')):
            continue
         if sel.group is not None and groupIdx != sel.group:
            continue
         switchGroups[siteIdx].setdefault(groupIdx, {})
         stackEntries = siteGroupInputs.get('devicesGroup', {}).get('stack')
         if not stackEntries:
            continue
         for stackIdx, stackEntry in enumerate(stackEntries):
            if not (stackEntryQuery := stackEntry.get(
                    'tags', {}).get('query')):
               continue
            if not (swid := stackEntry.get('inputs', {}).get(
                    'stackMember')):
               continue
            devId = stackEntryQuery.split(':')[1]
            switchGroups[siteIdx][groupIdx].setdefault(
               devId,
               {
                  'stackIdx': stackIdx,
                  'switchId': swid,
                  'access-vlans': {},
                  'trunk-vlans': {},
                  'routed-intfs': {},
                  'other-attrs': {},
               })
   return switchGroups


def aggregateIntfs(intfs):
   '''
   Return a string of aggregated ethernet interfaces
   Inputs:
      list of the form: Ethernet1, Ethernet2, Ethernet5/1
   Returns:
      string of the form: "e1,2,5/1"
   '''
   ethList = []
   for intf in intfs:
      if len(intfSplit := intf.split('Ethernet')) > 1:
         ethList.append(intfSplit[1])
   return f"e{','.join(ethList)}" if ethList else ""


def disaggregateIntfs(intfs):
   '''
   Return a list of ethernet names
   Inputs:
      string of the form: "e1,2,5/1"
   Returns:
      list of the form: Ethernet1, Ethernet2, Ethernet5/1
   '''
   if not intfs:
      return []
   ethList = [f"Ethernet{''.join(dropwhile(lambda x: not x.isdigit(), s))}"
              for s in intfs.split(',')]
   return ethList


vlansMissingProfiles = []


def getDeviceModePortRanges(portRanges, swid, vlansInfo, vlansToProfile,
                            attrsInfo, aggregate):
   '''
   Add to the port table for a Device for a Mode.
   Inputs:
      portRanges: {(profileName, intfs, (attrs)): [swId1, swId2, ...]}
      swid: switchId of device
      vlansInfo:
         {
            vlan: [interface1, interface2, ],
         },
      vlansToProfile: {vlanId: [profileName]}
      attrsInfo:
         {
            (attrs): [interface1, interface2, ],
         },
      aggregate: aggregate interfaces sharing same port attributes
   Returns/Updates:
      portRanges: {(profileName, intfs, (attrs)): [swId1, swId2, ...]}
   '''
   for _, (vlan, intfs) in enumerate(vlansInfo.items()):
      if not (profileName := vlansToProfile.get(vlan)) and not (
         profileName := vlansToProfile.get(0)):
         if vlan not in vlansMissingProfiles:
            log(0, f"skipping: vlan {vlan} missing matching profiles")
            vlansMissingProfiles.append(vlan)
         continue
      if not intfs:
         continue
      if aggregate.lower() == 'yes':
         for attrs, intfsA in attrsInfo.items():
            intfsX = list(set(intfs) & set(intfsA))
            if not intfsX:
               continue
            intfsX = natural_sort(intfsX)
            if ethList := aggregateIntfs(intfsX):
               portRanges.setdefault((profileName[0], ethList,
                                      attrs),
                                     []).append(swid)
      else:
         for intf in intfs:
            attrs = None
            for attrs, intfsA in attrsInfo.items():
               if intf in intfsA:
                  break
            if attrs is None:
               log(0, f"skipping: intf {intf} missing attributes")
               continue
            portRanges.setdefault((profileName[0], intf,
                                   attrs),
                                  []).append(swid)
   return portRanges


def getGroupPortRanges(devices, accessVlansToProfile, trunkVlansToProfile,
                       routedToProfile, aggregate='no'):
   '''
   Add to the port table for a SwitchGroup.
   Inputs:
      devices: {
         deviceId: {
            'switchId': Id,
            'access-vlans': {
               vlan: [interface1, interface2, ],
            },
            'trunk-vlans': {
               vlan: [interface1, interface2, ],
            },
            'routed-intfs': {
               'all': [interface1, interface2, ],
            },
         }
      }
      accessVlansToProfile: {vlanId: [profileName]}
      trunkVlansToProfile: {vlanId: [profileName]}
      routedToProfile: {'all': [profileName]}
      aggregate: aggregate interfaces sharing same port attributes
   Returns:
      portRanges: {(profileName, intfs): [swId1, swId2, ...]}
   '''
   portRanges = {}
   for _, (_, deviceInfo) in enumerate(devices.items()):
      if not (swid := deviceInfo.get('switchId')):
         continue
      if vlansInfo := deviceInfo.get('access-vlans'):
         getDeviceModePortRanges(portRanges, swid, vlansInfo,
                                 accessVlansToProfile,
                                 deviceInfo.get('other-attrs'),
                                 aggregate)
      if vlansInfo := deviceInfo.get('trunk-vlans'):
         getDeviceModePortRanges(portRanges, swid, vlansInfo,
                                 trunkVlansToProfile,
                                 deviceInfo.get('other-attrs'),
                                 aggregate)
      if routedInfo := deviceInfo.get('routed-intfs'):
         getDeviceModePortRanges(portRanges, swid, routedInfo,
                                 routedToProfile,
                                 deviceInfo.get('other-attrs'),
                                 aggregate)
   return portRanges


def setGroupPortRanges(siteIdx, groupIdx, portRanges):
   '''
   Set the port table for a SwitchGroup in the studio inputs.
   Inputs:
      siteIdx:    inputs index for a site
      groupIdx:   inputs index for a switch group
      portRanges: {(profileName, intfs, attrs): [swId1, swId2, ...]}
   '''

   def sorting_range_key(item):
      '''
      Sort based on portRanges key tuple intfs member
      - use first intf in intfs
      - handle intf like 1/1/1, eg. 1/1/1 is less than 1/1/2
      '''
      first_intf = item[0][1].split(',')[0]
      numeric_part = ''.join(dropwhile(lambda x: not x.isdigit(),
                                       first_intf))
      intfslices = numeric_part.split('/')
      key = 0.0
      for idx, islice in enumerate(intfslices):
         key += int(islice) / (10 ** (2*idx))
      return key

   for intfRangeIdx, ((profileName, intfs, attrs), swids) in enumerate(
         sorted(portRanges.items(), key=sorting_range_key)):
      path = getIntfRangeProfilePath(siteIdx, groupIdx, intfRangeIdx)
      setInput(path, profileName)
      path = getIntfRangeMemberPath(siteIdx, groupIdx, intfRangeIdx)
      setInput(path, swids)
      path = getIntfRangeIntfsPath(siteIdx, groupIdx, intfRangeIdx)
      setInput(path, intfs)
      (speed, desc, ipv4, ipv6, vlan, allowed, poNum, mlagEnabled, lacpEnabled,) = attrs
      if speed:
         path = getIntfRangeSpeedPath(siteIdx, groupIdx, intfRangeIdx)
         setInput(path, speed)
      if desc:
         path = getIntfRangeDescriptionPath(siteIdx, groupIdx, intfRangeIdx)
         setInput(path, desc)
      if ipv4:
         path = getIntfRangeIpv4Path(siteIdx, groupIdx, intfRangeIdx)
         setInput(path, ipv4)
      if ipv6:
         path = getIntfRangeIpv6Path(siteIdx, groupIdx, intfRangeIdx)
         setInput(path, ipv6)
      if vlan:
         path = getIntfRangeVlanPath(siteIdx, groupIdx, intfRangeIdx)
         setInput(path, str(vlan))
      if allowed:
         path = getIntfRangeAllowedPath(siteIdx, groupIdx, intfRangeIdx)
         setInput(path, allowed)
      if poNum:
         path = getIntfRangeChannelPath(siteIdx, groupIdx, intfRangeIdx)
         setInput(path, poNum)
      if mlagEnabled:
         path = getIntfRangeMlagEnabledPath(siteIdx, groupIdx, intfRangeIdx)
         setInput(path, mlagEnabled)
      if lacpEnabled:
         path = getIntfRangeLacpEnabledPath(siteIdx, groupIdx, intfRangeIdx)
         setInput(path, lacpEnabled)


def getDeviceGroupSwitchIds(groupInfo):
   swidToDev = {}
   for devId, devInfo in groupInfo.items():
      if swid := devInfo.get("switchId"):
         swidToDev[swid] = devId
   return swidToDev


def getExistingPortInterfaces(inputs, switchGroups, siteIdx, groupIdx,
                              profilesToAccessVlans, profilesToTrunkVlans,
                              profilesToRouted, excludeDevs = None):
   '''
   Set the switchport vlans from inputs ports table for a specific
   device group in SwitchGroups.
   Inputs:
      inputs:                 studio inputs
      switchGroups:           missing access-vlans, trunk-vlans, other-attrs
      sitexIdx:               the site to operate on
      groupIdx:               the device group to operate on
      profilesToAccessVlans:  the profile to access-vlan mapping
      profilesToTrunkVlans:   the profile to trunk-vlan mapping
      profilesToRouted:       the profile to routed mapping
   Returns:
      switchGroups: {
         siteIndex: {
            groupIndex: {
               deviceId: {
                  'switchId': Id,
                  'access-vlans': {
                     vlan: [interface1, interface2, ],
                  },
                  'trunk-vlans': {
                     vlan: [interface1, interface2, ],
                  },
                  'routed-intfs': {
                     'all': [interface1, interface2, ],
                  },
                  'other-attrs': {
                     (attr, ...): [interface1, interface2, ],
                  },
               }
            }
         }
      }
   '''
   groupPortTable = inputs.get('sites')[siteIdx].get('inputs').get(
      'sitesGroup').get('devices')[groupIdx].get('inputs').get(
      'devicesGroup').get('interfaceRanges')
   if not groupPortTable:
      return switchGroups
   swidToDev = getDeviceGroupSwitchIds(switchGroups[siteIdx][groupIdx])
   for intfRangeIdx, entry in enumerate(groupPortTable):
      log(2, f"getExisting: {intfRangeIdx}, {entry}")
      profileId = entry.get('profileOfProfileName')
      swids = entry.get('memberNumberCollection')
      speed = entry.get('speed')
      desc = entry.get('description')
      ipv4 = entry.get('ipPrefix')
      ipv6 = entry.get('ipv6Prefix')
      vlan = int(vlan) if ((vlan := entry.get('accessVlan')
                ) and vlan.isdigit()) else 0
      poNum = entry.get('channelGroup')
      allowed = entry.get('vlansAllowed')
      mlagEnabled = entry.get('mlagEnabled')
      lacpEnabled = entry.get('lacpEnabled')
      attrs = (speed, desc, ipv4, ipv6, vlan, allowed, poNum, mlagEnabled, lacpEnabled,)
      intfs = disaggregateIntfs(entry.get('interfaceName'))
      if not swids or not profileId or not intfs:
         continue
      if swids == ['all-switches']:
         swids = list(swidToDev.keys())
      for swid in swids:
         if not (devId := swidToDev[swid]):
            continue
         if excludeDevs and devId in excludeDevs:
            continue
         if vlan := profilesToAccessVlans.get(profileId):
            switchGroups[siteIdx][groupIdx][devId][
               'access-vlans'].setdefault(vlan[0], []).extend(intfs)
         elif vlan := profilesToTrunkVlans.get(profileId):
            switchGroups[siteIdx][groupIdx][devId][
               'trunk-vlans'].setdefault(vlan[0], []).extend(intfs)
         elif vlan := profilesToRouted.get(profileId):
            switchGroups[siteIdx][groupIdx][devId][
               'routed-intfs'].setdefault(vlan[0], []).extend(intfs)
         else:
            raise ActionFailed(f"\nThe profileID {profileId} is invalid: "
                               f"Internal Error 1.")
         switchGroups[siteIdx][groupIdx][devId][
            'other-attrs'].setdefault(attrs, []).extend(intfs)
   return switchGroups


def addSpecificPortInterfaces(switchGroups, deviceId, profileId, mode,
                              profilesToVlans, intf, attrs):
   '''
   Update the switchport vlans using a profile for a specific interface of
   a specific device in the SwitchGroups.
   Leaves other interface assignments as is.
   Inputs:
      switchGroups:    current access-vlans, trunk-vlans, other-attrs
      deviceId:        the device to operate on
      profileId:       the profile to use
      mode:            'access-vlans' or 'trunk-vlans' or 'routed-intfs'
      profilesToVlans: the profile to vlan mapping
      interface:       interface to assign the profile
      attrs:           other interface attributes (eg. speed)
   Returns:
      switchGroups: {
         siteIndex: {
            groupIndex: {
               deviceId: {
                  'switchId': Id,
                  'access-vlans': {
                     vlan: [interface1, interface2, ],
                  },
                  'trunk-vlans': {
                     vlan: [interface1, interface2, ],
                  },
                  'routed-intfs': {
                     'all': [interface1, interface2, ],
                  },
                  'other-attrs': {
                     (attr, ...): [interface1, interface2, ],
                  },
               }
            }
         }
      }
   '''
   ok, siteIdx, groupIdx, switchIdx = getDevIndices(deviceId, switchGroups)
   if not ok:
      raise ActionFailed(f"\nSpecified device {deviceId} "
                         f"is missing switch Id.")
   vlan = 0
   if (vlans := profilesToVlans.get(profileId)):
      vlan = vlans[0]
   log(1, f"addSpecificPortInterfaces: {deviceId} {intf} {profileId} "
          f"{mode} {vlan}")
   log(2, f"device info: {siteIdx} {groupIdx} {switchIdx}")
   # remove any existing profile assignment on interface
   for amode in ['access-vlans', 'trunk-vlans', 'routed-intfs', 'other-attrs']:
      vlansInfo = switchGroups[siteIdx][groupIdx][deviceId][amode]
      for ivlan in list(vlansInfo.keys()):
         if intf in (intfs := vlansInfo.get(ivlan)):
            intfs.remove(intf)
         if not vlansInfo.get(ivlan):
            switchGroups[siteIdx][groupIdx][deviceId][amode].pop(ivlan)
   vlansInfo = switchGroups[siteIdx][groupIdx][deviceId][mode]
   vlansInfo.setdefault(vlan, []).append(intf)
   vlansInfo[vlan] = natural_sort(vlansInfo[vlan])
   attrsInfo = switchGroups[siteIdx][groupIdx][deviceId]['other-attrs']
   attrsInfo.setdefault(attrs, []).append(intf)
   attrsInfo[attrs] = natural_sort(attrsInfo[attrs])
   return switchGroups


def addMultiplePortInterfaces(ctx, switchGroups, deviceId, profileId, mode,
                              profilesToVlans, wrkID, interfaceCount, attrs):
   '''
   Set the switchport vlans using a profile for interfaces of
   a specific device in the SwitchGroups.
   Inputs:
      switchGroups:    missing access-vlans, trunk-vlans, other-attrs
      deviceId:        the device to operate on
      profileId:       the profile to use
      mode:            'access-vlans' or 'trunk-vlans' or 'routed-intfs'
      profilesToVlans: the profile to vlan mapping
      wrkID:           workspaceID
      interfaceCount:  number of interfaces to assign the profile
      attrs:           other interface attributes (eg. speed)
   Returns:
      switchGroups: {
         siteIndex: {
            groupIndex: {
               deviceId: {
                  'switchId': Id,
                  'access-vlans': {
                     vlan: [interface1, interface2, ],
                  },
                  'trunk-vlans': {
                     vlan: [interface1, interface2, ],
                  },
                  'routed-intfs': {
                     'all': [interface1, interface2, ],
                  },
                  'other-attrs': {
                     (attr, ...): [interface1, interface2, ],
                  },
               }
            }
         }
      }
   '''
   log(1, f"addMultiplePortInterfaces: "
          f"{deviceId} {profileId} {interfaceCount} {attrs}")
   ok, siteIdx, groupIdx, switchIdx = getDevIndices(deviceId, switchGroups)
   if not ok:
      raise ActionFailed(f"\nSpecified device {deviceId} "
                         f"is missing switch Id.")
   log(2, f"device info: {siteIdx} {groupIdx} {switchIdx}")
   vlan = 0
   if (vlans := profilesToVlans.get(profileId)):
      vlan = vlans[0]
   interfacesList = []
   for idx, interfaceId in enumerate(tagSearchQuery(
        ctx, f"device:{deviceId}", wrkID, ELEMENT_TYPE_INTERFACE), 1):
      if interfaceCount and idx > interfaceCount:
         break
      if 'Management' in interfaceId:
         continue
      interfacesList.append(interfaceId)
   vlanInterfaces = {}
   vlanInterfaces[vlan] = interfacesList
   switchGroups[siteIdx][groupIdx][
      deviceId][mode] |= vlanInterfaces
   attrInterfaces = {}
   attrInterfaces[attrs] = interfacesList
   switchGroups[siteIdx][groupIdx][deviceId]['other-attrs'] |= attrInterfaces
   return switchGroups


def setClearGroupPortTable(inputs, siteIdx, groupIdx):
   '''
   Clear the switch group port table for the specified site/group
   Inputs:
      inputs:   studio inputs
      siteIdx:  site index
      groupIdx: group index
   '''
   log(1, f"setClearGroupPortTable: site {siteIdx}, group {groupIdx}")
   groupPortTable = inputs.get('sites')[siteIdx].get('inputs').get(
      'sitesGroup').get('devices')[groupIdx].get('inputs').get(
      'devicesGroup').get('interfaceRanges')
   if not groupPortTable:
      return
   for intfRangeIdx, _ in enumerate(groupPortTable):
      path = getIntfRangeIndexPath(siteIdx, groupIdx, intfRangeIdx)
      setInput(path, '', True)


def setClearPortTables(inputs, switchGroups, deviceIds):
   '''
   Clear the switch group port table for the specified devices
   Inputs:
      inputs:       studio inputs
      switchGroups: sites dictionary
      deviceIds:    list of device serial numbers
   '''
   if not switchGroups:
      return
   for siteIdx, siteGroup in switchGroups.items():
      if not siteGroup:
         continue
      for groupIdx, groupDevices in siteGroup.items():
         if not groupDevices:
            continue
         clear = False
         for deviceId in groupDevices:
            if deviceId in deviceIds:
               clear = True
               break
         if clear:
            setClearGroupPortTable(inputs, siteIdx, groupIdx)


def setPorts(switchGroups, accessVlansToProfile, trunkVlansToProfile,
             routedToProfile, aggregate):
   '''
   Set the port tables for all SwitchGroups in the studio inputs.
   Inputs:
      switchGroups: {
         siteIndex: {
            groupIndex: {
               deviceId: {
                  'switchId': Id,
                  'access-vlans': {
                     vlan: [interface1, interface2, ],
                  },
                  'trunk-vlans': {
                     vlan: [interface1, interface2, ],
                  },
                  'routed-intfs': {
                     'all': [interface1, interface2, ],
                  },
               }
            }
         }
      }
      accessVlansToProfile: {vlanId: [profileName]}
      trunkVlansToProfile: {vlanId: [profileName]}
      routedToProfile: {'all': [profileName]}
   '''
   if not switchGroups:
      return
   for siteIdx, siteGroup in switchGroups.items():
      if not siteGroup:
         continue
      for groupIdx, devices in siteGroup.items():
         if not devices:
            continue
         portRanges = getGroupPortRanges(
            devices, accessVlansToProfile, trunkVlansToProfile,
            routedToProfile, aggregate)
         log(1, f"setPorts {list(devices.keys())}:\n"
                f"{pformat(portRanges, sort_dicts=True)}")
         setGroupPortRanges(siteIdx, groupIdx, portRanges)


def main():
   # pylint: disable=undefined-variable
   stdID, wrkID, input_path = extractStudioInfoFromArgs(ctx.action.args)
   if not wrkID or not input_path:
      return
   try:
      inputs = getStudioInputs(ctx.getApiClient, stdID, wrkID)
   except (InputRequestException, InputNotFoundException) as error:
      raise ActionFailed(
               f"\nNothing to do since the studio "
               f"has no inputs. {error}") from error
   # Get user args
   global LOGLEVEL
   LOGLEVEL = int(logLevel) if (logLevel := ctx.action.args.get(
      "logLevel")) else LOGLEVEL
   aggregate = aggArg if (aggArg := ctx.action.args.get(
      "aggregate")) else 'No'
   # other attrs
   allAttributes = allAttributesArg if (allAttributesArg := ctx.action.args.get(
      "allAttributes")) else 'No'
   speed = speedArg if (speedArg := ctx.action.args.get(
      "speed")) else None
   desc = ctx.action.args.get("portDesc")
   ipv4 = ipv4Arg if (ipv4Arg := ctx.action.args.get(
      "ipv4")) else None
   ipv6 = ipv6Arg if (ipv6Arg := ctx.action.args.get(
      "ipv6")) else None
   attrvlan = attrvlan if (attrvlan := ctx.action.args.get(
      "vlan")) else 0
   allowed = allowedArg if (allowedArg := ctx.action.args.get(
      "allowedVlans")) else None
   poNum = poNumArg if (poNumArg := ctx.action.args.get(
      "channel-group")) else None
   mlagEnabled = mlagEnabledArg if (mlagEnabledArg := ctx.action.args.get(
      "mlagEnabled")) in ['enabled', 'disabled'] else None
   lacpEnabled = lacpEnabledArg if (lacpEnabledArg := ctx.action.args.get(
      "lacpEnabled")) in ['enabled', 'disabled'] else None
   validSources = ['generate', 'running-config', 'clear']
   source = ctx.action.args.get("source")
   deviceHostname = ctx.action.args.get("device")
   if not source:
      source = 'existing'
      log(0, "source unspecified: keeping existing entries")
   if source.lower() not in validSources + ['existing']:
      raise ActionFailed(
               f"\nArgument source is invalid. "
               f"It must be one of the following: "
               f"{validSources}")
   profileId = None
   interfaceCount = None
   interfaceNames = None
   if source.lower() == 'generate':
      if not (argProfileId := ctx.action.args.get("profileID")):
         raise ActionFailed("\nArgument profileID must be entered")
      profileId = argProfileId.replace('"', '').replace(
         "'", "").strip()
      argIntf = ctx.action.args.get("interface")
      if argIntf and argIntf.isnumeric() and int(argIntf) < 200:
         interfaceCount = int(argIntf)
      elif argIntf and argIntf.lower() == 'all':
         interfaceCount = 0
      elif argIntf and not argIntf.isnumeric():
         interfaceNames = argIntf
      else:
         raise ActionFailed(
                  "\nArgument interface must be entered as "
                  "a count of interfaces, "
                  "'all' to mean all interfaces, "
                  "or the name of a specific interface")
   argDevs = []
   if deviceHostname:
      devs = tagSearchQuery(ctx, f"hostname:{deviceHostname}", "",
                            ELEMENT_TYPE_DEVICE, False)
      if not devs:
         raise ActionFailed(
            "\nArgument device is an invalid hostname "
            "for a switch"
         )
      argDevs = devs
   log(1, f"action inputs:\n    "
          f"[profileId: {profileId}, "
          f"interfaceCount: {interfaceCount}, "
          f"interfaceNames: {interfaceNames}, "
          f"deviceHostname: {deviceHostname}, "
          f"aggregate: {aggregate}, source: {source}, "
          f"speed: {speed}, portDesc: {desc}, "
          f"ipv4: {ipv4}, ipv6: {ipv6}, allowed: {allowed}, poNum: {poNum}, "
          f"mlagEnabled: {mlagEnabled}, lacpEnabled: {lacpEnabled}, "
          f"]")
   log(1, f"input_path:\n    "
          f"{input_path}")
   log(3, f"inputs:\n"
          f"{json.dumps(inputs, indent=4)}")
   # Get profile mappings from the studio's current inputs
   profilesToAccessVlans, accessVlansToProfile, profilesToTrunkVlans, \
      trunkVlansToProfile, profilesToRouted, routedToProfile \
          = getProfiles(inputs, profileId)
   log(1, f"accessVlansToProfile: {accessVlansToProfile}")
   log(1, f"trunkVlansToProfile: {trunkVlansToProfile}")
   log(1, f"routedToProfile: {routedToProfile}")
   log(1, f"profilesToAccessVlans: {profilesToAccessVlans}")
   log(1, f"profilesToTrunkVlans: {profilesToTrunkVlans}")
   log(1, f"profilesToRouted: {profilesToRouted}")
   # Get switch group info from the studio's current inputs
   switchGroups = getSwitchGroups(inputs, Selection())
   log(1, f"starting switchGroups:\n"
          f"{pformat(switchGroups, sort_dicts=True)}")
   # Get devices for the Switch Group
   deviceIds = []
   siteIdx = None
   groupIdx = None
   stackIdx = None
   if not argDevs:
      if 'sitesGroup' in input_path:
         siteIdx = int(input_path[input_path.index('sites')+1])
      if 'stack' in input_path:
         groupIdx = int(input_path[input_path.index('devices')+1])
      if 'stackMember' in input_path:
         stackIdx = int(input_path[input_path.index('stack')+1])
      if bugResolverAction:
         if stackIdx is None:
            ActionFailed("\nAction must be invoked from Stack Member. "
                         "due to missing bug fix in release.")
         else:
            stackIdx = None
      log(1, f"input_path siteIdx: {siteIdx}, groupIdx: {groupIdx}, stackIdx: {stackIdx}")
      if siteIdx is not None and groupIdx is not None:
         deviceIds = getDevicesFromSwitchGroup(
            switchGroups, [siteIdx], [groupIdx], [stackIdx])
   else:
      deviceIds = argDevs
      ok, siteIdx, groupIdx, _ = getDevIndices(deviceIds[0], switchGroups)
      if not ok:
         raise ActionFailed(f"\nSpecified device {deviceIds[0]} "
                            f"is missing switch Id.")
   log(1, f"input_path deviceIds: {deviceIds}")
   if not deviceIds:
      raise ActionFailed("\nThe Switch Group has no devices.")
   # Get ports tables from existing inputs
   excludeDevs = None
   if source == 'clear' or (
      source.lower() == 'running-config') or (
      source.lower() == 'generate' and not interfaceNames):
      excludeDevs = deviceIds
   getExistingPortInterfaces(inputs, switchGroups, siteIdx,
                             groupIdx, profilesToAccessVlans,
                             profilesToTrunkVlans, profilesToRouted,
                             excludeDevs)
   log(1, f"existing switchGroups:\n"
       f"{pformat(switchGroups, sort_dicts=True)}")
   # Perform source-specific logic
   if source.lower() == 'running-config':
      for deviceId in deviceIds:
         runningConfig = getRunningConfig(deviceId=deviceId)
         log(3, f"running Config {deviceId}:\n"
                f"{pformat(runningConfig)}")
         accessVlanIntfs, trunkVlanIntfs, routedIntfs, \
            attrIntfs = getRunningInterfaces(deviceId, runningConfig)
         if allAttributes.lower() == 'no':
            attrIntfs = getMinAttrs(attrIntfs)
         switchGroups[siteIdx][groupIdx][deviceId][
            'access-vlans'] |= accessVlanIntfs
         switchGroups[siteIdx][groupIdx][deviceId][
            'trunk-vlans'] |= trunkVlanIntfs
         switchGroups[siteIdx][groupIdx][deviceId][
            'routed-intfs'] |= routedIntfs
         switchGroups[siteIdx][groupIdx][deviceId][
            'other-attrs'] |= attrIntfs
   elif source.lower() == 'generate':
      # Add generated interface info to devices in switchGroups
      if profileId in profilesToAccessVlans:
         mode = 'access-vlans'
         profilesToVlans = profilesToAccessVlans
      elif profileId in profilesToTrunkVlans:
         mode = 'trunk-vlans'
         profilesToVlans = profilesToTrunkVlans
      elif profileId in profilesToRouted:
         mode = 'routed-intfs'
         profilesToVlans = profilesToRouted
      else:
         raise ActionFailed(f"\nThe profileID {profileId} is invalid: "
                            f"Internal Error 4.")
      attrs = (speed, desc, ipv4, ipv6, attrvlan, allowed,
               poNum, mlagEnabled, lacpEnabled,)
      if interfaceCount is not None:
         for deviceId in deviceIds:
            switchGroups = addMultiplePortInterfaces(
               ctx, switchGroups, deviceId, profileId, mode,
               profilesToVlans, wrkID, interfaceCount, attrs)
      else:
         interfaceNames = expandIntfs(interfaceNames)
         for interfaceName in interfaceNames:
            for deviceId in deviceIds:
               devIntfs = tagSearchQuery(ctx, f"device:{deviceId}", wrkID,
                                         ELEMENT_TYPE_INTERFACE)
               if interfaceName not in devIntfs:
                  raise ActionFailed(f"\nInterface {interfaceName} "
                                     f"is invalid for device {deviceId}")
               switchGroups = addSpecificPortInterfaces(
                  switchGroups, deviceId, profileId, mode,
                  profilesToVlans, interfaceName, attrs)
   elif source.lower() == 'existing':
      log(1, "just transform existing")
   log(1, f"final switchGroups:\n"
          f"{pformat(switchGroups, sort_dicts=True)}")
   # Add rows to ports table for vlans added to switchGroups
   setClearPortTables(inputs, switchGroups, deviceIds)
   setPorts(switchGroups, accessVlansToProfile, trunkVlansToProfile,
            routedToProfile, aggregate)
   # Send inputs to be set
   for inputSetting in inputSettings:
      log(2, f"inputSetting: {inputSetting}")
   if inputSettings:
      sendInputSettings(stdID, wrkID, inputSettings)


if __name__ == "__main__":
   main()

