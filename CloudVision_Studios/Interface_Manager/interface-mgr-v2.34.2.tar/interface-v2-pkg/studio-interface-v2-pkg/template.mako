<%
import ipaddress
import re
import tagsearch_python.tagsearch_pb2_grpc as tsgr
import tagsearch_python.tagsearch_pb2 as tspb
from arista.tag.v2.tag_pb2 import TagKey, TagAssignmentKey
from arista.tag.v2.services import TagConfigServiceStub, TagAssignmentConfigServiceStub
from arista.tag.v2.services import TagConfigSetRequest, TagAssignmentConfigSetRequest

# Turning on DEBUG_LEVEL will impact performance
DEBUG_LEVEL = 0
if DEBUG_LEVEL:
    ctx.benchmarkingOn()

# Platform capabilities/limitations
old_veos_regex = r'(v|c)EOS(-)*(Lab)*'
new_veos_regex = r'CloudEOS(-)*(Lab)*'
veos_regex = f"({old_veos_regex})|({new_veos_regex})"
platform_settings = {
    "jericho-fixed": {
        "regexes": [r'DCS-7280\w(R|R2)\D*-.+', r'DCS-7048T'],
        "info": "Configured in standard settings",
        "reload_delay": {
            "mlag": 900,
            "non_mlag": 1020
        },
        "tcam_profile": "vxlan-routing",
    },
    "jericho-chassis": {
        "regexes": [r'DCS-75\d\d'],
        "info": "Configured in standard settings",
        "reload_delay": {
            "mlag": 900,
            "non_mlag": 1020
        },
        "tcam_profile": "vxlan-routing",
        "management_interface": "Management0",
    },
    "jericho2-fixed": {
        "regexes": [r'DCS-7280\w(R3)\D*-.+'],
        "info": "Configured in standard settings",
        "reload_delay": {
            "mlag": 900,
            "non_mlag": 1020
        },
        "tcam_profile": None,
    },
    "jericho2-chassis": {
        "regexes": [r'DCS-78\d\d'],
        "info": "Configured in standard settings",
        "reload_delay": {
            "mlag": 900,
            "non_mlag": 1020
        },
        "tcam_profile": None,
    },
    "trident3x1-fixed": {
        "regexes": [r'CCS-720DP-24S', r'CCS-720DT-24', r'CCS-710P'],
        "info": "Configured in standard settings",
        "reload_delay": {
            "mlag": 300,
            "non_mlag": 330
        },
        "tcam_profile": None,
        "trident_forwarding_table_partition": "flexible exact-match 16384 l2-shared 98304 l3-shared 131072",
        "feature_support": {
            "queue_monitor_length_notify": False,
            "phone": True,
            "poe": True,
        },
        "ip_locking": {
            "support": True
        },
        "per_interface_mtu": False,
    },
    "trident3x2-fixed-poe": {
        "regexes": [r'CCS-720DP-48S', r'CCS-722XP'],
        "info": "Configured in standard settings",
        "reload_delay": {
            "mlag": 300,
            "non_mlag": 330
        },
        "tcam_profile": None,
        "trident_forwarding_table_partition": "flexible exact-match 16384 l2-shared 98304 l3-shared 131072",
        "feature_support": {
            "queue_monitor_length_notify": False,
            "phone": True,
            "poe": True,
        },
        "ip_locking": {
            "support": True
        },
        "per_interface_mtu": False,
    },
    "trident3x2-fixed": {
        "regexes": [r'CCS-720DT-48', r'DCS-7010TX', r'DCS-7050(S|T)X-\d\d'],
        "info": "Configured in standard settings",
        "reload_delay": {
            "mlag": 300,
            "non_mlag": 330
        },
        "tcam_profile": None,
        "trident_forwarding_table_partition": "flexible exact-match 16384 l2-shared 98304 l3-shared 131072",
        "feature_support": {
            "queue_monitor_length_notify": False,
            "phone": True,
        },
        "ip_locking": {
            "support": True
        },
        "per_interface_mtu": False,
    },
    "trident3x3-fixed": {
        "regexes": [r'CCS-720XP-\d\d', r'CCS-720DP-\d\dZS', r'CCS-720DF-\d\d'],
        "info": "Configured in standard settings",
        "reload_delay": {
            "mlag": 300,
            "non_mlag": 330
        },
        "tcam_profile": None,
        "trident_forwarding_table_partition": "flexible exact-match 16384 l2-shared 98304 l3-shared 131072",
        "feature_support": {
            "queue_monitor_length_notify": False,
            "phone": True,
            "poe": True,
        },
        "ip_locking": {
            "support": True
        },
    },
    "trident3x4-chassis": {
        "regexes": [r'CCS-75\d'],
        "info": "Configured in standard settings",
        "reload_delay": {
            "mlag": 300,
            "non_mlag": 330
        },
        "tcam_profile": None,
        "trident_forwarding_table_partition": "flexible exact-match 16384 l2-shared 98304 l3-shared 131072",
        "feature_support": {
            "queue_monitor_length_notify": False,
            "phone": True,
            "poe": True,
        },
        "ip_locking": {
            "support": True
        },
        "per_interface_mtu": False,
    },
    "trident3x5|7-fixed": {
        "regexes": [r'DCS-7050\wX3'],
        "info": "Configured in standard settings",
        "reload_delay": {
            "mlag": 300,
            "non_mlag": 330
        },
        "tcam_profile": None,
        "trident_forwarding_table_partition": "flexible exact-match 16384 l2-shared 98304 l3-shared 131072",
        "feature_support": {
            "queue_monitor_length_notify": False,
            "phone": True,
        },
        "ip_locking": {
            "support": True
        },
    },
    "trident3-chassis": {
        "regexes": [r'DCS-73\d\dX3'],
        "info": "Configured in standard settings",
        "reload_delay": {
            "mlag": 1200,
            "non_mlag": 1320
        },
        "tcam_profile": None,
        "trident_forwarding_table_partition": "flexible exact-match 16384 l2-shared 98304 l3-shared 131072",
        "management_interface": "Management0",
    },
    "veos": {
        "regexes": [veos_regex],
        "info": "Configured in standard settings",
        "reload_delay": {
            "mlag": 300,
            "non_mlag": 330
        },
        "tcam_profile": None,
        "management_interface": "Management0",
        "feature_support": {
            "queue_monitor_length_notify": False,
            "interface_storm_control": False
        },
    },
    "default": {
        "regexes": [r'.+'],
        "info": "Configured in standard settings",
        "reload_delay": {
            "mlag": 300,
            "non_mlag": 330
        },
        "tcam_profile": None,
        "feature_support": {
            # "queue-monitor length notify" is only valid for R-Series
            # so should be disabled on default platform.
            "queue_monitor_length_notify": False,
        }
    }
}

switch_facts = {
    'hostname': '',
    'platform': '',
    'platform_settings': {},
}

def set_platform_settings(switch_facts):
    for platform, settings in platform_settings.items():
        # Skip default as this will be applied at the end
        # to any switch that doesn't match any other platform
        if platform == "default":
            continue
        # check to see if any default platform regex is matched
        for regex in settings['regexes']:
            if re.search(regex, switch_facts['platform'], re.IGNORECASE):
                switch_facts['platform_settings'] = settings
    # If no platform setting is matched, set to default
    if not switch_facts.get('platform_settings'):
        switch_facts['platform_settings'] = platform_settings['default']

class BaseInterface:
    def __init__(self):
        self.enabled = False
        self.mode = None
        self.security = []
        self.dot1x = []
        self.logging = []
        self.poe = []
        self.stormControl = []
        self.igmpSnooping = []
        self.igmpPortSettings = []
        self.igmpStaticGroups = []
        self.igmpEnable = False
        self.ptpGlobalCommands = []
        self.ptpPorts = []
        self.ptpVlanInterfaces = []
        self.pimInterfaceCommands = {}
        self.multicastInterfaceCommands = {}
        self.pimGlobalCommands = []
        self.pimRPCommands = []
        self.pimAnycastRPCommands = []
        self.multicastGlobalCommands = []
        self.softwareForwardingSfe = False
        self.accessVlan = None
        self.desc = None
        self.vlanName = None
        self.nativeVlanId = None
        self.allowedVlans = None
        self.phoneVlanId = None
        self.phoneTrunk = None
        self.portFastEnabled = False
        self.rootGuardEnabled = False
        self.bpduGuardEnabled = False
        self.bpduFilterEnabled = False
        self.command = None
        self.rpfMode = None
        self.ipaddress = None
        self.mgtVrfRouting = False
        self.virtualIpAddress = None
        self.virtualRouterMac = None
        self.ipAddressVirtual = None
        self.ipv6address = None
        self.virtualIpv6Address = None
        self.ipv6AddressVirtual = None
        self.arpAgingTimer = None
        self.vrf = None
        self.gateway = None
        self.secondaryIPs = []
        self.enableDhcpCollector = False
        self.ipAddressDhcpEnable = False
        self.acceptDhcpDefaultRoute = False
        self.helper = []
        self.vlanTranslation = []
        self.ipMtu = None
        self.aclIn = None
        self.aclOut = None
        self.v6AclIn = None
        self.v6AclOut = None
        self.qosInstance = None
        self.ipLocking = None
        self.macSecurity = None
        self.ethernetSegmentRouteTarget = None
        self.esi = None
        self.mplsSharedIndex = None
        self.autoRT = False
        self.autoESI = False
        self.autoESISeed = None
        self.redundancyMode = None
        self.dfPref = None
        self.lacpSysId = None
        self.linkTrackingGroup = None
        self.linkTrackingDirection = None
        self.linkTrackingRecoveryDelay = None
        self.lacpFallback = None
        self.sflow = None
        self.macAddressLearning = True
        self.shapeRate = None
        self.bandwidth = None
        self.bandwidthPercent = None
        self.ipv6EnforcementDisable = None
        self.ipv4EnforcementDisable = None
        self.ipLockingAddressFamilyIPv4 = None
        self.ipLockingAddressFamilyIPv6 = None
        self.ipLockingDenyIpAddress = []
        self.bgpSessionTracker = None
        self.lacpTimerFast = None
        self.l2ProtocolEncapVlan = None
        self.dynamicNat = []
        self.staticNat = []
        self.state = None
        self.autoState = False

class Interface(BaseInterface):
    def __init__(self):
        super().__init__()
        self.speed = None
        self.groupNum = None
        self.lacpEnabled = None

class ChannelGroup(BaseInterface):
    def __init__(self):
        super().__init__()
        self.ethernetSegmentRouteTarget = None
        self.esi = None
        self.autoRT = False
        self.autoESI = False
        self.autoESISeed = None
        self.mplsSharedIndex = None
        self.redundancyMode = None
        self.dfPref = None
        self.lacpSysId = None
        self.mlagEnabled = None
        self.lacpEnabled = None
        self.lacpFallback = None
        self.lacpFallbackTimeout = None
        self.minLinks = None
        self.linkTrackingGroup = None
        self.linkTrackingDirection = None
        self.linkTrackingRecoveryDelay = None
        self.pcDescription = None
        self.bgpSessionTracker = None

class Vlans:
    def __init__(self):
        self.vID = None
        self.vlanName = None
        self.state = None
        self.privateVlanType = None
        self.trunkGroup = None
        self.primaryVlan = None
        self.ipLocking = None
        self.trunkGroups = []
        self.disableSTP = ""

class Tunnels:
    def __init__(self):
        self.desc = None
        self.ipaddress = None
        self.ipv6address = None
        self.vrf = None
        self.destinationAddress = None
        self.source = None
        self.sourceInterface = None
        self.underlayVrf = None
        self.name = None
        self.tunnelMode = None
        self.mtu = None

class SwitchDetails:
    def __init__(self,device_id):
        self.device_id = device_id
        self.acls = {}
        self.qos = {}
        self.iplocking = {}
        self.macSec = {}
        self.ipSec = {}
        self.mc = {}
        self.multiH = {}

## Get Profile for Devices resolver in Profiles
    @ctx.benchmark
    def configure_acls(self, switch_acls):
        for acl, acl_details in switch_acls.items():
            self.acls[acl] = {}
            if acl_details["name"].strip() != "":
                self.acls[acl]["name"] = acl_details["name"]
            self.acls[acl]["counters_per_entry"] = acl_details["counters_per_entry"]
            if acl_details["description"].strip() != "":
                self.acls[acl]["description"] = acl_details["description"]
            if acl_details["type"].strip() != "":
                self.acls[acl]["type"] = acl_details["type"]
            if acl_details["acl_lines"]:
                self.acls[acl]["acl_lines"] = acl_details["acl_lines"]
            if acl_details["devices"]:
                self.acls[acl]["devices"] = acl_details["devices"]
            if acl_details["aclStandardOrExtended"]:
                self.acls[acl]["aclStandardOrExtended"] = acl_details["aclStandardOrExtended"]

    @ctx.benchmark
    def configure_qos(self, switch_qos):
        for qos, qos_details in switch_qos.items():
            self.qos[qos] = {}
            if qos_details["instance_name"].strip() != "":
                self.qos[qos]["instance_name"] = qos_details["instance_name"]
            if qos_details["class_maps"]:
                self.qos[qos]["class_maps"] = qos_details["class_maps"]
            if qos_details["policy_maps"]:
                self.qos[qos]["policy_maps"] = qos_details["policy_maps"]
            if qos_details["service_profiles"]:
                self.qos[qos]["service_profiles"] = qos_details["service_profiles"]
            if qos_details["classification"]:
                self.qos[qos]["classification"] = qos_details["classification"]
                self.qos[qos]["rewrite_rules"] = qos_details["rewrite_rules"]
            if qos_details["traffic_cl_to_q"]:
                self.qos[qos]["traffic_cl_to_q"] = qos_details["traffic_cl_to_q"]
            if qos_details["devices"]:
                self.qos[qos]["devices"] = qos_details["devices"]
            if qos_details["nextHopGroups"]:
                self.qos[qos]["nextHopGroups"] = qos_details["nextHopGroups"]

    @ctx.benchmark
    def configure_ipl(self, switch_ipl):
        for ipl, ipl_details in switch_ipl.items():
            self.iplocking[ipl] = {}
            self.iplocking[ipl]["localInterface"] = ipl_details["localInterface"]
            self.iplocking[ipl]["dhcpServers"] = ipl_details["dhcpServers"]
            self.iplocking[ipl]["enabled"] = ipl_details["enabled"]
            self.iplocking[ipl]["leaseIpAndMac"] = ipl_details["leaseIpAndMac"]
            self.iplocking[ipl]["lockedAddressExpirationMacDisabled"] = ipl_details["lockedAddressExpirationMacDisabled"]
            self.iplocking[ipl]["lockedIPv6AddressExpirationMacDisabled"] = ipl_details["lockedIPv6AddressExpirationMacDisabled"]
            self.iplocking[ipl]["lockedAddressIPv4EnforcementDisabled"] = ipl_details["lockedAddressIPv4EnforcementDisabled"]
            self.iplocking[ipl]["lockedAddressIPv6EnforcementDisabled"] = ipl_details["lockedAddressIPv6EnforcementDisabled"]

    @ctx.benchmark
    def configure_ipSec(self, switch_ipSec):
        for ipSec, ipSec_details in switch_ipSec.items():
            self.ipSec[ipSec] = {}
            self.ipSec[ipSec]["ipSecProfileName"] = ipSec_details["ipSecProfileName"]
            self.ipSec[ipSec]["ikePolicyName"] = ipSec_details["ikePolicyName"]
            self.ipSec[ipSec]["saPolicyName"] = ipSec_details["saPolicyName"]
            self.ipSec[ipSec]["dpd"] = ipSec_details["dpd"]
            self.ipSec[ipSec]["mode"] = ipSec_details["mode"]
            self.ipSec[ipSec]["connection"] = ipSec_details["connection"]
            self.ipSec[ipSec]["sharedKey"] = ipSec_details["sharedKey"]
            self.ipSec[ipSec]["espEncryption"] = ipSec_details["espEncryption"]
            self.ipSec[ipSec]["espIntegrity"] = ipSec_details["espIntegrity"]
            self.ipSec[ipSec]["encryption"] = ipSec_details["encryption"]
            self.ipSec[ipSec]["acl"] = ipSec_details["acl"]
            self.ipSec[ipSec]["version"] = ipSec_details["version"]
            self.ipSec[ipSec]["integrity"] = ipSec_details["integrity"]
            self.ipSec[ipSec]["dhGroup"] = ipSec_details["dhGroup"]
            self.ipSec[ipSec]["localId"] = ipSec_details["localId"]
            self.ipSec[ipSec]["perfectForwardSecretcy"] = ipSec_details["perfectForwardSecretcy"]
            self.ipSec[ipSec]["saLifetime"] = ipSec_details["saLifetime"]
            self.ipSec[ipSec]["ethernetUntaggedAllowed"] = ipSec_details["ethernetUntaggedAllowed"]

    @ctx.benchmark
    def configure_macSec(self, switch_macSec):
        for macSec, macSec_details in switch_macSec.items():
            self.macSec[macSec] = {}
            self.macSec[macSec]["macSecProfileName"] = macSec_details["macSecProfileName"]
            self.macSec[macSec]["key"] = macSec_details["key"]
            self.macSec[macSec]["mkaReKeyPeriod"] = macSec_details["mkaReKeyPeriod"]
            self.macSec[macSec]["cipher"] = macSec_details["cipher"]
            self.macSec[macSec]["l2ProtocolLldp"] = macSec_details["l2ProtocolLldp"]
            self.macSec[macSec]["fips"] = macSec_details["fips"]
            self.macSec[macSec]["trafficUnprotected"] = macSec_details["trafficUnprotected"]

    @ctx.benchmark
    def configure_mc(self, switch_mc):
        for mc, mc_details in switch_mc.items():
            self.mc[mc] = {}
            self.mc[mc]["pimProfileName"] = mc_details["pimProfileName"]
            self.mc[mc]["rPs"] = mc_details["rPs"]
            self.mc[mc]["anycastRPs"] = mc_details["anycastRPs"]

    @ctx.benchmark
    def configure_multiH(self, switch_multiH):
        for multiH, multiH_details in switch_multiH.items():
            self.multiH[multiH] = {}
            self.multiH[multiH]["multiHomingProfileName"] = multiH_details["multiHomingProfileName"]
            self.multiH[multiH]["lacpPortIdRange"] = multiH_details["lacpPortIdRange"]
            self.multiH[multiH]["noStpVlanIdRange"] = multiH_details["noStpVlanIdRange"]
            self.multiH[multiH]["stpSuperRoot"] = multiH_details["stpSuperRoot"]
def containsWord(string, listToSearch):
    return any([e in string for e in listToSearch])

def stripSubInt(intfName):
    return intfName.split('.')[0]

def get_loopback0_tag():
    tsclient = ctx.getApiClient(tsgr.TagSearchStub)
    tvs = tspb.TagValueSearchRequest(label='router_bgp.router_id', workspace_id=ctx.studio.workspaceId, topology_studio_request=True)
    tvsresp = tsclient.GetTagValueSuggestions(tvs)
    ptpSourceIp = None
    for tag in tvsresp.tags:
        query = '{}:\"{}\" AND device:{}'.format(tag.label, tag.value, myDeviceID)
        tagmr = tspb.TagMatchRequestV2(query=query, workspace_id=ctx.studio.workspaceId, topology_studio_request=True)
        tagmresp =  tsclient.GetTagMatchesV2(tagmr)
        if len(tagmresp.matches) > 0:
            ptpSourceIp = tag.value
            return ptpSourceIp

## get Profiles for Global Config
@ctx.benchmark
def get_ACLs(intProfileName, acl, acl_details):
    aclNameFound = None
    pimProfileFound = None
    ipSecProfileFound = None
    natProfileFound = None
    if intProfileName:
        for iprofile in profileOfProfiles:
            if iprofile.profileOfProfilesName == intProfileName:
                aclNameFound = iprofile["aclIn"] or iprofile["aclOut"] or iprofile["v6AclIn"] or iprofile["v6AclOut"]
                pimProfileFound = iprofile["pimProfile"]
                ipSecProfileFound = iprofile["ipSecProfile"]
                natProfileFound = iprofile["natProfile"]
    if acl == aclNameFound:
        switch_acls[acl] = acl_details
    for pim in pimProfiles:
        if pim.pimProfileName == pimProfileFound:
            # get ACLs for PIM Profiles
            if pim.multicastInterfaceCommands.multicastAclName == acl:
                switch_acls[acl] = acl_details
            for rp in pim.rPs:
                if rp.rPacl == acl:
                   switch_acls[acl] = acl_details
    for ipSec in ipSecProfiles:
        if ipSec.ipSecProfileName == ipSecProfileFound:
            # get ACLs for IP Sec Profiles
            if ipSec.profileGroup.acl == acl:
                switch_acls[acl] = acl_details
    for nat in natProfiles:
        if nat.natProfileName == natProfileFound:
            # get ACLs for NAT Profiles
            for natLine in nat.dynamicNat:
                if natLine.acl == acl:
                    switch_acls[acl] = acl_details
            for natLine in nat.staticNat:
                if natLine.acl == acl:
                    switch_acls[acl] = acl_details

@ctx.benchmark
def get_QOS(intProfileName, qos, qos_details):
    qosNameFound = None
    if intProfileName:
        for iprofile in profileOfProfiles:
            if iprofile.profileOfProfilesName == intProfileName:
                qosNameFound = iprofile["qosInstance"]
    if qos == qosNameFound:
        switch_qos[qos] = qos_details
        for acl, acl_details in aclInputs.items():
            # if QOS uses ACL include the ACL in the config
            for pmap in qos_details["policy_maps"]:
                for pmcmap in pmap["policyMapclassMaps"]:
                    for cmap in qos_details["class_maps"]:
                        if cmap["classMapName"] == pmcmap["pmclassMap"]:
                            if acl == cmap["acl"]:
                                switch_acls[acl] = acl_details
                for pbr in pmap["pbr"]:
                    for cmap in qos_details["class_maps"]:
                        if cmap["classMapName"] == pbr["classMap"]:
                            if acl == cmap["acl"]:
                                switch_acls[acl] = acl_details

@ctx.benchmark
def get_IPL(intProfileName, ipl, ipl_details):
    iplNameFound = None
    if intProfileName:
        for iprofile in profileOfProfiles:
            if iprofile.profileOfProfilesName == intProfileName:
                iplNameFound = iprofile["ipLockingProfile"]
    if ipl == iplNameFound:
        switch_ipl[ipl] = ipl_details

@ctx.benchmark
def get_IpSec(intProfileName, ipSec, ipSec_details):
    ipSecNameFound = None
    if intProfileName:
        for iprofile in profileOfProfiles:
            if iprofile.profileOfProfilesName == intProfileName:
                ipSecNameFound = iprofile["ipSecProfile"]
    if ipSec == ipSecNameFound:
        switch_ipSec[ipSec] = ipSec_details

@ctx.benchmark
def get_MacSec(intProfileName, macSec, macSec_details):
    macSecNameFound = None
    if intProfileName:
        for iprofile in profileOfProfiles:
            if iprofile.profileOfProfilesName == intProfileName:
                macSecNameFound = iprofile["macSecProfile"]
    if macSec == macSecNameFound:
        switch_macSec[macSec] = macSec_details

@ctx.benchmark
def get_Mc(intProfileName, mc, mc_details):
    mcNameFound = None
    if intProfileName:
        for iprofile in profileOfProfiles:
            if iprofile.profileOfProfilesName == intProfileName:
                mcNameFound = iprofile["pimProfile"]
    if mc == mcNameFound:
        switch_mc[mc] = mc_details

@ctx.benchmark
def get_NAT(intProfileName, nat, nat_details):
    natNameFound = None
    if intProfileName:
        for iprofile in profileOfProfiles:
            if iprofile.profileOfProfilesName == intProfileName:
                natNameFound = iprofile["natProfile"]
    if nat == natNameFound:
        switch_nat[nat] = nat_details

@ctx.benchmark
def hasPortChannelhasAutoPortChannelNumbering(intfRange):
    intProfileName = intfRange.get('profileOfProfileName')
    portChannelProfileName = None
    matchedportChannelProfile = None
    if intProfileName:
        for iprofile in profileOfProfiles:
            if iprofile.profileOfProfilesName == intProfileName:
                portChannelProfileName = iprofile["portChannelProfile"]
                if portChannelProfileName:
                    matchedportChannelProfile = next((p for p in portChannelProfiles if portChannelProfileName == p['portChannelProfileName']), None)
                    if not matchedportChannelProfile:
                        raise Exception('Found no matching portChannelProfile "%s" for interface %s' % (portChannelProfileName, intfName))
        if matchedportChannelProfile:
            if matchedportChannelProfile.autoPortChannelNumbering:
                if matchedportChannelProfile.membersPerPortChannel:
                    isMultiPort = matchedportChannelProfile.membersPerPortChannel
                    return isMultiPort
                else:
                    return 1
            else:
                return 0

@ctx.benchmark
def processMultiHoming(intfCfg, intfName, intf, multiHomingProfileCfg):
    if intf.autoESI:
        if intf.autoESISeed:
            seed = intf.autoESISeed.replace('.', "")
        numeric_filter = filter(str.isdigit, intfName)
        numeric_string = "".join(numeric_filter)
        autoESI = seed + numeric_string
        while len(autoESI) < 20:
            autoESI = "0" + autoESI
        autoESI = autoESI[:-4] + ":" + autoESI[-4:]
        autoESI = autoESI[:-9] + ":" + autoESI[-9:]
        autoESI = autoESI[:-14] + ":" + autoESI[-14:]
        autoESI = autoESI[:-19] + ":" + autoESI[-19:]
        intf.esi = autoESI
    #specific esi over rides profile
    esi  = intfCfg.get('esi') or multiHomingProfileCfg.get('esi')
    if esi:
        intf.esi = esi
    intf.dfPref = intfCfg.get('dfPref')
    if intf.autoRT and intf.esi:
        autoRtLacpSysId = intf.esi
        while len(autoRtLacpSysId) > 14:
            autoRtLacpSysId = autoRtLacpSysId[1:]
        RT = autoRtLacpSysId
        RT = RT[:12] + ':' + RT[12:]
        RT = RT[:7] + ':' + RT[7:]
        RT = RT[:2] + ':' + RT[2:]
        intf.ethernetSegmentRouteTarget = RT
        SysId = autoRtLacpSysId
        SysId = SysId.replace(':', '.')
        intf.lacpSysId = SysId
    if intf.esi and intf.esi.count(':') == 2:
        intf.esi = "0000:0000:" + intf.esi
    return(intf)

@ctx.benchmark
def validateProfiles(intfCfg, intfName, isMultiPort = False):
    intProfileName = intfCfg.get('profileOfProfileName')
    portChannelProfileName = None
    matchedportChannelProfile = None
    multiHomingProfileName = None
    matchedMultiHomingProfile = None
    ptpProfileName = None
    matchedptpProfile = None
    pimProfileName = None
    matchedpimProfile = None
    generalProfileName = None
    matchedGeneralProfile = None
    dot1xProfileName = None
    matchedDot1xProfile = None
    portSecurityProfileName = None
    matchedPortSecurityProfile = None
    loggingProfileName = None
    matchedLoggingProfile = None
    poeProfileName = None
    matchedPoeProfile = None
    stormControlProfileName = None
    matchedStormControlProfile = None
    igmpProfileName = None
    matchedigmpProfile = None
    macSecProfileName = None
    matchedmacSecProfile = None
    ipSecProfileName = None
    matchedipSecProfile = None
    taggingProfileName = None
    matchedTaggingProfile = None
    ipLockingProfileName = None
    matchedIpLockingProfile = None
    natProfileName = None
    matchedNatProfile = None
    if intProfileName:
        for iprofile in profileOfProfiles:
            if iprofile.profileOfProfilesName == intProfileName:
                intfCfg.aclIn = iprofile["aclIn"]
                intfCfg.aclOut = iprofile["aclOut"]
                intfCfg.v6AclIn = iprofile["v6AclIn"]
                intfCfg.v6AclOut = iprofile["v6AclOut"]
                intfCfg.qosInstance = iprofile["qosInstance"]
                intfCfg.ipLocking = iprofile["ipLockingProfile"]
                intfCfg.macSecurity = iprofile["macSecProfile"]
                portChannelProfileName = iprofile["portChannelProfile"]
                if portChannelProfileName:
                    matchedportChannelProfile = next((p for p in portChannelProfiles if portChannelProfileName == p['portChannelProfileName']), None)
                    if not matchedportChannelProfile:
                        raise Exception('Found no matching portChannelProfile "%s" for interface %s' % (portChannelProfileName, intfName))
                multiHomingProfileName = iprofile["multiHomingProfile"]
                if multiHomingProfileName:
                    matchedMultiHomingProfile = next((p for p in multiHomingProfiles if multiHomingProfileName == p['multiHomingProfileName']), None)
                    if not matchedMultiHomingProfile:
                        raise Exception('Found no matching multiHomingProfile "%s" for interface %s' % (multiHomingProfileName, intfName))
                ptpProfileName = iprofile["ptpProfile"]
                if ptpProfileName:
                    matchedptpProfile = next((p for p in ptpProfiles if ptpProfileName == p['ptpProfileName']), None)
                    if not matchedptpProfile:
                        raise Exception('Found no matching ptpProfile "%s" for interface %s' % (ptpProfileName, intfName))
                pimProfileName = iprofile["pimProfile"]
                if pimProfileName:
                    matchedpimProfile = next((p for p in pimProfiles if pimProfileName == p['pimProfileName']), None)
                    if not matchedpimProfile:
                        raise Exception('Found no matching pimProfile "%s" for interface %s' % (pimProfileName, intfName))
                generalProfileName = iprofile["vlanProfile"]
                if generalProfileName:
                    matchedGeneralProfile = next((p for p in vlanProfiles if generalProfileName == p['name']), None)
                    if not matchedGeneralProfile:
                        raise Exception('Found no matching vlanProfile "%s" for interface %s' % (generalProfileName, intfName))
                dot1xProfileName = iprofile["dot1XProfile"]
                if dot1xProfileName:
                    matchedDot1xProfile = next((p for p in dot1XProfiles if dot1xProfileName == p['dot1XProfileName']), None)
                    if not matchedDot1xProfile:
                        raise Exception('Found no matching dot1xProfile "%s" for interface %s' % (dot1xProfileName, intfName))
                portSecurityProfileName = iprofile["portSecurityProfile"]
                if portSecurityProfileName:
                    matchedPortSecurityProfile = next((p for p in portSecurityProfiles if portSecurityProfileName == p['portSecurityProfileName']), None)
                    if not matchedPortSecurityProfile:
                        raise Exception('Found no matching portSecurityProfile "%s" for interface %s' % (portSecurityProfileName, intfName))
                loggingProfileName = iprofile["loggingProfile"]
                if loggingProfileName:
                    matchedLoggingProfile = next((p for p in loggingProfiles if loggingProfileName == p['loggingProfileName']), None)
                    if not matchedLoggingProfile:
                        raise Exception('Found no matching loggingProfile "%s" for interface %s' % (loggingProfileName, intfName))
                poeProfileName = iprofile["poeProfile"]
                if poeProfileName:
                    matchedPoeProfile = next((p for p in poeProfiles if poeProfileName == p['poeProfileName']), None)
                    if not matchedPoeProfile:
                        raise Exception('Found no matching poeProfile "%s" for interface %s' % (poeProfileName, intfName))
                stormControlProfileName = iprofile["stormControlProfile"]
                if stormControlProfileName:
                    matchedStormControlProfile = next((p for p in stormControlProfiles if stormControlProfileName == p['stormControlProfileName']), None)
                    if not matchedStormControlProfile:
                        raise Exception('Found no matching stormControlProfile "%s" for interface %s' % (stormControlProfileName, intfName))
                igmpProfileName = iprofile["igmpProfile"]
                if igmpProfileName:
                    matchedigmpProfile = next((p for p in igmpProfiles if igmpProfileName == p['igmpProfileName']), None)
                    if not matchedigmpProfile:
                        raise Exception('Found no matching igmpProfile "%s" for interface %s' % (igmpProfileName, intfName))
                taggingProfileName = iprofile["taggingProfile"]
                if taggingProfileName:
                    matchedTaggingProfile = next((p for p in taggingProfiles if taggingProfileName == p['taggingProfileName']), None)
                    if not matchedTaggingProfile:
                        raise Exception('Found no matching taggingProfile "%s" for interface %s' % (taggingProfileName, intfName))
                ipLockingProfileName = iprofile["ipLockingProfile"]
                if ipLockingProfileName:
                    matchedIpLockingProfile = next((p for p in ipLockingProfiles if ipLockingProfileName == p['ipLockingProfileName']), None)
                    if not matchedIpLockingProfile:
                        raise Exception('Found no matching ipLockingProfile "%s" for interface %s' % (ipLockingProfileName, intfName))

                natProfileName = iprofile["natProfile"]
                if natProfileName:
                    matchedNatProfile = next((p for p in natProfiles if natProfileName == p['natProfileName']), None)
                    if not matchedNatProfile:
                        raise Exception('Found no matching natProfile "%s" for interface %s' % (natProfileName, intfName))

    processInterface(intfName, intfCfg, isMultiPort, intProfileName, matchedGeneralProfile, matchedportChannelProfile, matchedMultiHomingProfile, matchedDot1xProfile, matchedPortSecurityProfile, matchedLoggingProfile, matchedPoeProfile, matchedStormControlProfile, matchedptpProfile, matchedpimProfile, matchedigmpProfile, matchedTaggingProfile, matchedIpLockingProfile, matchedNatProfile)

@ctx.benchmark
def validateTunnelProfiles(tunnelCfg, intfName):
    tunnelProfileName = tunnelCfg.get('profileOfProfileName')
    ipSecProfileName = None
    matchedipSecProfile = None
    if tunnelProfileName:
        for iprofile in profileOfProfiles:
            if iprofile.profileOfProfilesName == tunnelProfileName:
                tunnelCfg.aclIn = iprofile["aclIn"]
                tunnelCfg.aclOut = iprofile["aclOut"]
                tunnelCfg.v6AclIn = iprofile["v6AclIn"]
                tunnelCfg.v6AclOut = iprofile["v6AclOut"]
                tunnelCfg.qosInstance = iprofile["qosInstance"]
                ipSecProfileName = iprofile["ipSecProfile"]
                if ipSecProfileName:
                    matchedipSecProfile = next((p for p in ipSecProfiles if ipSecProfileName == p['ipSecProfileName']), None)
                    if not matchedipSecProfile:
                        raise Exception('Found no matching ipSecProfile "%s" for interface %s' % (ipSecProfileName, intfName))
    processTunnel(intfName, tunnelCfg, matchedipSecProfile)

@ctx.benchmark
def processTunnel(intfName, tunnelCfg, ipSecProfileCfg):
    tunnel = tunnels.get(intfName, Tunnels())
    tunnel.tunnelDescription = tunnelCfg.get('description')
    tunnel.ipaddress = tunnelCfg.get('ipPrefix')
    tunnel.ipv6address = tunnelCfg.get('ipV6Prefix')
    tunnel.vrf = tunnelCfg.get('vrf')
    tunnel.destinationAddress = tunnelCfg.get('tunnelDestination')
    tunnel.source = tunnelCfg.get('tunnelSourceIp')
    tunnel.sourceInterface = tunnelCfg.get('tunnelSource')
    tunnel.underlayVrf = tunnelCfg.get('underlayVrf')
    tunnel.tunnelMode = tunnelCfg.get('tunnelMode')
    tunnel.mtu = tunnelCfg.get('mtu')
    if ipSecProfileCfg is not None:
        tunnel.name = ipSecProfileCfg.get('ipSecProfileName')
    tunnels[intfName] = tunnel

@ctx.benchmark
def processInterface(intfName, intfCfg, isMultiPort, intProfileName, generalProfileCfg, portChannelProfileCfg, multiHomingProfileCfg, dot1xProfileCfg, portSecurityProfileCfg, loggingProfileCfg, poeProfileCfg, stormControlProfileCfg, ptpProfileCfg, pimProfileCfg, igmpProfileCfg, taggingProfileCfg, ipLockingProfileCfg, natProfileCfg):
    intf = interfaces.get(intfName, Interface())
    group = groups.get(intf.groupNum, ChannelGroup())
    intf.enabled = intfCfg.get('enabled')
    intf.speed = intfCfg.get('speed')
    # determine the port channel group number
    if portChannelProfileCfg:
        if portChannelProfileCfg.get('channelGroupNumber'):
            intf.groupNum = portChannelProfileCfg.get('channelGroupNumber')
        if portChannelProfileCfg.get('autoPortChannelNumbering'):
            intf.groupNum = re.sub(r'\D', '', intfName)
    if isMultiPort and portChannelProfileCfg.get('autoPortChannelNumbering'):
        intfName = intfName.replace('(','').replace(')','')
        intfGroupList = intfName.split(',')
        intf.groupNum = re.sub("[^0-9]", "", intfGroupList[0])
    if intfCfg.get('channelGroup'):
        intf.groupNum = intfCfg.get('channelGroup')
    accessVlan = None
    accessVlan = intfCfg.get('accessVlan')
    mode = "access"
    vlanName = None
    intf.aclIn = intfCfg.get('aclIn')
    intf.aclOut = intfCfg.get('aclOut')
    intf.v6AclIn = intfCfg.get('v6AclIn')
    intf.v6AclOut = intfCfg.get('v6AclOut')
    intf.qosInstance = intfCfg.get('qosInstance')
    intf.ipLocking = intfCfg.get('ipLocking')
    intf.macSecurity = intfCfg.get('macSecurity')
    desc = intfCfg.get('description')
    if generalProfileCfg or portChannelProfileCfg or multiHomingProfileCfg or dot1xProfileCfg or loggingProfileCfg or poeProfileCfg or stormControlProfileCfg or ptpProfileCfg or pimProfileCfg or igmpProfileCfg or intf.groupNum or ipLockingProfileCfg or natProfileCfg:
        if ptpProfileCfg and not intf.groupNum:
            intf.ptpGlobalCommands = ptpProfileCfg.get('ptpGlobalCommands')
            intf.ptpVlanInterfaces = ptpProfileCfg.get('ptpVlanInterfaces')
            intf.ptpPorts = ptpProfileCfg.get('ptpPorts')
        if ipLockingProfileCfg and not intf.groupNum:
            intf.ipv6EnforcementDisable = ipLockingProfileCfg["interfaceIpLockingSettings"].get('iPv6EnforcementDisable')
            intf.ipv4EnforcementDisable = ipLockingProfileCfg["interfaceIpLockingSettings"].get('iPv4EnforcementDisable')
            intf.ipLockingAddressFamilyIPv4 = ipLockingProfileCfg["interfaceIpLockingSettings"].get('addressFamilyIPv4')
            intf.ipLockingAddressFamilyIPv6 = ipLockingProfileCfg["interfaceIpLockingSettings"].get('addressFamilyIPv6')
            intf.ipLockingDenyIpAddress = ipLockingProfileCfg["interfaceIpLockingSettings"].get('denyIpAddress')
        if natProfileCfg and not intf.groupNum:
            intf.dynamicNat = natProfileCfg.get("dynamicNat")
            intf.staticNat = natProfileCfg.get("staticNat")
        if pimProfileCfg and not intf.groupNum:
            intf.pimInterfaceCommands = pimProfileCfg.get('pimInterfaceCommands')
            intf.multicastInterfaceCommands = pimProfileCfg.get('multicastInterfaceCommands')
            intf.pimRPCommands = pimProfileCfg.get('rPs')
            intf.pimAnycastRPCommands = pimProfileCfg.get('anycastRPs')
            intf.multicastGlobalCommands = pimProfileCfg.get('multicastRouting')
            intf.softwareForwardingSfe = pimProfileCfg.get('softwareForwardingSfe')
        if poeProfileCfg and not intf.groupNum:
            intf.poe = poeProfileCfg.get('poe')
        if loggingProfileCfg and not intf.groupNum:
            intf.logging = loggingProfileCfg.get('logging')
        if dot1xProfileCfg and not intf.groupNum:
            intf.dot1x = dot1xProfileCfg.get('dot1x')
        if portSecurityProfileCfg and not intf.groupNum:
            intf.security = portSecurityProfileCfg.get('portSecurity')
        if stormControlProfileCfg and not intf.groupNum:
            intf.stormControl = stormControlProfileCfg.get('stormControl')
        if igmpProfileCfg and not intf.groupNum:
            intf.igmpSnooping = igmpProfileCfg.get('igmpSnooping')
            intf.igmpPortSettings = igmpProfileCfg.get('igmpPortSettings')
            intf.igmpStaticGroups = igmpProfileCfg.get('staticGroup')
            intf.igmpEnable = igmpProfileCfg.get('enableIgmp')
        if multiHomingProfileCfg and not intf.groupNum:
            intf.ethernetSegmentRouteTarget = multiHomingProfileCfg.get('ethernetSegmentRouteTarget')
            intf.redundancyMode = multiHomingProfileCfg.get('redundancyMode')
            intf.autoRT = multiHomingProfileCfg.get('autoRtAndLacpSysId')
            intf.autoESI = multiHomingProfileCfg.get('autoEsi')
            intf.autoESISeed = multiHomingProfileCfg.get('seedIpAddressForAutoEsi')
            intf.mplsSharedIndex = multiHomingProfileCfg.get("mplsSharedIndex")
            intf = processMultiHoming(intfCfg, intfName, intf, multiHomingProfileCfg)
        if generalProfileCfg:
            if not intf.speed:
                intf.speed = generalProfileCfg.get('speed')
            mode = generalProfileCfg.get('mode')
            intf.bgpSessionTracker = generalProfileCfg.get("bgpSessionTrackerName")
            intf.l2ProtocolEncapVlan = generalProfileCfg.get("l2ProtocolEncapVlan")
            if generalProfileCfg.linkTracking:
              intf.linkTrackingGroup = generalProfileCfg.linkTracking.get('groupName')
              intf.linkTrackingDirection = generalProfileCfg.linkTracking.get('direction')
              intf.linkTrackingRecoveryDelay = generalProfileCfg.linkTracking.get('recoveryDelay')
            intf.command = generalProfileCfg.get('command')
            intf.vlanTranslation = generalProfileCfg.get('vlanTranslation')
            intf.portFastEnabled = generalProfileCfg.get('portFastEnabled')
            intf.rootGuardEnabled = generalProfileCfg.get('rootGuardEnabled')
            intf.sflow = generalProfileCfg.get('sflow')
            intf.bpduGuardEnabled = generalProfileCfg.get('bpduGuardEnabled')
            intf.bpduFilterEnabled = generalProfileCfg.get('bpduFilterEnabled')
            if mode == 'access':
                accessVlan = accessVlan or generalProfileCfg.get('accessVlanId')
            if mode == 'l2-sub-interface':
                intf.macAddressLearning = generalProfileCfg["l2SubInterfaceProperties"].get('macAddressLearning')
                intf.shapeRate = generalProfileCfg["l2SubInterfaceProperties"].get('shapeRate')
                intf.bandwidth = generalProfileCfg["l2SubInterfaceProperties"].get('bandwidth')
                intf.bandwidthPercent = generalProfileCfg["l2SubInterfaceProperties"].get('bandwidthPercent')
                intfName = intfName + "." + str(accessVlan)
            elif mode == 'phone':
                accessVlan = accessVlan or generalProfileCfg.get('accessVlanId')
                intf.portFastEnabled = generalProfileCfg.get('portFastEnabled')
                intf.bpduGuardEnabled = generalProfileCfg.get('bpduGuardEnabled')
            elif mode == 'routed':
                # add ip address if port is routed, loopback  or vlan interface
                accessVlan = accessVlan or generalProfileCfg.get('accessVlanId')
                intf.ipaddress = generalProfileCfg.get('ipaddress')
                intf.ipAddressVirtual = generalProfileCfg.get('profileIpAddressVirtual')
                intf.virtualRouterMac = generalProfileCfg.get('virtualRouterMacAddress')
                intf.arpAgingTimer = generalProfileCfg.get('arpAgingTimer')
                intf.ipMtu = generalProfileCfg.get('ipMtu')
                intf.rpfMode = generalProfileCfg.get('reversePathForwardingMode')
                intf.helper = generalProfileCfg.get('dhcpHelpers')
                intf.enableDhcpCollector = generalProfileCfg.get('enableDhcpCollector')
                intf.acceptDhcpDefaultRoute = generalProfileCfg.get("dhcp", {}).get('acceptDefaultRoute')
                intf.ipAddressDhcpEnable = generalProfileCfg.get("dhcp", {}).get('ipAddressDhcpEnable')
                # When the interface is a routed subinterface (not a svi)
                # append the subinterface number to the port name
                # this occurs when the port profile is "Routed" and a vlan id is specified
                if accessVlan and not containsWord(intfName, vlanList):
                    intfName = intfName + "." + str(accessVlan)
            profileDesc = generalProfileCfg.get('profileDescription')
            if generalProfileCfg.vlanName:
                vlanName = generalProfileCfg.get('vlanName')
            if profileDesc:
                if '$1' in profileDesc:
                    if not desc:
                        raise Exception('Interface %s is missing a description, '
                            'needed for the profile %r template' % (intfName, profileName))
                    desc = profileDesc.replace('$1', desc)
                elif not desc:
                    desc = profileDesc
        if intf.groupNum:
            mlagEnabled = None
            lacpEnabled = None
            group.mode = mode
            intf.mode = mode
            if generalProfileCfg:
                group.bgpSessionTracker = generalProfileCfg.get("bgpSessionTrackerName")
                group.l2ProtocolEncapVlan = generalProfileCfg.get("l2ProtocolEncapVlan")
                group.portFastEnabled = generalProfileCfg.get('portFastEnabled')
                group.rootGuardEnabled = generalProfileCfg.get('rootGuardEnabled')
                group.bpduGuardEnabled = generalProfileCfg.get('bpduGuardEnabled')
                group.bpduFilterEnabled = generalProfileCfg.get('bpduFilterEnabled')
                group.sflow = generalProfileCfg.get('sflow')
                group.nativeVlanId = intf.nativeVlanId = accessVlan or generalProfileCfg.get('nativeVlanId')
                group.allowedVlans = intf.allowedVlans = intfCfg.get('vlansAllowed') or generalProfileCfg.get('allowedVlans')
                group.phoneVlanId = generalProfileCfg.get('phoneVlanId')
                group.phoneTrunk = generalProfileCfg.get('phoneTrunk')
                group.command = generalProfileCfg.get ('command')
                group.vlanTranslation = generalProfileCfg.get('vlanTranslation')
                if generalProfileCfg.linkTracking:
                  group.linkTrackingGroup = generalProfileCfg.linkTracking.get('groupName')
                  group.linkTrackingDirection = generalProfileCfg.linkTracking.get('direction')
                  group.linkTrackingRecoveryDelay = generalProfileCfg.linkTracking.get('recoveryDelay')
                if group.mode == 'phone':
                    accessVlan = accessVlan or generalProfileCfg.get('accessVlanId')
                if mode == 'l2-sub-interface':
                    group.macAddressLearning = generalProfileCfg["l2SubInterfaceProperties"].get('macAddressLearning')
                    group.shapeRate = generalProfileCfg["l2SubInterfaceProperties"].get('shapeRate')
                    group.bandwidth = generalProfileCfg["l2SubInterfaceProperties"].get('bandwidth')
                    group.bandwidthPercent = generalProfileCfg["l2SubInterfaceProperties"].get('bandwidthPercent')
                    intf.groupNum = intf.groupNum + "." + str(accessVlan)
                    group.groupNum = intf.groupNum + "." + str(accessVlan)
                elif group.mode == 'access':
                    accessVlan = accessVlan or generalProfileCfg.get('accessVlanId')
                elif group.mode == 'routed':
                    accessVlan = accessVlan or generalProfileCfg.get('accessVlanId')
                    group.ipaddress = generalProfileCfg.get('ipaddress')
                    group.ipAddressVirtual = generalProfileCfg.get('profileIpAddressVirtual')
                    group.arpAgingTimer = generalProfileCfg.get('arpAgingTimer')
                    group.ipMtu = generalProfileCfg.get('ipMtu')
                    group.rpfMode = generalProfileCfg.get('reversePathForwardingMode')
                    group.helper = generalProfileCfg.get('dhcpHelpers')
                    # When a port channel is "Routed" and a vlan id is specified
                    # append the port channel name with the vlan id
                    # to create the subinterface name
                    if accessVlan:
                        intf.groupNum = intf.groupNum + "." + str(accessVlan)
                        group.groupNum = intf.groupNum + "." + str(accessVlan)
            if portChannelProfileCfg:
                autoPortChannelNumbering = portChannelProfileCfg.get('autoPortChannelNumbering') or portChannelProfileCfg.get('autoPortChannelNumbering')
                mlagEnabled = portChannelProfileCfg.get('mlagEnabled')
                lacpEnabled = portChannelProfileCfg.get('lacpEnabled')
                group.lacpFallback = portChannelProfileCfg.get('lacpFallback')
                intf.lacpFallback = portChannelProfileCfg.get('lacpFallback')
                intf.lacpTimerFast = portChannelProfileCfg.get('lacpTimerFast')
                group.lacpFallbackTimeout = portChannelProfileCfg.get('lacpFallbackTimeout')
                group.minLinks = portChannelProfileCfg.get('minimumLinks')
            if multiHomingProfileCfg:
                group.ethernetSegmentRouteTarget = multiHomingProfileCfg.get('ethernetSegmentRouteTarget')
                group.redundancyMode = multiHomingProfileCfg.get('redundancyMode')
                group.lacpSysId = multiHomingProfileCfg.get('lacpSysId')
                group.autoRT = multiHomingProfileCfg.get('autoRtAndLacpSysId')
                group.autoESI = multiHomingProfileCfg.get('autoEsi')
                group.autoESISeed = multiHomingProfileCfg.get('seedIpAddressForAutoEsi')
                group.mplsSharedIndex = multiHomingProfileCfg.get("mplsSharedIndex")
                group = processMultiHoming(intfCfg, intf.groupNum, group, multiHomingProfileCfg)
            if loggingProfileCfg:
                group.logging = loggingProfileCfg.get('logging')
            if portSecurityProfileCfg:
                group.security = portSecurityProfileCfg.get('portSecurity')
            if stormControlProfileCfg:
                group.stormControl = stormControlProfileCfg.get('stormControl')
            if pimProfileCfg:
                group.pimInterfaceCommands = pimProfileCfg.get('pimInterfaceCommands')
                group.multicastInterfaceCommands = pimProfileCfg.get('multicastInterfaceCommands')
                group.pimRPCommands = pimProfileCfg.get('rPs')
                group.pimAnycastRPCommands = pimProfileCfg.get('anycastRPs')
                group.multicastGlobalCommands = pimProfileCfg.get('multicastRouting')
                group.softwareForwardingSfe = pimProfileCfg.get('softwareForwardingSfe')
            if igmpProfileCfg:
                group.igmpSnooping = igmpProfileCfg.get('igmpSnooping')
                group.igmpPortSettings = igmpProfileCfg.get('igmpPortSettings')
                group.igmpStaticGroups = igmpProfileCfg.get('staticGroup')
                group.igmpEnable = igmpProfileCfg.get('enableIgmp')
            if natProfileCfg:
                group.dynamicNat = natProfileCfg.get("dynamicNat")
                group.staticNat = natProfileCfg.get("staticNat")
            group.vlanName = vlanName
            group.accessVlan = accessVlan
            group.aclIn = intfCfg.get('aclIn')
            group.aclOut = intfCfg.get('aclOut')
            group.v6AclIn = intfCfg.get('v6AclIn')
            group.v6AclOut = intfCfg.get('v6AclOut')
            group.qosInstance = intfCfg.get('qosInstance')
            group.ipLocking = intfCfg.get('ipLocking')
            group.pcDescription = intfCfg.get('portChannelDescription')
            group.mlagEnabled = intfCfg.get('mlagEnabled') or mlagEnabled
            intf.lacpEnabled = group.lacpEnabled = intfCfg.get('lacpEnabled') or lacpEnabled
            intf.desc = desc
        else:
            intf.mode = mode
            intf.nativeVlanId = accessVlan or generalProfileCfg.get('nativeVlanId') if generalProfileCfg else None
            intf.allowedVlans = intfCfg.get('vlansAllowed') or generalProfileCfg.get('allowedVlans') if generalProfileCfg else None
            intf.phoneVlanId = generalProfileCfg.get('phoneVlanId') if generalProfileCfg else None
            intf.phoneTrunk = generalProfileCfg.get('phoneTrunk') if generalProfileCfg else None
            intf.desc = desc
            intf.vlanName = vlanName

    # Override Profile Config
    intf.accessVlan = accessVlan
    # if a routed port
    ip = intfCfg.get("ipPrefix")
    if ip:
        intf.ipaddress = ip
        intf.gateway = intfCfg.get("defaultGw")
        if intf.groupNum:
            group.ipaddress = ip
            group.gateway = intfCfg.get("defaultGw")
    ipv6 = intfCfg.get("ipv6Prefix")
    if ipv6:
        intf.ipv6address = ipv6
        if intf.groupNum:
            group.ipv6address = ipv6
    intf.vrf = intfCfg["vrf"]
    if intf.groupNum:
        # interface channel group inputs overrides general profile
        group.vlanName = vlanName
        group.vrf = intfCfg["vrf"]
        group.enabled = intf.enabled
    vlanName = intfCfg.get('vlanName')
    if vlanName:
        intf.vlanName = vlanName
        if intf.groupNum:
            group.vlanName = vlanName
    # if a vlan or management interface
    if containsWord(intfName, vlanList) or containsWord(intfName, managementIntList):
        intf.mode = "routed"
        intf.desc = intfCfg["description"]
        intf.vlanName = intfCfg["description"]
        if intfCfg["ipPrefix"]:
            intf.ipaddress = intfCfg["ipPrefix"]
        intf.virtualIpAddress = intfCfg["virtualRouterAddress"]
        if intfCfg["ipAddressVirtual"]:
            intf.ipAddressVirtual = intfCfg["ipAddressVirtual"]
        if intfCfg["ipv6Prefix"]:
            intf.ipv6address = intfCfg["ipv6Prefix"]
        intf.virtualIpv6Address = intfCfg["virtualRouterIpv6Address"]
        if intfCfg["ipv6AddressVirtual"]:
            intf.ipv6AddressVirtual = intfCfg["ipv6AddressVirtual"]
        intf.vrf = intfCfg["vrf"]
        intf.gateway = intfCfg["defaultGatewayNextHop"]
        intf.secondaryIPs = intfCfg["secIp"]
        intf.mgtVrfRouting = intfCfg["mgtVrfRouting"]
        intf.state = intfCfg["enabled"]
        intf.autoState = intfCfg["autoState"]

    # if a loopback interface
    if intfName.lower().startswith('loopback') or intfName.lower().startswith('Loopback'):
        intf.mode = "routed"
        intf.desc = intfCfg["description"]
        if intfCfg["ipPrefix"]:
            intf.ipaddress = intfCfg["ipPrefix"]
        intf.vrf = intfCfg["vrf"]
        intf.secondaryIPs = intfCfg["secIp"]

    # Finish processing interfaces
    interfaces[intfName] = intf
    if intf.groupNum:
        groups[intf.groupNum] = group
    createInterfaceTags(taggingProfileCfg, intProfileName, intf, intfName, group)

@ctx.benchmark
def cleanUpInterfaceNamesToBeTagged(interface):
    if containsWord(interface, vlanList):
        return interface
    if interface.count("/") == 1:
        intfSplitSlash = list(interface.split("/"))
        slashList = []
        # strip non decimal characters
        for intf in intfSplitSlash:
            intf ="".join(c for c in intf if  c.isdecimal())
            slashList.append(intf)
        interface = "/".join(slashList)
        interface = "Ethernet" + interface
    else:
        if interface.count(".") == 1:
            intfSplitDot = list(interface.split("."))
            dotList = []
            # strip non decimal characters
            for intf in intfSplitDot:
                intf ="".join(c for c in intf if  c.isdecimal())
                dotList.append(intf)
            interface = ".".join(dotList)
            interface = "Ethernet" + interface
        else:
            interface="".join(c for c in interface if  c.isdecimal())
            interface = "Ethernet" + interface
    return interface

@ctx.benchmark
def createInterfaceTags(taggingProfileCfg, intProfileName, intf, intfName, group):
    # Create Interface Tags
    profileTagValue = None
    descriptionTagValue = None
    pcDescriptionTagValue = None
    pcVrfTagValue = None
    vrfTagValue = None
    # get teg values
    if taggingProfileCfg:
        linkTagValue = taggingProfileCfg['taggingSettings'].get('linkTypeTag')
        linkTagValue = linkTagValue.replace(" ", "")
    profileTagValue = intProfileName
    profileTagValue = profileTagValue.replace(" ", "")
    if intf.groupNum:
        pcDescriptionTagValue = group.pcDescription
        pcDescriptionTagValue = pcDescriptionTagValue.replace(" ", "")
    if intf.desc:
        descriptionTagValue = intf.desc
        descriptionTagValue = descriptionTagValue.replace(" ", "")
    if intf.groupNum:
        pcVrfTagValue = group.vrf
        pcVrfTagValue = pcVrfTagValue.replace(" ", "")
    if intf.vrf:
        vrfTagValue = intf.vrf
        vrfTagValue = vrfTagValue.replace(" ", "")
    # create tags for port channel interfaces
    if intf.groupNum:
        fullName = 'Port-Channel'+ str(intf.groupNum)
        # populate the list of tags to create
        if taggingProfileCfg:
            if linkTagValue:
                typeTag = (myDeviceID, fullName, 'Type', linkTagValue, False )
                if typeTag not in intTagList:
                    intTagList.append(typeTag)
        if profileTagValue:
            profileTag = (myDeviceID, fullName, 'Profile', profileTagValue, False )
            if profileTag not in intTagList:
                intTagList.append(profileTag)
        if pcDescriptionTagValue:
            descriptionTag = (myDeviceID, fullName, 'Description', pcDescriptionTagValue, False )
            if descriptionTag not in intTagList:
                intTagList.append(descriptionTag)
        if pcVrfTagValue:
            vrfTag = (myDeviceID, fullName, 'VRF', pcVrfTagValue, False )
            if vrfTag not in intTagList:
                intTagList.append(vrfTag)
        # strip the subinterface number from the Ethernet
        # if this is a port channel subinterface
        if intfName.count(".") == 1:
            isSubInt = intfName.split('.')
            intfName = isSubInt[0]
    # Ethernet ports might have a range comfigured
    # an interface tag is need for all ports in the range
    interfaceList = intfName.split(',')
    rangeList = []
    for interface in interfaceList:
        nameList = []
        # expand a range of ports into individual ports for tagging purposes
        # non breakout cable case
        # for example interface syntax Ethernet 1/1-3/1 (two forward slashes) expands to
        # Ethernet1/1, Ethernet2/1, and Ethernet 3/1
        if interface.count("-") == 1 and interface.count("/") == 2:
            nameList = list(interface.split("-"))
            tempList0 = []
            tempList1 = []
            nameList0 = list(nameList[0].split("/"))
            nameList1 = list(nameList[1].split("/"))
            # strip non decimal characters
            for name in nameList0:
                name ="".join(c for c in name if  c.isdecimal())
                tempList0.append(name)
            if tempList0:
                nameList0 = tempList0
            for name in nameList1:
                name ="".join(c for c in name if  c.isdecimal())
                tempList1.append(name)
            if tempList1:
                nameList1 = tempList1
            diff = (int(nameList1[0]) - int(nameList0[0]))
            rangeStart = int(nameList0[0])
            # loop through the range
            while diff > -1:
                rangeList.append(str(rangeStart) + "/" + "1")
                rangeStart = rangeStart + 1
                diff = diff - 1
        # expand a range of ports into individual ports for tagging purposes
        # breakout cable case
        # for example interface syntax Ethernet 1/1-4 (only one forward slash) expands to
        # Ethernet1/1, Ethernet1/2, Ethernet 1/3, and Ethernet 1/4
        elif interface.count("-") == 1 and interface.count("/") == 1:
            nameList = list(interface.split("-"))
            tempList0 = []
            tempList1 = []
            nameList0 = list(nameList[0].split("/"))
            nameList1 = list(nameList[1].split("/"))
            # strip non decimal characters
            for name in nameList0:
                name ="".join(c for c in name if  c.isdecimal())
                tempList0.append(name)
            if tempList0:
                nameList0 = tempList0
            for name in nameList1:
                name ="".join(c for c in name if  c.isdecimal())
                tempList1.append(name)
            if tempList1:
                nameList1 = tempList1
            diff = (int(nameList1[0]) - int(nameList0[1]))
            rangeStart = int(nameList0[1])
            # loop through the range
            while diff > -1:
                rangeList.append(str(nameList0[0]) + "/" + str(rangeStart))
                rangeStart = rangeStart + 1
                diff = diff - 1
        # range of ports without a slash
        elif interface.count("-") == 1:
            nameList = list(interface.split("-"))
            tempList = []
            # strip non decimal characters
            for name in nameList:
                name ="".join(c for c in name if  c.isdecimal())
                tempList.append(name)
            if tempList:
                nameList = tempList
            nameList[0] = re.sub(r'\D+', '', nameList[0])
            diff = (int(nameList[1]) - int(nameList[0]))
            rangeStart = int(nameList[0])
            # loop through the range
            while diff > -1:
                rangeList.append(str(rangeStart))
                rangeStart = rangeStart + 1
                diff = diff - 1
        else:
            rangeList.append(interface)
    # if there was a range replace the interface
    # list with the expanded list
    if rangeList:
        interfaceList = rangeList
        intfName = ",".join(interfaceList)
    # add Type tags to list of tags to be created for non port channels
    if taggingProfileCfg:
        if linkTagValue and intfName:
            if not intfName[0].lower().startswith('p'):
                interfaceList = intfName.split(',')
                for interface in interfaceList:
                    interface = cleanUpInterfaceNamesToBeTagged(interface)
                    typeTag = (myDeviceID, interface, 'Type', linkTagValue, False )
                    if typeTag not in intTagList:
                        intTagList.append(typeTag)
    # add Profile tags to list of tags to be created for non port channels
    if profileTagValue and intfName and not intf.groupNum:
        if not intfName[0].lower().startswith('p'):
            interfaceList = intfName.split(',')
            for interface in interfaceList:
                interface = cleanUpInterfaceNamesToBeTagged(interface)
                profileTag = (myDeviceID, interface, 'Profile', profileTagValue, False )
                if profileTag not in intTagList:
                    intTagList.append(profileTag)
    # add Description tags to list of tags to be created for non port channels
    if descriptionTagValue and intfName:
        if not intfName[0].lower().startswith('p'):
            interfaceList = intfName.split(',')
            for interface in interfaceList:
                interface = cleanUpInterfaceNamesToBeTagged(interface)
                descriptionTag = (myDeviceID, interface, 'Description', descriptionTagValue, False )
                if descriptionTag not in intTagList:
                    intTagList.append(descriptionTag)
    # add VRF tags to list of tags to be created for non port channels
    if vrfTagValue and intfName:
        if not intfName[0].lower().startswith('p'):
            interfacesCombined = []
            interfaceList = intfName.split(',')
            for interface in interfaceList:
                interface = cleanUpInterfaceNamesToBeTagged(interface)
                vrfTag = (myDeviceID, interface, 'VRF', vrfTagValue, False )
                if vrfTag not in intTagList:
                    intTagList.append(vrfTag)

@ctx.benchmark
def validateVlanProfiles(vID, vlanCfg):
    vlanProfileName = vlanCfg.get('profileOfProfileName')
    ipLockingProfileName = None
    matchedIpLockingProfile = None
    if vlanProfileName:
        for iprofile in profileOfProfiles:
            if iprofile.profileOfProfilesName == vlanProfileName:
                ipLockingProfileName = iprofile["ipLockingProfile"]
                if ipLockingProfileName:
                    matchedIpLockingProfile = next((p for p in ipLockingProfiles if ipLockingProfileName == p['ipLockingProfileName']), None)
                    if not matchedIpLockingProfile:
                        raise Exception('Found no matching ipLockingProfile "%s" for interface %s' % (ipLockingProfileName, vID))
    processVlans(vID, vlanCfg, matchedIpLockingProfile)

@ctx.benchmark
def processVlans(vID, vlanCfg, ipLockingProfileCfg):
    vlan = vlans.get(vID, Vlans())
    vlan.vID = vlanCfg.get('vlanID')
    vlan.vlanName = vlanCfg.get('vlanName')
    vlan.state = vlanCfg.get('state')
    vlan.privateVlanType = vlanCfg.get('privateVlanType')
    vlan.primaryVlan = vlanCfg.get('primaryVlan')
    vlan.trunkGroup = vlanCfg.get('trunkGroup')
    vlan.trunkGroups = vlanCfg.get('trunkGroups')
    vlan.disableSTP = vlanCfg.get('disableStp')
    vlan.ipLocking = ipLockingProfileCfg
    vlans[vID] = vlan


@ctx.benchmark
def targetedSplit(strng, sep, pos):
    strng = strng.split(sep)
    return sep.join(strng[:pos]), sep.join(strng[pos:])

@ctx.benchmark
def processAutoPortChannelNumberingPysIntfGroups(intfRange, ranges, isMultiPort):
    interfaceInput = intfRange["interfaceName"]
    # parse comma separated grouped interfaces input into separate interfaces
    if re.search(r'\(', interfaceInput) and re.search(r'\)', interfaceInput):
        ranges =  re.split(r',\(', interfaceInput)
        newlist = list()
        for group in ranges:
            splitGroup = re.split(r'\),', group)
            newlist.extend(splitGroup)
        ranges = newlist
        return (ranges)
    if isMultiPort:
        newList = []
        interfaceInputList = interfaceInput.split(",")
        for i in range(0, len(interfaceInputList), isMultiPort):
            newList.append(",".join(interfaceInputList[i:i+isMultiPort]))
        ranges = newList
    return (ranges)

@ctx.benchmark
def processAutoPortChannelNumberingMultipleRanges(intfRange, ranges):
# given interface input of comma separated ranges ex. et1-3, or et1/1-4
# a new port channelis created from each interface in the range
# 1-3 yields et1, et2, et3 and portchannel 1, portchannel 2 and port channel 3
# multiple ranges can be entered et1-3, et5-7, et9-11 
# and interfaces and associated portchannels will be created
# chassis notation is also supported ex. 1/1-4, 2/1-4, or 1/1-3/1,4/1-6/1
    nameList = []
    intList0 = []
    intList1 = []
    diff = 0
    rangeStart = 0
    bkorangeList = []
    interfaceInput = intfRange["interfaceName"]
    # parse comma separated interface input into separate interfaces
    if re.search(r',', interfaceInput):
        ranges = list(interfaceInput.split(","))
    else:
        ranges.append(interfaceInput)
    # parse interface range into separate interfaces for breakout cables
    # expand a range of ports into individual port channels
    # for example interface syntax Ethernet 1/1-4 (one forward slashe) expands to
    # Ethernet1/1, Ethernet1/2, Ethernet1/3, and Ethernet 1/4
    chassisDiff = 0
    chassisRangeStart = 0
    chassisRangeList = []
    chassisRange = []
    for range in ranges:
        if range.count("-") == 3 and range.count("/") == 2:
            chassisRange = targetedSplit(range,"/", 1)
            range = chassisRange[1]
            chassisNumbers = targetedSplit(chassisRange[0],"-", 1)
            chassisDiff =  int(chassisNumbers[1]) - int(chassisNumbers[0])
            chassisRangeStart = int(chassisNumbers[0])
            while chassisDiff > -1:
                chassisRangeList.append(str(chassisRangeStart) + "/" + chassisRange[1])
                chassisRangeStart = chassisRangeStart + 1
                chassisDiff = chassisDiff - 1
        else:
            chassisRangeList.append(range)
    if chassisRangeList:
        ranges = chassisRangeList
    for range in ranges:
        bkoIntList0 = []
        breakOutList = []
        bkoIntList0List = []
        bkoDiff = 0
        bkoRangeStart = 0
        breakoutRangeList = []
        chassisNumber = []
        if range.count("-") == 2 and range.count("/") == 2:
                chassisNumber = targetedSplit(range,"/", 1)
                range = chassisNumber[1]
        if range.count("-") == 2 and range.count("/") == 1:
            breakOutList = targetedSplit(range,"-", 2)
            # breakout cable
            if re.search(r'/', breakOutList[0]):
                bkoIntList0 = list(breakOutList[0].split("/"))
                bkoIntList0List = list(bkoIntList0[0].split("-"))
                bkoDiff =  int(bkoIntList0List[1]) - int(bkoIntList0List[0])
                bkoRangeStart = int(bkoIntList0List[0])
                while bkoDiff > -1:
                    if chassisNumber[0]:
                        breakoutRangeList.append(chassisNumber[0] + "/" + str(bkoRangeStart) + "/" + bkoIntList0[1])
                    else:
                        breakoutRangeList.append(str(bkoRangeStart) + "/" + bkoIntList0[1])
                    bkoRangeStart = bkoRangeStart + 1
                    bkoDiff = bkoDiff - 1
                for port in breakoutRangeList:
                    bkorangeList.append(port + "-" + breakOutList[1])
        else:
            bkorangeList.append(range)
    if bkorangeList:
        ranges = bkorangeList
    return (ranges)

@ctx.benchmark
def processAutoPortChannelNumberingSingleRange(range, rangeList):
    chassisNumber = []
    nameList = []
    intList0 = []
    intList1 = []
    diff = 0
    rangeStart = 0
    if range.count("-") == 1 and range.count("/") == 2:
        chassisNumber = targetedSplit(range,"/", 1)
        range = chassisNumber[1]
        leftNum = int(re.sub(r'\D', '', chassisNumber[0]))
    if range.count("-") == 1:
        nameList = list(range.split("-"))
         # range of ports
        if re.search(r'/', nameList[0]) and re.search(r'/', nameList[1]):
            intList0 = list(nameList[0].split("/"))
            intList0[0] = re.sub(r'\D', '', intList0[0])
            intList1 = list(nameList[1].split("/"))
            intList1[0] = re.sub(r'\D', '', intList1[0])
            if intList0[0] == intList1[0]:
                diff = (int(intList1[1]) - int(intList0[1]))
                rangeStart = int(intList0[1])
                while diff > -1:
                    if chassisNumber:
                        rangeList.append(chassisNumber[0] + "/" + intList0[0] + "/" + str(rangeStart))
                    else:
                        rangeList.append(intList0[0] + "/" + str(rangeStart))
                    rangeStart = rangeStart + 1
                    diff = diff - 1
            elif intList0[1] == intList1[1]:
                diff = (int(intList1[0]) - int(intList0[0]))
                rangeStart = int(intList0[0])
                while diff > -1:
                    if chassisNumber:
                        rangeList.append(chassisNumber[0] + "/" + str(rangeStart) + "/" + intList0[1])
                    else:
                        rangeList.append(str(rangeStart) + "/" + intList0[1])
                    rangeStart = rangeStart + 1
                    diff = diff - 1
        # breakout cable with /
        # if the range is 1/1-4 the output is Port-Channel111, Port-Channel112, Port-Channel113, Port-Channel114
        elif re.search(r'/', nameList[0]):
            intList0 = list(nameList[0].split("/"))
            intList0[0] = re.sub(r'\D', '', intList0[0])
            diff =  int(nameList[1]) - int(intList0[1])
            rangeStart = int(intList0[1])
            while diff > -1:
                if chassisNumber:
                    rangeList.append(chassisNumber[0] + "/" + intList0[0] + "/" + str(rangeStart))
                else:
                    rangeList.append(intList0[0] + "/" + str(rangeStart))
                rangeStart = rangeStart + 1
                diff = diff - 1
        # not a breakout port but has a /
        # if the range is 1/1-3/1 the output is Port-Channel11, Port-Channel21, and  Port-Channel31
        elif re.search(r'/', nameList[1]):
            intList1 = list(nameList[1].split("/"))
            intList1[0] = re.sub(r'\D', '', intList1[0])
            intList1[1] = re.sub(r'\D', '', intList1[1])
            diff =  int(intList1[0]) - leftNum
            rangeStart = leftNum
            while diff > -1:
                if chassisNumber:
                    rangeList.append(str(rangeStart) + "/" + intList1[1])
                    rangeStart = rangeStart + 1
                    diff = diff - 1
        # range of ports without "/"
        else:
            nameList[0] = re.sub(r'\D', '', nameList[0])
            diff = (int(nameList[1]) - int(nameList[0]))
            rangeStart = int(nameList[0])
            while diff > -1:
                if chassisNumber:
                    rangeList.append(chassisNumber[0] + "/" + str(rangeStart))
                else:
                    rangeList.append(str(rangeStart))
                rangeStart = rangeStart + 1
                diff = diff - 1
    # no ranges input
    else:
        rangeList.append(range)
    return (rangeList)

@ctx.benchmark
def processDevicesGroup(devicesGroup):
    # VLANs
    for vlan in devicesGroup.vlans:
        stackNumList = vlan["memberNumberCollection"]
        for stackNum in stackNumList:
            if myStackNumber == stackNum or stackNum == "all-switches":
                vID = vlan["vlanId"]
                vlanCfg = vlan
                vlanCfg.accessVlan = vID
                validateVlanProfiles(vID, vlanCfg)

    # Ports
    for intfRange in devicesGroup.interfaceRanges:
        intfStackNumList = intfRange["memberNumberCollection"]
        found = 0
        for intfStackNum in intfStackNumList:
            if myStackNumber == intfStackNum or intfStackNum == "all-switches":
                found = 1
                break
        if found == 0:
            continue
        ranges = []
        rangeList = []
        isMultiPort = hasPortChannelhasAutoPortChannelNumbering(intfRange)
        # process phyical interfaces to be members of a port channel
        if isMultiPort and not re.search(r'-', intfRange.interfaceName):
            ranges = processAutoPortChannelNumberingPysIntfGroups(intfRange, ranges, isMultiPort)
        # expand input if multiple comma separated interfaces are entered
        elif isMultiPort:
            ranges = processAutoPortChannelNumberingMultipleRanges(intfRange, ranges)
        else:
            ranges.append(intfRange.interfaceName)
        # expand input if dash separated ranges are entered
        for range in ranges:
            if isMultiPort:
                rangeList = processAutoPortChannelNumberingSingleRange(range, rangeList)
            else:
                rangeList.append(range)
            # clean up input and process Profiles
            for intfName in rangeList:
                for intfStackNum in intfStackNumList:
                    if intfName:
                        # remove any whitespece
                        intfName = intfName.replace(" ", "")
                        # strip all leading alpha characters from interface name unless its a Port Channel
                        if not intfName[0].lower().startswith('p'):
                            intfName = re.sub(r'^[a-zA-Z]+', '', intfName)
                            intfName = "Ethernet" + intfName
                    intfCfg = intfRange
                    validateProfiles(intfCfg, intfName, isMultiPort)
    # VLAN Interfaces
    for vlanIntf in devicesGroup.vlanInterfaces:
        intfStackNumList = vlanIntf["memberNumberCollection"]
        for stackNum in intfStackNumList:
            if myStackNumber == stackNum or stackNum == "all-switches":
                intfName = vlanIntf["vlanId"]
                intfCfg = vlanIntf
                if intfName != "Management0" and intfName != "Management1":
                    intfCfg.accessVlan = intfName
                    intfName = "Vlan" + intfName
                validateProfiles(intfCfg, intfName)
    # Loopbacks
    for lbIntf in devicesGroup.loopbackInterfaces:
        intfStackNumList = lbIntf["memberNumberCollection"]
        for intfStackNum in intfStackNumList:
            if myStackNumber == intfStackNum or intfStackNum == "all-switches":
                intfName = str(lbIntf["number"])
                intfCfg = lbIntf
                intfName = "loopback" + intfName
                validateProfiles(intfCfg, intfName)
    # Tunnel Interfaces
    for tunnel in devicesGroup.tunnelInterfaces:
        tunnelStackNumList = tunnel["memberNumberCollection"]
        for tunnelStackNum in tunnelStackNumList:
            if myStackNumber == tunnelStackNum or tunnelStackNum == "all-switches":
                intfName = str(tunnel["number"])
                tunnelCfg = tunnel
                validateTunnelProfiles(tunnelCfg, intfName)

@ctx.benchmark
def processProfiles(devicesGroup):
    # Get  ACL input
    for acl in aclNames:
        aclInputs[acl["name"]] = {
            "name": acl["name"],
            "description": acl["aclSettings"]["description"],
            "aclStandardOrExtended": acl["aclSettings"]["aclStandardOrExtended"],
            "type": acl["aclSettings"]["type"],
            "acl_lines": acl["aclLines"],
            "counters_per_entry": acl["aclSettings"]["countersPerEntry"],
            "devices": acl["devices"]
        }
    # Get  QOS input
    for qos in qosProfiles:
        qosInputs[qos["instanceName"]] = {
            "instance_name": qos["instanceName"],
            "class_maps": qos["classMaps"],
            "policy_maps": qos["policyMaps"],
            "service_profiles": qos["serviceProfiles"],
            "classification": qos["classification"],
            "rewrite_rules": qos["rewriteRules"],
            "traffic_cl_to_q": qos["trafficClassToQueue"],
            "nextHopGroups": qos["nextHopGroups"],
            "devices": qos["devices"]
        }

    # Get  IP Locking input
    for ipl in ipLockingProfiles:
        iplInputs[ipl["ipLockingProfileName"]] = {
            "ipLockingProfileName": ipl["ipLockingProfileName"],
            "localInterface": ipl["ipLockingSettings"]["localInterface"],
            "dhcpServers": ipl["dhcpServers"],
            "enabled": ipl["ipLockingSettings"]["enabled"],
            "leaseIpAndMac": ipl["ipLockingSettings"]["leaseIpAndMac"],
            "lockedAddressExpirationMacDisabled": ipl["ipLockingSettings"]["lockedAddressExpirationMacDisabled"],
            "lockedIPv6AddressExpirationMacDisabled": ipl["ipLockingSettings"]["lockedIPv6AddressExpirationMacDisabled"],
            "lockedAddressIPv4EnforcementDisabled": ipl["ipLockingSettings"]["lockedAddressIPv4EnforcementDisabled"],
            "lockedAddressIPv6EnforcementDisabled": ipl["ipLockingSettings"]["lockedAddressIPv6EnforcementDisabled"],
            "devices": ipl["devices"]
        }

    # Get  IP Sec input
    for ipSec in ipSecProfiles:
        ipSecInputs[ipSec["ipSecProfileName"]] = {
            "ipSecProfileName": ipSec["ipSecProfileName"],
            "dpd": ipSec["profileGroup"]["dpd"],
            "ikePolicyName": ipSec["ikeGroup"]["ikePolicyName"],
            "encryption": ipSec["ikeGroup"]["encryption"],
            "version": ipSec["ikeGroup"]["version"],
            "integrity": ipSec["ikeGroup"]["integrity"],
            "dhGroup": ipSec["ikeGroup"]["dhGroup"],
            "localId": ipSec["ikeGroup"]["localId"],
            "saPolicyName": ipSec["saGroup"]["saPolicyName"],
            "espEncryption": ipSec["saGroup"]["espEncryption"],
            "espIntegrity": ipSec["saGroup"]["espIntegrity"],
            "perfectForwardSecretcy": ipSec["saGroup"]["perfectForwardSecretcy"],
            "saLifetime": ipSec["saGroup"]["saLifetime"],
            "mode": ipSec["profileGroup"]["mode"],
            "dpd": ipSec["profileGroup"]["dpd"],
            "connection": ipSec["profileGroup"]["connection"],
            "sharedKey": ipSec["profileGroup"]["sharedKey"],
            "acl": ipSec["profileGroup"]["acl"],
            "ethernetUntaggedAllowed": ipSec["ethernetUntaggedAllowed"],
            "devices": ipSec["devices"]
        }
    # Get  MAC Sec input
    for macSec in macSecProfiles:
        macSecInputs[macSec["macSecProfileName"]] = {
            "macSecProfileName": macSec["macSecProfileName"],
            "fips": macSec["fips"],
            "trafficUnprotected": macSec["trafficUnprotected"],
            "key": macSec["key"],
            "cipher": macSec["cipher"],
            "l2ProtocolLldp": macSec["l2ProtocolLldp"],
            "mkaReKeyPeriod": macSec["mkaSessionGroup"]["mkaReKeyPeriod"],
            "devices": macSec["devices"]
        }
    # Get  Multicast input
    for mc in pimProfiles:
        mcInputs[mc["pimProfileName"]] = {
            "pimProfileName": mc["pimProfileName"],
            "rPs": mc["rPs"],
            "anycastRPs": mc["anycastRPs"],
            "devices": mc["devices"]
        }
    # Get  MultiHoming input
    for multiH in multiHomingProfiles:
        multiHInputs[multiH["multiHomingProfileName"]] = {
            "multiHomingProfileName": multiH["multiHomingProfileName"],
            "lacpPortIdRange": multiH["devices"].resolve()["devicesGroup"]["lacpPortIdRange"],
            "noStpVlanIdRange": multiH["devices"].resolve()["devicesGroup"]["noStpVlanIdRange"],
            "stpSuperRoot": multiH["devices"].resolve()["devicesGroup"]["stpSuperRoot"],
            "devices": multiH["devices"]
        }

    # Get only ACLs applied to this switch
    for acl, acl_details in aclInputs.items():
        if acl_details["devices"].resolve()["interfaces"]["configGlobalCommands"]:
            switch_acls[acl] = acl_details
        # get ACLs for Interface Ranges
        for intfRange in devicesGroup["interfaceRanges"]:
            intProfileName = intfRange.get('profileOfProfileName')
            intfStackNumList = intfRange["memberNumberCollection"]
            for stackNum in intfStackNumList:
                if myStackNumber == stackNum or stackNum == "all-switches":
                    get_ACLs(intProfileName, acl, acl_details)
        # get ACLs for Vlan Interfaces
        for vlanIntf in devicesGroup["vlanInterfaces"]:
            intProfileName = vlanIntf.get('profileOfProfileName')
            intfStackNumList = vlanIntf["memberNumberCollection"]
            for stackNum in intfStackNumList:
                if myStackNumber == stackNum or stackNum == "all-switches":
                    get_ACLs(intProfileName, acl, acl_details)
        # get ACLs for Tunnel Interfaces
        for tunnelIntf in devicesGroup["tunnelInterfaces"]:
            intProfileName = tunnelIntf.get('profileOfProfileName')
            intfStackNumList = tunnelIntf["memberNumberCollection"]
            if myStackNumber in intfStackNumList or 'all-switches' in intfStackNumList:
                get_ACLs(intProfileName, acl, acl_details)

    # Get only QOS applied to this switch
    for qos, qos_details in qosInputs.items():
        if qos_details["devices"].resolve()["deviceGroup"]["deviceQosSettings"]["configGlobalCommands"]:
            switch_qos[qos] = qos_details
            # Get ACLs applied applied to QOS
            for acl, acl_details in aclInputs.items():
                for cmap in qos_details["class_maps"]:
                    if acl == cmap["acl"]:
                        switch_acls[acl] = acl_details
        # Get QOS applied applied to Interface Ranges
        for intfRange in devicesGroup["interfaceRanges"]:
            intProfileName = intfRange.get('profileOfProfileName')
            intfStackNumList = intfRange["memberNumberCollection"]
            for stackNum in intfStackNumList:
                if myStackNumber == stackNum or stackNum == "all-switches":
                    get_QOS(intProfileName, qos, qos_details)
        # Get QOS applied applied to Vlan Interfaces
        for vlanIntf in devicesGroup["vlanInterfaces"]:
            intProfileName = vlanIntf.get('profileOfProfileName')
            intfStackNumList = vlanIntf["memberNumberCollection"]
            for stackNum in intfStackNumList:
                if myStackNumber == stackNum or stackNum == "all-switches":
                    get_QOS(intProfileName, qos, qos_details)

    # Get only IP Locking profiles applied to this switch
    for ipl, ipl_details in iplInputs.items():
        if ipl_details["devices"].resolve()["deviceGroup"]["configureIpLockingGlobally"]:
            switch_ipl[ipl] = ipl_details
        # get IP Locking for Interface Ranges
        for intfRange in devicesGroup["interfaceRanges"]:
            intProfileName = intfRange.get('profileOfProfileName')
            intfStackNumList = intfRange["memberNumberCollection"]
            for stackNum in intfStackNumList:
                if myStackNumber == stackNum or stackNum == "all-switches":
                    get_IPL(intProfileName, ipl, ipl_details)
    # Get only IP SEC profiles applied to this switch
    for ipSec, ipSec_details in ipSecInputs.items():
        if ipSec_details["devices"].resolve()["deviceGroup"]["configureIpSecGlobally"]:
            switch_ipSec[ipSec] = ipSec_details
            aclKeys = list(aclInputs.keys())
            if (acl := ipSec_details['acl']) in aclKeys:
                switch_acls[acl] = aclInputs[acl]
        # get IP Sec for Interface Ranges
        for tunnelInterface in devicesGroup["tunnelInterfaces"]:
            tunnelProfileName = tunnelInterface.get('profileOfProfileName')
            tunnelStackNumList = tunnelInterface["memberNumberCollection"]
            for stackNum in tunnelStackNumList:
                if myStackNumber == stackNum or stackNum == "all-switches":
                    get_IpSec(tunnelProfileName, ipSec, ipSec_details)
    # Get only MAC SEC profiles applied to this switch
    for macSec, macSec_details in macSecInputs.items():
        if macSec_details["devices"].resolve()["deviceGroup"]["configureMacSecGlobally"]:
            switch_macSec[macSec] = macSec_details
        # get Mac Sec for Interface Ranges
        for intfRange in devicesGroup["interfaceRanges"]:
            intProfileName = intfRange.get('profileOfProfileName')
            intfStackNumList = intfRange["memberNumberCollection"]
            for stackNum in intfStackNumList:
                if myStackNumber == stackNum or stackNum == "all-switches":
                    get_MacSec(intProfileName, macSec, macSec_details)
    # Get only Multicast profiles applied to this switch
    for mc, mc_details in mcInputs.items():
        if mc_details["devices"].resolve()["deviceGroup"]["configureMulticastGlobally"]:
            switch_mc[mc] = mc_details
            aclKeys = list(aclInputs.keys())
            for rp in mc_details['rPs']:
                if (acl := rp['rPacl']) in aclKeys:
                    switch_acls[acl] = aclInputs[acl]
        # get Multicast RPs for Interface Ranges
        for intfRange in devicesGroup["interfaceRanges"]:
            intProfileName = intfRange.get('profileOfProfileName')
            intfStackNumList = intfRange["memberNumberCollection"]
            for stackNum in intfStackNumList:
                if myStackNumber == stackNum or stackNum == "all-switches":
                    get_Mc(intProfileName, mc, mc_details)
    # Get only Multi Homing profiles applied to this switch
    for multiH, multiH_details in multiHInputs.items():
        _, devCtx = multiH_details["devices"].resolveWithContext()
        if devCtx.query_str:
            switch_multiH[multiH] = multiH_details

# Template mainline start
myDevice = ctx.getDevice()
myDeviceID = myDevice.id
if not sites:
    return
site = sites.resolve()
devicesGroup = site["sitesGroup"]["devices"].resolve().devicesGroup
switchGroupCli = site["sitesGroup"]["switchGroupCli"]
myStackNumber = devicesGroup["stack"].resolve()["stackMember"]
if not myStackNumber:
    return
# set up switch facts
if myDevice.hostName:
    switch_facts['hostname'] = myDevice.hostName
if myDevice.modelName:
    switch_facts['platform'] = myDevice.modelName
set_platform_settings(switch_facts)
# process DeviceGroup Assignments
groups = {}
interfaces = {}
vlans = {}
tunnels = {}
vlanList = ["Vlan","vlan"]
loopbackList = ['loopback','Loopback']
managementIntList = ['Management']
intTagList = []
processDevicesGroup(devicesGroup)

# process Profile Information
loopbackList = ['loopback','Loopback']
aclInputs = {}
qosInputs = {}
iplInputs = {}
macSecInputs = {}
mcInputs = {}
multiHInputs = {}
ipSecInputs = {}
switch_acls = {}
switch_qos = {}
switch_ipl = {}
switch_macSec = {}
switch_mc = {}
switch_multiH = {}
switch_ipSec = {}
processProfiles(devicesGroup)

# Create ACL, QOS, IP Locking, IPSec and Mac Security Global config
switch = SwitchDetails(device_id)
if len(switch_acls) > 0:
    switch.configure_acls(switch_acls)
if len(switch_qos) > 0:
    switch.configure_qos(switch_qos)
#if len(switch_vmt) > 0:
#    switch.configure_vmt(switch_vmt)
if len(switch_ipl) > 0:
    switch.configure_ipl(switch_ipl)
if len(switch_ipSec) > 0:
    switch.configure_ipSec(switch_ipSec)
if len(switch_macSec) > 0:
    switch.configure_macSec(switch_macSec)
# multicast configuration
if len(switch_mc) > 0:
    switch.configure_mc(switch_mc)
if len(switch_multiH) > 0:
    switch.configure_multiH(switch_multiH)
config_acls = switch.acls
config_qos = switch.qos
config_ipl = switch.iplocking
config_ipSec = switch.ipSec
config_macSec = switch.macSec
config_mc = switch.mc
config_multiH = switch.multiH

unintTagList = []
# Clean up all interface tags
allIntfTags = ctx.tags._getAllInterfaceTags()
for device, device_details in allIntfTags.copy().items():
    if device == myDeviceID:
        for intfWithTag, interface_details in device_details.copy().items():
            for label, label_details in interface_details.copy().items():
                if label == "Type" or label == "Profile" or label == "Description" or label == "VRF":
                    unTag = (device, intfWithTag, label, None)
                    unintTagList.append(unTag)
ctx.tags._unassignInterfaceTags(unintTagList)
# Create interface tags
if not hideAndShowProfiles["hideProperties"]["taggingProperties"] == "Disable Interface Tagging":
    ctx.tags._assignInterfaceTags(intTagList)

ctx.benchmarkDump()
%>

<%def name="makeTunnelCfg(intfName, tunnelCfg)">
    <%
    %>
## Tunnel Interfaces
## Global
%if tunnelCfg.vrf:
vrf instance ${tunnelCfg.vrf}
ip routing vrf ${tunnelCfg.vrf}
%endif
!
%if tunnelCfg.underlayVrf:
vrf instance ${tunnelCfg.underlayVrf}
ip routing vrf ${tunnelCfg.underlayVrf}
%endif
!
%if intfName:
interface tunnel ${intfName}
%  if tunnelCfg.tunnelDescription:
    description ${tunnelCfg.tunnelDescription}
%  endif
%  if tunnelCfg.vrf:
    vrf ${tunnelCfg.vrf}
%  endif
%  if tunnelCfg.ipaddress:
    ip address ${tunnelCfg.ipaddress}
%  endif
%  if tunnelCfg.ipv6address:
    ipv6 address ${tunnelCfg.ipv6address}
%  endif
%  if tunnelCfg.tunnelMode:
    tunnel mode ${tunnelCfg.tunnelMode}
%  endif
%  if tunnelCfg.mtu:
    mtu ${tunnelCfg.mtu}
%  endif
%  if tunnelCfg.underlayVrf:
    tunnel underlay vrf ${tunnelCfg.underlayVrf}
%  endif
%  if tunnelCfg.destinationAddress:
    tunnel destination ${tunnelCfg.destinationAddress}
%  endif
%  if tunnelCfg.source:
    tunnel source ${tunnelCfg.source}
%  endif
%  if tunnelCfg.sourceInterface:
    tunnel source interface ${tunnelCfg.sourceInterface}
%  endif
%  if tunnelCfg.name:
    tunnel ipsec profile ${tunnelCfg.name}
%  endif
    exit
!
%endif
</%def>

<%def name="makeIntfCfg(intfName, intfCfg)">
    <%
      # Interface-specific settings (intfCfg) override profile settings
      # Speed is always taken from profile if not set at interface level.
      # Description is always taken from profile, and template-substituted with interface description
      vlanIntFound = containsWord(intfName, vlanList)
      managementIntFound = containsWord(intfName, managementIntList)
      loopbackIntFound = containsWord(intfName, loopbackList)
      intfName = stripSubInt(intfName)
    %>
## Global Commands
%if intfCfg.linkTrackingGroup and intfCfg.linkTrackingRecoveryDelay:
link tracking group ${intfCfg.linkTrackingGroup}
    recovery delay ${intfCfg.linkTrackingRecoveryDelay}
%endif
%if intfCfg.mode == 'routed' and intfCfg.vrf:
!
vrf instance ${intfCfg.vrf}
%  if not managementIntFound:
ip routing vrf ${intfCfg.vrf}
ipv6 unicast-routing vrf ${intfCfg.vrf}
%  elif managementIntFound and not intfCfg.mgtVrfRouting:
no ip routing vrf ${intfCfg.vrf}
no ipv6 unicast-routing vrf ${intfCfg.vrf}
%  elif managementIntFound and intfCfg.mgtVrfRouting:
ip routing vrf ${intfCfg.vrf}
ipv6 unicast-routing vrf ${intfCfg.vrf}
%  endif
%  if intfCfg.gateway:
ip route vrf ${intfCfg.vrf} 0.0.0.0/0 ${intfCfg.gateway}
%  endif
%elif intfCfg.mode == 'routed':
ip routing
%  if intfCfg.gateway:
ip route 0.0.0.0/0 ${intfCfg.gateway}
%  endif
%endif
!
## Interface commands
interface ${intfName}
%  if intfCfg.enabled and loopbackIntFound == 0:
    no shutdown
%  elif not intfCfg.enabled and loopbackIntFound == 0:
    shutdown
%  endif
%  if intfCfg.bgpSessionTracker:
    bgp session tracker ${intfCfg.bgpSessionTracker}
%  endif
%  if intfCfg.l2ProtocolEncapVlan:
    l2-protocol encapsulation dot1q vlan ${intfCfg.l2ProtocolEncapVlan}
%  endif
## LINK TRACKING
%  if intfCfg.linkTrackingGroup and intfCfg.linkTrackingDirection:
    link tracking group ${intfCfg.linkTrackingGroup} ${intfCfg.linkTrackingDirection}
%  endif
%  if intfCfg.speed == "auto":
    speed auto
%  elif intfCfg.speed:
    speed ${intfCfg.speed}
%  endif
  ## VLANs
%  if intfCfg.mode == 'access':
%    if intfCfg.desc:
    description ${intfCfg.desc}
%    endif
    switchport
    switchport mode access
%    if intfCfg.lacpFallback is None and not intfName[0].lower().startswith('p'):
    no channel-group
%    endif
%    if intfCfg.accessVlan is not None:
    switchport access vlan ${intfCfg.accessVlan}
%    endif
## MULTI HOMING
    ${makeMultiHoming(intfCfg)}
%  elif intfCfg.mode == 'l2-sub-interface':
    no switchport
    no switchport mode
%    if intfCfg.ipMtu:
    mtu ${intfCfg.ipMtu}
%    endif

%    if intfCfg.accessVlan:
!
interface ${intfName}.${intfCfg.accessVlan}
    description ${intfCfg.desc}
    encapsulation dot1q vlan ${intfCfg.accessVlan}
    vlan id ${intfCfg.accessVlan}
%    endif
%    if not intfCfg.macAddressLearning:
    mac address learning disabled
%    endif
%    if intfCfg.shapeRate:
    shape rate ${intfCfg.shapeRate}
%    endif
%    if intfCfg.bandwidth:
    bandwidth guaranteed ${intfCfg.bandwidth}
%    endif
%    if intfCfg.bandwidthPercent:
    bandwidth guaranteed percent ${intfCfg.bandwidthPercent}
%    endif
## MULTI HOMING
    ${makeMultiHoming(intfCfg)}
%  elif intfCfg.mode == 'trunk':
%    if intfCfg.desc:
    description ${intfCfg.desc}
%    endif
    switchport
    switchport mode trunk
%    if intfCfg.lacpFallback is None and not intfName[0].lower().startswith('p'):
    no channel-group
%    endif
%      if intfCfg.nativeVlanId:
    switchport trunk native vlan ${intfCfg.nativeVlanId}
%      endif
%      if intfCfg.allowedVlans:
    switchport trunk allowed vlan ${intfCfg.allowedVlans}
%      endif
%      for vvlan in intfCfg.vlanTranslation:
%        if vvlan.direction == "Bi-Directional":
    switchport vlan translation ${vvlan.translatedVlan} ${vvlan.originalVlan}
%        elif vvlan.direction == "In":
    switchport vlan translation in ${vvlan.translatedVlan} ${vvlan.originalVlan}
%        elif vvlan.direction == "Out":
    switchport vlan translation out ${vvlan.translatedVlan} ${vvlan.originalVlan}
%        endif
%      endfor
  ## MULTI HOMING
    ${makeMultiHoming(intfCfg)}
%  elif intfCfg.mode == 'routed':
  ## Loopbacks
%    if loopbackIntFound:
%      if intfCfg.desc:
    description ${intfCfg.desc}
%      endif
%      if intfCfg.vrf:
    vrf ${intfCfg.vrf}
%      endif
%      if intfCfg.ipaddress:
    ip address ${intfCfg.ipaddress}/32
%      endif
%      if intfCfg.ipv6address:
    ipv6 address ${intfCfg.ipv6address}/128
%      endif
%      for secadd in intfCfg.secondaryIPs:
    ip address ${secadd.secPrefix}/32 secondary
%      endfor
  ## Routed Port
%    elif not (vlanIntFound or managementIntFound):
    no switchport
    no switchport mode
%    if intfCfg.lacpFallback is None and not intfName[0].lower().startswith('p'):
    no channel-group
%    endif
%      if intfCfg.ipMtu:
    mtu ${intfCfg.ipMtu}
%      endif
%      if intfCfg.accessVlan:
!
interface ${intfName}.${intfCfg.accessVlan}
    encapsulation dot1q vlan ${intfCfg.accessVlan}
%      endif
%      if intfCfg.desc:
    description ${intfCfg.desc}
%      endif
%      if intfCfg.vrf:
    vrf ${intfCfg.vrf}
%      endif
%      if intfCfg.ipaddress:
    ip address ${intfCfg.ipaddress}
%      endif
%      if intfCfg.ipv6address:
    ipv6 address ${intfCfg.ipv6address}
%      endif
%      for helper in intfCfg.helper:
%        if helper.sourceInterface:
    ip helper-address ${helper.helperAddress} source-interface ${helper.sourceInterface}
%        endif
%        if helper.vrf:
    ip helper-address ${helper.helperAddress} vrf ${helper.vrf}
%        endif
%        if not helper.sourceInterface and not helper.vrf:
    ip helper-address ${helper.helperAddress}
%        endif
%      endfor
%      if intfCfg.rpfMode == "loose-mode non-default":
    ip verify unicast source reachable-via any non-default
%      elif intfCfg.rpfMode == "loose-mode":
    ip verify unicast source reachable-via any
%      elif intfCfg.rpfMode == "strict-mode":
    ip verify unicast source reachable-via rx
%      endif
  ## MULTI HOMING
    ${makeMultiHoming(intfCfg)}
  ## VLAN Interface
%    else:
%      if intfCfg.desc:
    description ${intfCfg.desc}
%      endif
%      if intfCfg.vrf:
    vrf ${intfCfg.vrf}
%      endif
%      if intfCfg.ipAddressDhcpEnable:
    ip address dhcp
%      endif
%      if intfCfg.acceptDhcpDefaultRoute:
    dhcp client accept default-route
%      endif
%      if intfCfg.ipaddress:
    ip address ${intfCfg.ipaddress}
%      if vlanIntFound:
%        if not intfCfg.autoState:
    no autostate
%        endif
%      endif
%      endif
%      if intfCfg.virtualIpAddress:
    ip virtual-router address ${intfCfg.virtualIpAddress}
%      endif
%      if intfCfg.ipAddressVirtual:
    ip address virtual ${intfCfg.ipAddressVirtual}
%        if not intfCfg.autoState:
    no autostate
%        endif
%      endif
%      if intfCfg.ipv6address:
    ipv6 address ${intfCfg.ipv6address}
%        if not intfCfg.autoState:
    no autostate
%        endif
%      endif
%      if intfCfg.virtualIpv6Address:
    ipv6 virtual-router address ${intfCfg.virtualIpv6Address}
%      endif
%      if intfCfg.ipv6AddressVirtual:
    ipv6 address virtual ${intfCfg.ipv6AddressVirtual}
%        if not intfCfg.autoState:
    no autostate
%        endif
%      endif
%      if intfCfg.arpAgingTimer:
    arp aging timeout ${intfCfg.arpAgingTimer}
%      endif
%      for secadd in intfCfg.secondaryIPs:
%        if secadd.ipAddressVirtual:
    ip address virtual ${secadd.secPrefix} secondary
%        else:
    ip address ${secadd.secPrefix} secondary
%        endif
%      endfor
%      if intfCfg.ipMtu:
    mtu ${intfCfg.ipMtu}
%      endif
%      for helper in intfCfg.helper:
%        if helper.sourceInterface:
    ip helper-address ${helper.helperAddress} source-interface ${helper.sourceInterface}
%        endif
%        if helper.vrf:
    ip helper-address ${helper.helperAddress} vrf ${helper.vrf}
%        endif
%        if not helper.sourceInterface and not helper.vrf:
    ip helper-address ${helper.helperAddress}
%        endif
%      endfor
%      if intfCfg.rpfMode == "loose-mode non-default":
    ip verify unicast source reachable-via any non-default
%      elif intfCfg.rpfMode == "loose-mode":
    ip verify unicast source reachable-via any
%      elif intfCfg.rpfMode == "strict-mode":
    ip verify unicast source reachable-via rx
%      endif
%    endif
  %elif intfCfg.mode == 'phone':
%    if intfCfg.desc:
    description ${intfCfg.desc}
%    endif
    switchport
    switchport mode trunk phone
%    if intfCfg.lacpFallback is None and not intfName[0].lower().startswith('p'):
    no channel-group
%    endif
%    if intfCfg.nativeVlanId:
    switchport trunk native vlan ${intfCfg.nativeVlanId}
%    endif
%    if intfCfg.allowedVlans:
    switchport trunk allowed vlan ${intfCfg.allowedVlans}
%    endif
%    if intfCfg.phoneVlanId:
    switchport phone vlan ${intfCfg.phoneVlanId}
%     endif
%     if intfCfg.phoneTrunk == "untagged":
    switchport phone trunk untagged
%     endif
%     if intfCfg.phoneTrunk == "tagged":
    switchport phone trunk tagged
%     endif
%  elif intfCfg.accessVlan:
    switchport
    switchport mode access
%    if intfCfg.accessVlan is not None:
    switchport access vlan ${intfCfg.accessVlan}
%    endif
%  endif
  ## QOS
%  if intfCfg.qosInstance:
${makeQOS(intfCfg)}
%  endif
  ## ACL
%  if intfCfg.aclIn:
    ip access-group ${intfCfg.aclIn} in
%  endif
%  if intfCfg.aclOut:
    ip access-group ${intfCfg.aclOut} out
%  endif
%  if intfCfg.v6AclIn:
    ipv6 access-group ${intfCfg.v6AclIn} in
%  endif
%  if intfCfg.v6AclOut:
    ipv6 access-group ${intfCfg.v6AclOut} out
%  endif
  ## IP Locking
%  if intfCfg.ipLocking:
    address locking
%    if intfCfg.ipv4EnforcementDisable:
        locked-address ipv4 enforcement disabled
%    endif
%    if intfCfg.ipv6EnforcementDisable:
        locked-address ipv6 enforcement disabled
%    endif
%    if intfCfg.ipLockingAddressFamilyIPv4:
        address-family ipv4
%    endif
%    if intfCfg.ipLockingAddressFamilyIPv6:
        address-family ipv6
%    endif
%    if not intfCfg.ipLockingAddressFamilyIPv4:
        address-family ipv4 disabled
%    endif
%    if not intfCfg.ipLockingAddressFamilyIPv6:
        address-family ipv6 disabled
%    endif
%    for address in intfCfg.ipLockingDenyIpAddress:
        deny ${address}
%    endfor
        exit
%  endif
 ## MAC Sec
%  if intfCfg.macSecurity:
    mac security profile ${intfCfg.macSecurity}
%  endif
  ## Spanning Tree
%  if intfCfg.portFastEnabled:
    spanning-tree portfast
%  endif
%  if intfCfg.rootGuardEnabled:
    spanning-tree guard root
%  endif
%  if intfCfg.bpduGuardEnabled:
    spanning-tree bpduguard enable
%  endif
%  if intfCfg.bpduFilterEnabled:
    spanning-tree bpdufilter enable
%  endif
%  if intfCfg.sflow:
    sflow ${intfCfg.sflow}
%  endif
  ## Port Security
%  if intfCfg.security and intfCfg.mode != "routed":
  ${makePortSecurity(intfCfg)}
%  endif
  ## Dot1x
%  if intfCfg.dot1x and intfCfg.mode != "routed":
  ${makeDot1x(intfCfg)}
%  endif
  ## Logging
%  if intfCfg.logging:
  ${makeLogging(intfCfg)}
%  endif
  ## PoE
%  if intfCfg.poe and intfCfg.mode != "routed":
  ${makePoE(intfCfg)}
%  endif
  ## Storm Control
%  if intfCfg.stormControl and intfCfg.mode != "routed":
  ${makeStormControl(intfCfg)}
%  endif
  ## IGMP
%  if intfCfg.igmpEnable:
  ${makeIGMP(intfCfg)}
%  endif
  ## NAT
%  if intfCfg.dynamicNat and intfCfg.mode == "routed":
  ${makeDynamicNat(intfCfg)}
%  endif
%  if intfCfg.staticNat and intfCfg.mode == "routed":
  ${makeStaticNat(intfCfg)}
%  endif
    ## PTP
%  if intfCfg.ptpPorts and not vlanIntFound:
  ${makePTP(intfCfg)}
%  endif
   ## Multicast
%  if intfCfg.mode == "routed":
    ${makeMulticast(intfCfg)}
%  endif
  ## COMMAND LINE
%  if intfCfg.command:
    ${intfCfg.command}
%  endif
    exit
!
## Global DHCP Collector
%  if intfCfg.enableDhcpCollector and intfCfg.mode == "routed":
ip dhcp snooping
ip dhcp snooping information option
ip dhcp snooping ${intfName}
!
%  endif
## Global dot1x
%if intfCfg.dot1x:
dot1x system-auth-control
dot1x dynamic-authorization
!
%endif
## Global PTP
%if intfCfg.ptpGlobalCommands:
${makeGlobalPTP(intfCfg)}
%endif

## Global NAT
%if intfCfg.dynamicNat:
${makeGlobalNat(intfCfg)}
%endif

## Global Multicast
%  if intfCfg.mode == "routed":
    ${makeGlobalMulticast(intfCfg)}
%  endif
## Global IGMP
%if intfCfg.igmpSnooping:
${makeGlobalIGMP(intfCfg)}
%endif
## Global VLAN
%if intfCfg.mode == 'access' or vlanIntFound:
%  if intfCfg.accessVlan:
vlan ${intfCfg.accessVlan}
!
%  endif
%endif
%if intfCfg.nativeVlanId  and intfCfg.nativeVlanId != 1:
vlan ${intfCfg.nativeVlanId}
!
%endif
%if intfCfg.mode == 'routed':
%  if vlanIntFound:
%    if intfCfg.virtualIpAddress:
%      if intfCfg.virtualRouterMac:
ip virtual-router mac-address ${intfCfg.virtualRouterMac}
%      else:
ip virtual-router mac-address 001c.7300.0099
%      endif
    <%
        route = ipaddress.ip_interface(intfCfg.virtualIpAddress)
    %>
%      if intfCfg.vrf:
ip route vrf ${intfCfg.vrf} ${route.network} vlan ${intfCfg.accessVlan}
%      else:
ip route ${route.network} vlan ${intfCfg.accessVlan}
%      endif
%    endif
%    if intfCfg.ipAddressVirtual:
%      if intfCfg.virtualRouterMac:
ip virtual-router mac-address ${intfCfg.virtualRouterMac}
%      else:
ip virtual-router mac-address 001c.7300.0099
%      endif
%    endif
%    if intfCfg.gateway:
%      if intfCfg.vrf:
ip route vrf ${intfCfg.vrf} 0.0.0.0/0 ${intfCfg.gateway}
%      else:
ip route 0.0.0.0/0 ${intfCfg.gateway}
%      endif
%    endif
!
%    if intfCfg.helper:
ip dhcp relay information option
ip dhcp relay always-on
!
%    endif
%  endif
%endif
</%def>

<%def name="makeChannelMemberCfg(intfName, intfCfg)">
    <%
      # Simple config for a port channel member interface
      intfName = stripSubInt(intfName)
      intfCfg.groupNum = stripSubInt(intfCfg.groupNum)
    %>
##!
interface ${intfName}
%if intfCfg.enabled:
    no shutdown
%endif
%if intfCfg.mode == 'routed':
    no switchport
%else:
    switchport
%endif
%  if intfCfg.desc:
    description ${intfCfg.desc}
%  endif
%if intfCfg.speed == "auto":
    speed auto
%elif intfCfg.speed:
    speed ${intfCfg.speed}
%endif
## MAC Sec
%  if intfCfg.macSecurity:
    mac security profile ${intfCfg.macSecurity}
%  endif
%if intfCfg.lacpTimerFast:
    lacp timer fast
%endif
%if intfCfg.lacpEnabled == "enabled":
    channel-group ${intfCfg.groupNum} mode active
    exit
!
%else:
    channel-group ${intfCfg.groupNum} mode on
    exit
!
%endif
##    exit
</%def>

<%def name="makeChannelGroupCfg(groupNum, groupCfg)">
## Global Commands
%if groupCfg.linkTrackingGroup and groupCfg.linkTrackingRecoveryDelay:
link tracking group ${groupCfg.linkTrackingGroup}
    recovery delay ${groupCfg.linkTrackingRecoveryDelay}
%endif
%if groupCfg.mode == 'routed':
%  if groupCfg.vrf:
vrf instance ${groupCfg.vrf}
ip routing vrf ${groupCfg.vrf}
%  endif
%  if groupCfg.gateway:
%    if groupCfg.vrf:
ip route vrf ${groupCfg.vrf} 0.0.0.0/0 ${groupCfg.gateway}
%    else:
ip route 0.0.0.0/0 ${groupCfg.gateway}
%    endif
%  endif
%endif
<%
    groupNum = stripSubInt(groupNum)
%>
!
interface Port-Channel ${stripSubInt(groupNum)}
%if groupCfg.enabled:
    no shutdown
%else:
    shutdown
%endif
%if groupCfg.bgpSessionTracker:
    bgp session tracker ${groupCfg.bgpSessionTracker}
%endif
%if groupCfg.l2ProtocolEncapVlan:
    l2-protocol encapsulation dot1q vlan ${groupCfg.l2ProtocolEncapVlan}
%endif
%if groupCfg.pcDescription and not (groupCfg.mode == "routed" and groupCfg.accessVlan):
    description ${groupCfg.pcDescription}
%endif
%if groupCfg.lacpFallback == "Individual":
    port-channel lacp fallback individual
%elif   groupCfg.lacpFallback == "Static":
    port-channel lacp fallback static
%endif
%if groupCfg.lacpFallbackTimeout:
    port-channel lacp fallback timeout ${groupCfg.lacpFallbackTimeout}
%endif
%if groupCfg.minLinks:
    port-channel min-links ${groupCfg.minLinks}
%endif
## LINK TRACKING
  %if groupCfg.linkTrackingGroup and groupCfg.linkTrackingDirection:
    link tracking group ${groupCfg.linkTrackingGroup} ${groupCfg.linkTrackingDirection}
  %endif
## VLANs
%if groupCfg.mlagEnabled == "enabled" and groupCfg.mode != 'routed':
    mlag ${groupNum}
%endif
%if groupCfg.mode == 'access':
    switchport
    switchport mode access
%  if groupCfg.accessVlan is not None:
    switchport access vlan ${groupCfg.accessVlan}
%  endif
## MULTI HOMING
    ${makeMultiHoming(groupCfg)}
%elif groupCfg.mode == 'l2-sub-interface':
%  if groupCfg.desc:
    description ${groupCfg.desc}
%  endif
    no switchport
    no switchport mode
%  if groupCfg.ipMtu:
    mtu ${groupCfg.ipMtu}
%  endif
## MULTI HOMING
    ${makeMultiHoming(groupCfg)}
%  if groupCfg.accessVlan:
interface Port-Channel ${groupNum}.${groupCfg.accessVlan}
%    if groupCfg.desc:
    description ${groupCfg.desc}
%    endif
%    if groupCfg.accessVlan:
    encapsulation dot1q vlan ${groupCfg.accessVlan}
    vlan id ${groupCfg.accessVlan}
%    endif
%    if not groupCfg.macAddressLearning:
    mac address learning disabled
%    endif
%    if groupCfg.shapeRate:
    shape rate ${groupCfg.shapeRate}
%    endif
%    if groupCfg.bandwidth:
    bandwidth guaranteed ${groupCfg.bandwidth}
%    endif
%    if groupCfg.bandwidthPercent:
    bandwidth guaranteed percent ${groupCfg.bandwidthPercent}
%    endif
%  endif
%elif groupCfg.mode == 'trunk':
    switchport
    switchport mode trunk
%    if groupCfg.nativeVlanId:
    switchport trunk native vlan ${groupCfg.nativeVlanId}
%    endif
%    if groupCfg.allowedVlans:
    switchport trunk allowed vlan ${groupCfg.allowedVlans}
%    endif
%  for vvlan in groupCfg.vlanTranslation:
%    if vvlan.direction == "Bi-Directional":
    switchport vlan translation ${vvlan.translatedVlan} ${vvlan.originalVlan}
%    elif vvlan.direction == "In":
    switchport vlan translation in ${vvlan.translatedVlan} ${vvlan.originalVlan}
%    elif vvlan.direction == "Out":
    switchport vlan translation out ${vvlan.translatedVlan} ${vvlan.originalVlan}
%    endif
%  endfor
## MULTI HOMING
    ${makeMultiHoming(groupCfg)}
%elif groupCfg.mode == 'routed':
    no switchport
    no switchport mode
%    if groupCfg.ipMtu:
    mtu ${groupCfg.ipMtu}
%    endif
%    if groupCfg.accessVlan:
!
interface Port-Channel ${groupNum}.${groupCfg.accessVlan}
    encapsulation dot1q vlan ${groupCfg.accessVlan}
%      if groupCfg.pcDescription:
    description ${groupCfg.pcDescription}
%      endif
%    endif
%    if groupCfg.vrf:
    vrf ${groupCfg.vrf}
%    endif
%    if groupCfg.ipaddress:
    ip address ${groupCfg.ipaddress}
%    endif
%    if groupCfg.ipv6address:
    ipv6 address ${groupCfg.ipv6address}
%    endif
%    for helper in groupCfg.helper:
%      if helper.sourceInterface:
    ip helper-address ${helper.helperAddress} source-interface ${helper.sourceInterface}
%      endif
%      if helper.vrf:
    ip helper-address ${helper.helperAddress} vrf ${helper.vrf}
%      endif
%      if not helper.sourceInterface and not helper.vrf:
    ip helper-address ${helper.helperAddress}
%      endif
%    endfor
%      if groupCfg.rpfMode == "loose-mode non-default":
    ip verify unicast source reachable-via any non-default
%      elif groupCfg.rpfMode == "loose-mode":
    ip verify unicast source reachable-via any
%      elif groupCfg.rpfMode == "strict-mode":
    ip verify unicast source reachable-via rx
%      endif
## MULTI HOMING
    ${makeMultiHoming(groupCfg)}
%elif groupCfg.mode == 'phone':
    switchport
    switchport mode trunk phone
%    if groupCfg.nativeVlanId:
    switchport trunk native vlan ${groupCfg.nativeVlanId}
%    endif
%    if groupCfg.phoneVlanId:
    switchport phone vlan ${groupCfg.phoneVlanId}
%    endif
%    if groupCfg.allowedVlans:
    switchport trunk allowed vlan ${groupCfg.allowedVlans}
%    endif
%endif
## QOS
%if groupCfg.qosInstance:
${makeQOS(groupCfg)}
%endif
## ACL
%if groupCfg.aclIn:
    ip access-group ${groupCfg.aclIn} in
%endif
%if groupCfg.aclOut:
    ip access-group ${groupCfg.aclOut} out
%endif
%if groupCfg.v6AclIn:
    ipv6 access-group ${groupCfg.v6AclIn} in
%endif
%if groupCfg.v6AclOut:
    ipv6 access-group ${groupCfg.v6AclOut} out
%endif
## IP Locking
%if groupCfg.ipLocking:
    address locking ipv6
%endif
## MAC Sec
%if groupCfg.macSecurity:
    mac security profile name
%endif
## Spanning Tree
%if groupCfg.portFastEnabled:
    spanning-tree portfast
%endif
%if groupCfg.rootGuardEnabled:
    spanning-tree guard root
%endif
%if groupCfg.bpduGuardEnabled:
    spanning-tree bpduguard enable
%endif
%if groupCfg.bpduFilterEnabled:
    spanning-tree bpdufilter enable
%endif
%if groupCfg.sflow:
    sflow ${groupCfg.sflow}
%endif
## Port Security
%if groupCfg.security and groupCfg.mode != "routed":
${makePortSecurity(groupCfg)}
%endif
## Storm Control
%if groupCfg.stormControl and groupCfg.mode != "routed":
${makeStormControl(groupCfg)}
%endif
## Logging
%if groupCfg.logging:
${makeLogging(groupCfg)}
%endif
## IGMP
%if groupCfg.igmpEnable:
${makeIGMP(groupCfg)}
%endif
## NAT
%if groupCfg.dynamicNat and groupCfg.mode == "routed":
  ${makeDynamicNat(groupCfg)}
%endif
%if groupCfg.staticNat and groupCfg.mode == "routed":
  ${makeStaticNat(groupCfg)}
%endif
## Multicast
%if groupCfg.mode == "routed":
    ${makeMulticast(groupCfg)}
%endif
## COMMAND LINE
%  if groupCfg.command:
    ${groupCfg.command}
%  endif
    exit
!
## Global Multicast
%if groupCfg.mode == "routed":
    ${makeGlobalMulticast(groupCfg)}
%endif

## Global NAT
%if groupCfg.dynamicNat:
${makeGlobalNat(groupCfg)}
%endif

## Global VLAN
%if groupCfg.mode == 'access':
%  if groupCfg.accessVlan is not None:
vlan ${groupCfg.accessVlan}
%    if groupCfg.vlanName:
    name ${groupCfg.vlanName}
    exit
%    endif
!
%  endif
%endif

## Global IGMP
%if groupCfg.igmpSnooping:
${makeGlobalIGMP(groupCfg)}
%endif
</%def>

## Global Vlans
<%def name="makeVlanCfg(vID, vlanCfg)">
vlan ${vID}
    state ${vlanCfg.state}
%if vlanCfg.vlanName:
    name ${vlanCfg.vlanName}
%endif
%if vlanCfg.ipLocking:
    address locking
%    if vlanCfg.ipLocking.interfaceIpLockingSettings.iPv4EnforcementDisable:
        locked-address ipv4 enforcement disabled
%    endif
%    if vlanCfg.ipLocking.interfaceIpLockingSettings.iPv6EnforcementDisable:
        locked-address ipv6 enforcement disabled
%    endif
%    if vlanCfg.ipLocking.interfaceIpLockingSettings.addressFamilyIPv4:
        address-family ipv4
%    endif
%    if vlanCfg.ipLocking.interfaceIpLockingSettings.addressFamilyIPv6:
        address-family ipv6
%    endif
        exit
%endif
%if vlanCfg.trunkGroup:
    trunk group ${vlanCfg.trunkGroup}
%endif
%if vlanCfg.trunkGroups:
%    for tGroup in vlanCfg.trunkGroups:
    trunk group ${tGroup }
%    endfor
%endif
%if vlanCfg.privateVlanType and vlanCfg.primaryVlan:
    private-vlan ${vlanCfg.privateVlanType} primary vlan ${vlanCfg.primaryVlan}
    exit
vlan ${vlanCfg.primaryVlan}
%endif
    exit
%if vlanCfg.disableSTP:
no spanning-tree vlan-id ${vID}
%endif
</%def>

## GLOBAL MULTICAST
<%def name="makeGlobalMulticast(intfCfg)">
%   if intfCfg.multicastGlobalCommands:
router multicast
%     if intfCfg.softwareForwardingSfe:
    ipv4
        software-forwarding sfe
%     endif
%     for vrf in intfCfg.multicastGlobalCommands:
%       if  vrf.vrf:
    vrf ${vrf.vrf}
%       endif
%       if vrf.ipProtocol == "both":
    ipv4
        routing
    ipv6
        routing
%       else:
  ${vrf.ipProtocol}
        routing
%       endif
  !
%     endfor
%   endif
</%def>

<%def name="makeMulticast(intfCfg)">
%   if intfCfg.multicastInterfaceCommands:
%      if intfCfg.multicastInterfaceCommands.ipProtocol == "ipv6" and intfCfg.multicastInterfaceCommands.type == "Boundary":
    multicast ipv6 boundary ${inftCfg.multicastInterfaceCommands.multicastAclName}
%      elif intfCfg.multicastInterfaceCommands.ipProtocol == "ipv4" and intfCfg.multicastInterfaceCommands.type == "Boundary":
    multicast ipv4 boundary ${intfCfg.multicastInterfaceCommands.multicastAclName}
%      elif intfCfg.multicastInterfaceCommands.ipProtocol == "ipv6" and intfCfg.multicastInterfaceCommands.type == "Source Route Export":
    multicast ipv6 source route export
%      elif intfCfg.multicastInterfaceCommands.ipProtocol == "ipv4" and intfCfg.multicastInterfaceCommands.type == "Source Route Export":
    multicast ipv4 source route export
%      endif
%   endif
%   if intfCfg.pimInterfaceCommands:
%     if intfCfg.pimInterfaceCommands.pimType == "both":
    pim ipv4 ${intfCfg.pimInterfaceCommands.pimMode}
    pim ipv6 ${intfCfg.pimInterfaceCommands.pimMode}
%      if intfCfg.pimInterfaceCommands.drPriority:
    pim ipv4 dr-priority ${intfCfg.pimInterfaceCommands.drPriority}
    pim ipv6 dr-priority ${intfCfg.pimInterfaceCommands.drPriority}
%      endif
%      elif intfCfg.pimInterfaceCommands.pimType == "ipv6":
    pim ipv6 ${intfCfg.pimInterfaceCommands.pimMode}
%        if intfCfg.pimInterfaceCommands.drPriority:
    pim ipv6 dr-priority ${intfCfg.pimInterfaceCommands.drPriority}
%        endif
%      elif intfCfg.pimInterfaceCommands.pimType == "ipv4":
    pim ipv4 ${intfCfg.pimInterfaceCommands.pimMode}
%        if intfCfg.pimInterfaceCommands.drPriority:
    pim ipv4 dr-priority ${intfCfg.pimInterfaceCommands.drPriority}
%        endif
%      endif
%      if intfCfg.pimInterfaceCommands.pimIPv4LocalInterface:
    pim ipv4 local-interface ${intfCfg.pimInterfaceCommands.pimIPv4LocalInterface}
%      endif
%    endif
</%def>

<%def name="makePTP(intfCfg)">
%  if intfCfg.ptpPorts.enable:
    ptp enable
%    if intfCfg.ptpPorts.announceInterval:
    ptp announce interval ${intfCfg.ptpPorts.announceInterval}
%    endif
%    if intfCfg.ptpPorts.role:
    ptp role ${intfCfg.ptpPorts.role}
%    endif
%    if not intfCfg.ptpPorts.errorCorrectionEncoding:
    no error-correction encoding
%    endif
%    if intfCfg.ptpPorts.delayReqInterval:
    ptp delay-req interval ${intfCfg.ptpPorts.delayReqInterval}
%    endif
%    if intfCfg.ptpPorts.ptpVlan:
    ptp vlan ${intfCfg.ptpPorts.ptpVlan}
%    endif
%    if intfCfg.ptpPorts.syncMessageInterval:
    ptp sync-message interval ${intfCfg.ptpPorts.syncMessageInterval}
%    endif
%  endif
</%def>

<%def name="makePoE(intfCfg)">
%if not intfCfg.poe.poeState:
    poe disabled
%endif
%if intfCfg.poe.linkDownAction  == "maintain":
    poe link down action maintain
%elif intfCfg.poe.linkDownAction  == "powerOff":
    poe link down action power-off
%endif
%if intfCfg.poe.poeWattsLimit:
    poe limit ${intfCfg.poe.poeWattsLimit} watts
%endif
%if intfCfg.poe.poeWattsLimitClass:
    poe limit class class${intfCfg.poe.poeWattsLimitClass}
%endif
%if intfCfg.poe.priority:
    poe priority ${intfCfg.poe.priority}
%endif
%if intfCfg.poe.poeNegotiationLldp == "enabled":
    poe negotiation lldp
%elif intfCfg.poe.poeNegotiationLldp == "disabled":
    poe negotiation lldp ${intfCfg.poe.poeNegotiationLldp}
%endif
%if intfCfg.poe.poeRebootAction == "maintain":
    poe reboot action ${intfCfg.poe.poeRebootAction}
%elif intfCfg.poe.poeRebootAction == "power-off":
    poe reboot action ${intfCfg.poe.poeRebootAction}
%endif
%if intfCfg.poe.poeShutdownAction == "maintain":
    poe shutdown action ${intfCfg.poe.poeShutdownAction}
%elif intfCfg.poe.poeShutdownAction == "power-off":
    poe shutdown action ${intfCfg.poe.poeShutdownAction}
%endif
%if intfCfg.poe.legacyDetect == "enabled":
    poe legacy detect
%endif
</%def>

<%def name="makeDot1x(intfCfg)">
    dot1x pae authenticator
    dot1x port-control ${intfCfg.dot1x.portControl}
%if intfCfg.dot1x.authenticationFailureAction == "drop":
    dot1x authentication failure action traffic ${intfCfg.dot1x.authenticationFailureAction}
%endif
%if intfCfg.dot1x.authenticationFailureAction == "allow":
    dot1x authentication failure action traffic ${intfCfg.dot1x.authenticationFailureAction} vlan ${intfCfg.dot1x.authenticationFailureActionAllowVlan}
%endif
%if intfCfg.dot1x.hostMode == "single-host":
    dot1x host-mode ${intfCfg.dot1x.hostMode}
%elif intfCfg.dot1x.hostMode == "multi-host":
    dot1x host-mode ${intfCfg.dot1x.hostMode}
%elif intfCfg.dot1x.hostMode == "multi-host authenticated":
    dot1x host-mode ${intfCfg.dot1x.hostMode}
%endif
%if intfCfg.dot1x.macBasedAuthentication == "enabled":
    dot1x mac based authentication
%elif intfCfg.dot1x.macBasedAuthentication == "host-mode-common":
    dot1x mac based authentication host-mode common
%endif
%if intfCfg.dot1x.eapol == "disable":
    dot1x eapol disabled
%endif]
%if intfCfg.dot1x.eapolAuthenticationFailureFallbackMba == "enabled":
    dot1x eapol authentication failure fallback mba
%endif
%if intfCfg.dot1x.unauthorizedAccessVlanMembershipEgress == "enabled":
    dot1x unauthorized access vlan membership egress
%endif
%if intfCfg.dot1x.unauthorizedNativeVlanMembershipEgress == "enabled":
    dot1x unauthorized native vlan membership egress
%endif
%if intfCfg.dot1x.reauthorizationRequestLimit:
    dot1x reauthorization request limit ${intfCfg.dot1x.reauthorizationRequestLimit}
%endif
%if intfCfg.dot1x.timeoutTxPeriod:
    dot1x timeout tx-period ${intfCfg.dot1x.timeoutTxPeriod}
%endif
%if intfCfg.dot1x.timeoutReauthTimeoutIgnore == "enabled":
    dot1x timeout reauth-timeout-ignore always
%endif
%if intfCfg.dot1x.timeoutReauthPeriod:
    dot1x timeout reauth-period ${intfCfg.dot1x.timeoutReauthPeriod}
%endif
%if intfCfg.dot1x.timeoutQuietPeriod:
    dot1x timeout quiet-period ${intfCfg.dot1x.timeoutQuietPeriod}
%endif
%if intfCfg.dot1x.reauthentication == "enabled":
    dot1x reauthentication
%endif
%if intfCfg.dot1x.idleHost:
    dot1x timeout idle-host ${intfCfg.dot1x.idleHost} seconds
%endif
</%def>

<%def name="makeQOS(intfCfg)">
    <% i = intfCfg.qosInstance %>
%  for qi in config_qos:
%      if i == qi:
%          if config_qos[qi].get("service_profiles"):
%              if vlanIntFound:
    service-profile ${intfCfg.qosInstance.service_profles}
%              else:
    <% sp = config_qos[qi].get("service_profiles")[0]["profileName"] %>
    service-profile ${sp}
%              endif
%          elif config_qos[qi].get("policy_maps"):
    <% pm = config_qos[qi].get("policy_maps")[0]["policyMapName"] %>
    <% pmType = config_qos[qi].get("policy_maps")[0]["type"] %>
    service-policy type ${pmType} input ${pm}
%          endif
%      endif
%  endfor
</%def>

<%def name="makePortSecurity(intfCfg)">
%if intfCfg.security.portSecurityViolations:
    switchport port-security
%  if intfCfg.security.portSecurityAllowedMacCount:
    switchport port-security mac-address maximum ${intfCfg.security.portSecurityAllowedMacCount}
%  endif
%  if intfCfg.security.portSecurityViolations == "protect":
    switchport port-security violation protect log
%  endif
%  if intfCfg.security.allowVlanId:
    switchport port-security vlan ${intfCfg.security.allowVlanId} mac-address maximum ${intfCfg.security.portSecurityAllowedMacCount}
%  endif
%  if intfCfg.security.portSecurityMacAddressMaximumDisabled:
    switchport port-security mac-address maximum disabled
%  endif
%endif
</%def>

<%def name="makeStormControl(intfCfg)">
%if intfCfg.stormControl.stormControlLevelAllValue:
%  if intfCfg.stormControl.stormControlLevelAllType == "level":
    storm-control all level ${intfCfg.stormControl.stormControlLevelAllValue}
%  elif intfCfg.stormControl.stormControlLevelAllType == "rate kbps":
    storm-control all level rate ${intfCfg.stormControl.stormControlLevelAllValue} kbps
%  elif intfCfg.stormControl.stormControlLevelAllType == "rate mbps":
    storm-control all level rate ${intfCfg.stormControl.stormControlLevelAllValue} mbps
%  elif intfCfg.stormControl.stormControlLevelAllType == "rate gbps":
    storm-control all level rate ${intfCfg.stormControl.stormControlLevelAllValue} gbps
%  elif intfCfg.stormControl.stormControlLevelAllType == "pps":
    storm-control all level ${intfCfg.stormControl.stormControlLevelAllType} ${intfCfg.stormControl.stormControlLevelAllValue}
%  endif
%endif
%if intfCfg.stormControl.stormControlBroadcastValue:
%  if intfCfg.stormControl.stormControlBroadcastType == "level":
    storm-control broadcast level ${intfCfg.stormControl.stormControlBroadcastValue}
%  elif intfCfg.stormControl.stormControlBroadcastType == "rate kbps":
    storm-control broadcast level rate ${intfCfg.stormControl.stormControlBroadcastValue} kbps
%  elif intfCfg.stormControl.stormControlBroadcastType == "rate mbps":
    storm-control broadcast level rate ${intfCfg.stormControl.stormControlBroadcastValue} mbps
%  elif intfCfg.stormControl.stormControlBroadcastType == "rate gbps":
    storm-control broadcast level rate ${intfCfg.stormControl.stormControlBroadcastValue} gbps
%  elif intfCfg.stormControl.stormControlBroadcastType == "pps":
    storm-control broadcast level ${intfCfg.stormControl.stormControlBroadcastType} ${intfCfg.stormControl.stormControlBroadcastValue}
%  endif
%endif
%if intfCfg.stormControl.stormControlMulticastValue:
%  if intfCfg.stormControl.stormControlMulticastType == "level":
    storm-control multicast level ${intfCfg.stormControl.stormControlMulticastValue}
%  elif intfCfg.stormControl.stormControlMulticastType == "rate kbps":
    storm-control multicast level rate ${intfCfg.stormControl.stormControlMulticastValue} kbps
%  elif intfCfg.stormControl.stormControlMulticastType == "rate mbps":
    storm-control multicast level rate ${intfCfg.stormControl.stormControlMulticastValue} mbps
%  elif intfCfg.stormControl.stormControlMulticastType == "rate gbps":
    storm-control multicast level rate ${intfCfg.stormControl.stormControlMulticastValue} gbps
%  elif intfCfg.stormControl.stormControlMulticastType == "pps":
    storm-control multicast level ${intfCfg.stormControl.stormControlMulticastType} ${intfCfg.stormControl.stormControlMulticastValue}
%  endif
%endif
%if intfCfg.stormControl.stormControlUnknownUnicastValue:
%  if intfCfg.stormControl.stormControlUnknownUnicastType == "level":
    storm-control unknown-unicast level ${intfCfg.stormControl.stormControlUnknownUnicastValue}
%  elif intfCfg.stormControl.stormControlUnknownUnicastType == "rate kbps":
    storm-control unknown-unicast level rate ${intfCfg.stormControl.stormControlUnknownUnicastValue} kbps
%  elif intfCfg.stormControl.stormControlUnknownUnicastType == "rate mbps":
    storm-control unknown-unicast level rate ${intfCfg.stormControl.stormControlUnknownUnicastValue} mbps
%  elif intfCfg.stormControl.stormControlUnknownUnicastType == "rate gbps":
    storm-control unknown-unicast level rate ${intfCfg.stormControl.stormControlUnknownUnicastValue} gbps
%  elif intfCfg.stormControl.stormControlUnknownUnicastType == "pps":
    storm-control unknown-unicast level ${intfCfg.stormControl.stormControlUnknownUnicastType} ${intfCfg.stormControl.stormControlUnknownUnicastValue}
%  endif
%endif
</%def>

<%def name="makeLogging(intfCfg)">
%if intfCfg.logging.congestionDrops == "enabled":
    logging event congestion-drops
%endif
%if intfCfg.logging.congestionDrops == "use-global":
    logging event congestion-drops use-global
%endif
%if intfCfg.logging.linkStatus == "enabled":
    logging event link-status
%endif
%if intfCfg.logging.linkStatus == "use-global":
    logging event link-status use-global
%endif
%if intfCfg.logging.spanningTree == "enabled":
    logging event spanning-tree
%endif
%if intfCfg.logging.spanningTree == "use-global":
    logging event spanning-tree use-global
%endif
%if intfCfg.logging.stormControl == "enabled":
    logging event storm-control discards
%endif
%if intfCfg.logging.stormControl == "use-global":
    logging event storm-control discards use-global
%endif
</%def>

<%def name="makeMultiHoming(intfCfg)">
%  if intfCfg.esi != None:
    evpn ethernet-segment
        identifier ${intfCfg.esi}
        route-target import ${intfCfg.ethernetSegmentRouteTarget}
%      if intfCfg.mplsSharedIndex:
        mpls shared index ${intfCfg.mplsSharedIndex}
%      endif
%      if intfCfg.redundancyMode == "all-active":
        redundancy ${intfCfg.redundancyMode}
%      elif intfCfg.redundancyMode == "single-active":
        redundancy ${intfCfg.redundancyMode}
        designated-forwarder election algorithm preference ${intfCfg.dfPref}
%      endif
        exit
%       if intfCfg.lacpEnabled == "enabled":
    lacp system-id ${intfCfg.lacpSysId}
%      endif
%  endif
</%def>

## Global PTP
<%def name="makeGlobalPTP(intfCfg)">
%if intfCfg.ptpGlobalCommands.monitorThresholdOffsetFromMaster:
ptp monitor threshold offset-from-master ${intfCfg.ptpGlobalCommands.monitorThresholdOffsetFromMaster}
%endif
%if intfCfg.ptpGlobalCommands.mode:
ptp mode ${intfCfg.ptpGlobalCommands.mode}
%endif
%if intfCfg.ptpGlobalCommands.priority1:
ptp priority1 ${intfCfg.ptpGlobalCommands.priority1}
%endif
%if intfCfg.ptpGlobalCommands.priority2:
ptp priority2 ${intfCfg.ptpGlobalCommands.priority2}
%endif
%if intfCfg.ptpGlobalCommands.sourceIp:
ptp source ip ${intfCfg.ptpGlobalCommands.sourceIp}
%elif intfCfg.ptpGlobalCommands.deriveSourceIpFromLo0Tag:
<% ptpSourceIp = get_loopback0_tag()%>
ptp source ip ${ptpSourceIp}
%endif
%if intfCfg.ptpGlobalCommands.domain:
ptp domain ${intfCfg.ptpGlobalCommands.domain}
%endif
</%def>

<%def name="makeIGMP(intfCfg)">
% if intfCfg.igmpEnable:
    ip igmp
% endif
% if intfCfg.igmpPortSettings.igmpVersion:
    ip igmp version ${intfCfg.igmpPortSettings.igmpVersion}
% endif
% if intfCfg.igmpPortSettings.lastMemberQueryInterval:
    ip igmp last-member-query-interval ${intfCfg.igmpPortSettings.lastMemberQueryInterval}
% endif
% if intfCfg.igmpPortSettings.lastMemberQueryCount:
    ip igmp last-member-query-count ${intfCfg.igmpPortSettings.lastMemberQueryCount}
% endif
% if intfCfg.igmpPortSettings.startupQueryInterval:
    ip igmp startup-query-interval ${intfCfg.igmpPortSettings.startupQueryInterval}
% endif
% if intfCfg.igmpPortSettings.startupQueryCount:
    ip igmp startup-query-count ${intfCfg.igmpPortSettings.startupQueryCount}
% endif
% if intfCfg.igmpPortSettings.queryInterval:
    ip igmp query-interval ${intfCfg.igmpPortSettings.queryInterval}
% endif
% if intfCfg.igmpPortSettings.queryMaxResponseTime:
    igmp query-max-response-time ${intfCfg.igmpPortSettings.queryMaxResponseTime}
% endif
% if intfCfg.igmpStaticGroups:
%   for staticGroup in intfCfg.igmpStaticGroups:
    ip igmp static-group ${staticGroup.mulicastGroup} ${staticGroup.source}
%   endfor
% endif
</%def>

## GLOBAL IGMP
<%def name="makeGlobalIGMP(intfCfg)">
%if not intfCfg.igmpSnooping.enable:
no ip igmp snooping
%endif
%if intfCfg.igmpSnooping.enable and intfCfg.igmpSnooping.disableIgmpSnoopingForVlaNs:
no ip igmp snooping vlan ${intfCfg.igmpSnooping.disableIgmpSnoopingForVlaNs}
%endif
</%def>

<%def name="makeDynamicNat(intfCfg)">
%for intfCfg in intfCfg.dynamicNat:
<%
    nat_cli = f'ip nat {intfCfg.natType} dynamic'
    nat_cli = nat_cli + f' access-list {intfCfg.acl}'
    if intfCfg.overloadOrPool == "overload":
        nat_cli = nat_cli + f' {intfCfg.overloadOrPool}'
    elif intfCfg.overloadOrPool == "pool":
        nat_cli = nat_cli + f' pool {intfCfg.ipNatPoolName}'
        if intfCfg.addressOnlyFullCone:
            nat_cli = nat_cli + f' {intfCfg.addressOnlyFullCone}'
    if intfCfg.priority:
        nat_cli = nat_cli + f' {intfCfg.priority}'
    if intfCfg.comment:
        nat_cli = nat_cli + f' comment {intfCfg.comment}'
%>
    ${nat_cli}
%endfor
</%def>

<%def name="makeStaticNat(intfCfg)">
%for intfCfg in intfCfg.staticNat:
<%
    nat_cli = f'ip nat {intfCfg.staticNatType} static'
    nat_cli = nat_cli + f' {intfCfg.originalIpAddress}'
    if intfCfg.translatedIpAddress:
        if intfCfg.acl:
            nat_cli = nat_cli + f' access-list {intfCfg.acl}'
        nat_cli = nat_cli + f' {intfCfg.translatedIpAddress}'
        if  intfCfg.port:
            nat_cli = nat_cli + f' {intfCfg.port}'
        if intfCfg.protocol:
            nat_cli = nat_cli + f' {intfCfg.protocol}'
        if intfCfg.comment:
            nat_cli = nat_cli + f' comment {intfCfg.comment}'
%>
    ${nat_cli}
%endfor
</%def>

## GLOBAL NAT
<%def name="makeGlobalNat(intfCfg)">
%for intfCfg in intfCfg.dynamicNat:
%    if intfCfg.overloadOrPool == "pool":
ip nat pool ${intfCfg.ipNatPoolName} prefix-length ${intfCfg.prefixLength}
   range ${intfCfg.natPoolLowerRange} ${intfCfg.natPoolUpperRange}
   exit
!
%    endif
%endfor
</%def>

## Mako Mainline start
##
## Global Configurations on Devices
##

## ACL Devices
%if config_acls:
%    for acl in config_acls:
%        if config_acls[acl].get("aclStandardOrExtended") == "extended":
${config_acls[acl].get("type")} access-list ${config_acls[acl].get("name")}
%            if config_acls[acl].get("counters_per_entry"):
    counters per-entry
%            endif
%            for line in config_acls[acl]["acl_lines"]:
%                if line.permitDenyRemark != "remark":
%                    if line.log and not line.nextHopGroup:
    ${line.seqNumber} ${line.permitDenyRemark} ${line.protocol} ${line.source} ${line.destination} log
%                    elif line.log and line.nextHopGroup:
    ${line.seqNumber} ${line.permitDenyRemark} ${line.protocol} ${line.source} ${line.destination} nexthop-group ${line.nextHopGroup} log
%                    elif line.tracked and not line.nextHopGroup:
    ${line.seqNumber} ${line.permitDenyRemark} ${line.protocol} ${line.source} ${line.destination} tracked
%                    elif line.tracked and line.nextHopGroup:
    ${line.seqNumber} ${line.permitDenyRemark} ${line.protocol} ${line.source} ${line.destination} nexthop-group ${line.nextHopGroup} tracked
%                    elif line.nextHopGroup:
    ${line.seqNumber} ${line.permitDenyRemark} ${line.protocol} ${line.source} ${line.destination} nexthop-group ${line.nextHopGroup}
%                    else:
    ${line.seqNumber} ${line.permitDenyRemark} ${line.protocol} ${line.source} ${line.destination}
%                    endif
%                else:
    ${line.seqNumber} ${line.permitDenyRemark} ${line.description}
%                endif
%            endfor
    exit
%        elif config_acls[acl].get("aclStandardOrExtended") == "standard":
${config_acls[acl].get("type")} access-list standard ${config_acls[acl].get("name")}
%            if config_acls[acl].get("counters_per_entry"):
    counters per-entry
%            endif
%            for line in config_acls[acl]["acl_lines"]:
%                if line.permitDenyRemark != "remark":
%                    if line.log:
    ${line.seqNumber} ${line.permitDenyRemark} ${line.source} log
%                    else:
    ${line.seqNumber} ${line.permitDenyRemark} ${line.source}
%                    endif
%                else:
    ${line.seqNumber} ${line.permitDenyRemark} ${line.description}
%                endif
%            endfor
    exit
%        endif
!
%        if config_acls[acl]["devices"].resolve()["interfaces"]["controlPlaneAcl"]:
system control-plane
    ${config_acls[acl].get("type")} access-group ${config_acls[acl].get("name")} in
## When vlan interfaces get ACL support this section can be enabled
##%        else:
##%            for interface in config_acls[acl]["devices"].resolve()["interfaces"]["vlanInterfaces"]:
##interface vlan${interface.vlanId}
##%                if interface.direction == "in":
##    ${config_acls[acl].get("type")} access-group ${config_acls[acl].get("name")} in
##    !
##%                else:
##    ${config_acls[acl].get("type")} access-group ${config_acls[acl].get("name")} out
##    !
##%                endif
##%            endfor
##%            for interface in config_acls[acl]["devices"].resolve()["interfaces"]["physicalAndSubInterfaces"]:
##interface ${interface.interfaceName}
##%                if not interface.direction == "in":
##    ${config_acls[acl].get("type")} access-group ${config_acls[acl].get("name")} in
##    !
##%                else:
##    ${config_acls[acl].get("type")} access-group ${config_acls[acl].get("name")} out
##    !
##%                endif
##%            endfor
%        endif
%    endfor
%endif

## QOS
%if config_qos:
%    for qos in config_qos:
%        if config_qos[qos].get("nextHopGroups"):
%            for nhg in config_qos[qos]["nextHopGroups"]:
!
nexthop-group ${nhg.nextHopGroupName} type ${nhg.nextHopGroupType}
%                for entry in nhg["nextHopGroupEntries"]:
    entry ${entry.entryNum} nexthop ${entry.nextHopIp}
%                endfor
%            endfor
    exit
%        endif
!
##       QOS Devices
%        if config_qos[qos]["devices"].resolve()["deviceGroup"]["interfaces"]:
%            for interface in config_qos[qos]["devices"].resolve()["deviceGroup"]["interfaces"]:
interface ${interface.interfaceName}
%                for queue in interface["txQueue"]:
    tx-queue ${queue.queue}
%                    if not queue.priorityStrict:
        no priority
%                    endif
%                    if queue.bandwidthType:
%                        if queue.bandwidthType == "guaranteed":
        bandwidth ${queue.bandwidthType} ${queue.bandwidth}
%                        elif queue.bandwidthType == "percent":
        bandwidth ${queue.bandwidthType} ${queue.bandwidth}
%                        endif
%                    endif
%                    if queue.shapeRate:
        shape rate ${queue.shapeRate}
%                    endif
%                    if queue.randomDetectType == "drop":
        random-detect ${queue.randomDetectType} minimum-threshold ${queue.rdMinThreshold} ${queue.minThresholdMetric} maximum-threshold ${queue.rdMaxThreshold} ${queue.minThresholdMetric} drop-probability ${queue.dropProbability}
%                    elif queue.randomDetectType == "ecn":
        random-detect ${queue.randomDetectType} minimum-threshold ${queue.rdMinThreshold} ${queue.minThresholdMetric} maximum-threshold ${queue.rdMaxThreshold} ${queue.minThresholdMetric}
%                    elif queue.randomDetectType == "non-ect":
        random-detect ${queue.randomDetectType} minimum-threshold ${queue.rdMinThreshold} ${queue.minThresholdMetric} maximum-threshold ${queue.rdMaxThreshold} ${queue.minThresholdMetric}
%                    endif
%                endfor
%                if interface.servicePolicyName and interface.servicePolicyType == "qos":
    service-policy type ${interface.servicePolicyType} ${interface.policyMapInputOutput} ${interface.servicePolicyName}
%                elif interface.servicePolicyName and interface.servicePolicyType == "pbr":
    service-policy type ${interface.servicePolicyType} input ${interface.servicePolicyName}
%                elif interface.serviceProfile:
    service-profile ${interface.serviceProfile}
%                endif
%                if interface.shapeRate:
    shape rate ${interface.shapeRate}
%                endif
%                if interface.trust == "dscp" or interface.trust == "cos" :
    qos trust ${interface.trust}
%                endif
%                if interface.dscp:
    qos dscp ${interface.dscp}
%                endif
%                if interface.cos:
    qos cos ${interface.cos}
%                endif
%                if interface.policerRate and interface.policerBurstSize:
    policer profile policer-${qos}-${interface.policerRate}-${interface.policerBurstSize} input
%                endif
    exit
!
%                if interface.policerRate and interface.policerBurstSize:
policing
    profile policer-${qos}-${interface.policerRate}-${interface.policerBurstSize} rate ${interface.policerRate} mbps burst-size ${interface.policerBurstSize} bytes
    exit
%                 endif
%            endfor
!
%        endif
##       Class Maps
%        if config_qos[qos].get("policy_maps"):
%            for policy_map in config_qos[qos]["policy_maps"]:
%                for pmclass_map in policy_map["policyMapclassMaps"]:
%                    for class_map in config_qos[qos]["class_maps"]:
%                        if pmclass_map["pmclassMap"] == class_map["classMapName"]:
class-map type ${class_map.type} match-any ${class_map.classMapName}
%                           if class_map.matchValue:
    match ${class_map.match} ${class_map.matchValue}
%                           endif
%                           if class_map.acl:
    match ${class_map.match} access-group ${class_map.acl}
%                           endif
%                        endif
    exit
%                    endfor
!
%                 endfor
%                for pbr in policy_map["pbr"]:
%                  if pbr["classMap"]:
%                    for class_map in config_qos[qos]["class_maps"]:
%                        if pbr["classMap"] == class_map["classMapName"]:
class-map type ${class_map.type} match-any ${class_map.classMapName}
%                           if class_map.matchValue:
    match ${class_map.match} ${class_map.matchValue}
%                           endif
%                           if class_map.acl:
    match ${class_map.match} access-group ${class_map.acl}
%                           endif
%                        endif
    exit
%                    endfor
!
%                   endif
%                 endfor
%             endfor
%         endif
##       Policy Maps
%        if config_qos[qos].get("policy_maps"):
%        for policy_map in config_qos[qos]["policy_maps"]:
%            if policy_map.type == "qos":
policy-map type quality-of-service ${policy_map.policyMapName}
%                if policy_map.classDefault:
    class class-default
        set traffic-class ${policy_map.classDefault}
        exit
%                endif
%                for class_map in policy_map["policyMapclassMaps"]:
    class ${class_map.pmclassMap}
%                    if class_map.classMapSettings.trafficClass:
        set traffic-class ${class_map.classMapSettings.trafficClass}
%                    endif
%                    if class_map.classMapSettings.cos:
        set cos ${class_map.classMapSettings.cos}
%                    endif
%                    if class_map.classMapSettings.dscp:
        set dscp ${class_map.classMapSettings.dscp}
%                    endif
%                    if class_map.classMapSettings.dropPrecedence:
        set drop-precedence ${class_map.classMapSettings.dropPrecedence}
%                    endif
%                    if class_map.classMapSettings.drop:
        drop
%                    endif
%                    if class_map.classMapSettings.policerCir and not class_map.classMapSettings.policerBc:
        police cir ${class_map.classMapSettings.policerCir}
%                    endif
%                    if class_map.classMapSettings.policerBc:
        police cir ${class_map.classMapSettings.policerCir} bc ${class_map.classMapSettings.policerBc}
%                    endif
%                    if class_map.classMapSettings.policerRate and not class_map.classMapSettings.policerBurstSize:
        police rate ${class_map.classMapSettings.policerRate}
%                    endif
%                    if class_map.classMapSettings.policerBurstSize:
        police rate ${class_map.classMapSettings.policerRate} burst-size ${class_map.classMapSettings.policerBurstSize}
%                    endif
%                endfor
        exit
%            elif policy_map.type == "policer":
policy-map type quality-of-service policer
%                if policy_map.classDefault:
    class class-default
        set traffic-class ${policy_map.classDefault}
        exit
%                endif
%                for class_map in policy_map["policyMapclassMaps"]:
    class ${class_map.pmclassMap}
%                    if class_map.classMapSettings.trafficClass:
        set traffic-class ${class_map.classMapSettings.trafficClass}
%                    endif
%                    if class_map.classMapSettings.cos:
        set cos ${class_map.classMapSettings.cos}
%                    endif
%                    if class_map.classMapSettings.dscp:
        set dscp ${class_map.classMapSettings.dscp}
%                    endif
%                    if class_map.classMapSettings.dropPrecedence:
        set drop-precedence ${class_map.classMapSettings.dropPrecedence}
%                    endif
%                    if class_map.classMapSettings.drop:
        drop
%                    endif
%                    if class_map.classMapSettings.policerCir and not class_map.classMapSettings.policerBc:
        police cir ${class_map.classMapSettings.policerCir}
%                    endif
%                    if class_map.classMapSettings.policerBc:
        police cir ${class_map.classMapSettings.policerCir} bc ${class_map.classMapSettings.policerBc}
%                    endif
%                    if class_map.classMapSettings.policerRate and not class_map.classMapSettings.policerBurstSize:
        police rate ${class_map.classMapSettings.policerRate}
%                    endif
%                    if class_map.classMapSettings.policerBurstSize:
        police rate ${class_map.classMapSettings.policerRate} burst-size ${class_map.classMapSettings.policerBurstSize}
%                    endif
%                endfor
        exit
%            elif policy_map.type == "copp":
policy-map type copp copp-system-policy
%                if policy_map.classDefault:
    class class-default
        set traffic-class ${policy_map.classDefault}
        exit
%                endif
%                for class_map in policy_map["policyMapclassMaps"]:
    class ${class_map.pmclassMap}
%                    if class_map.classMapSettings.bandwidth:
        bandwidth pps ${class_map.classMapSettings.bandwidth}
%                    endif
%                    if class_map.classMapSettings.shapeRate:
        shape pps ${class_map.classMapSettings.shapeRate}
%                    endif
%                endfor
        exit
%            elif policy_map.type == "pbr":
policy-map type pbr ${policy_map.policyMapName}
%                for class_map in policy_map["policyMapclassMaps"]:
    class ${class_map.pmclassMap}
%                    if class_map.classMapSettings.drop:
        drop
%                    endif
%                    if class_map.classMapSettings.nextHopIp and class_map.classMapSettings.nextHopVrf:
        set nexthop ${class_map.classMapSettings.nextHopIp} vrf ${class_map.classMapSettings.nextHopVrf}
%                    elif class_map.classMapSettings.nextHopIp and not class_map.classMapSettings.nextHopVrf:
        set nexthop ${class_map.classMapSettings.nextHopIp}
%                    endif
%                    if class_map.classMapSettings.nextHopGroup:
        nexthop-group ${class_map.classMapSettings.nextHopGroup} type ${class_map.classMapSettings.nextHopGroupType}
%                    endif
%                endfor
%                for pbr_line in policy_map["pbr"]:
%                    if pbr_line.match == "ip" or pbr_line.match == "ipv6":
%                        if not pbr_line.nextHopGroup and pbr_line.nextHopIp:
%                            if pbr_line.nextHopVrf:
    ${pbr_line.seqNumber} match ${pbr_line.match} ${pbr_line.matchSource} ${pbr_line.matchDestination} set nexthop ${pbr_line.nextHopIp} vrf ${pbr_line.nextHopVrf}
%                            else:
    ${pbr_line.seqNumber} match ${pbr_line.match} ${pbr_line.matchSource} ${pbr_line.matchDestination} set nexthop ${pbr_line.nextHopIp}
%                            endif
%                        elif pbr_line.nextHopGroup and not pbr_line.nextHopIp:
%                            if pbr_line.nextHopVrf:
    ${pbr_line.seqNumber} match ${pbr_line.match} ${pbr_line.matchSource} ${pbr_line.matchDestination} set nexthop-group ${pbr_line.nextHopGroup} vrf ${pbr_line.nextHopVrf}
%                            else:
    ${pbr_line.seqNumber} match ${pbr_line.match} ${pbr_line.matchSource} ${pbr_line.matchDestination} set nexthop-group ${pbr_line.nextHopGroup}
%                            endif
%                        endif
%                    elif pbr_line.match == "vlan match ip":
%                        if pbr_line.nextHopGroup and not pbr_line.nextHopIp:
%                            if pbr_line.nextHopVrf:
    ${pbr_line.seqNumber} match vlan ${pbr_line.vlanId} ${pbr_line.vlanMask} ip ${pbr_line.matchSource} ${pbr_line.matchDestination} set nexthop-group ${pbr_line.nextHopGroup} set nexthop ${pbr_line.nextHopIp} vrf ${pbr_line.nextHopVrf}
%                            else:
    ${pbr_line.seqNumber} match vlan ${pbr_line.vlanId} ${pbr_line.vlanMask} ip ${pbr_line.matchSource} ${pbr_line.matchDestination} set nexthop-group ${pbr_line.nextHopGroup} set nexthop ${pbr_line.nextHopIp}
%                            endif
%                        elif not pbr_line.nextHopGroup and pbr_line.nextHopIp:
%                            if pbr_line.nextHopVrf:
    ${pbr_line.seqNumber} match vlan ${pbr_line.vlanId} ${pbr_line.vlanMask} ip ${pbr_line.matchSource} ${pbr_line.matchDestination} set nexthop ${pbr_line.nextHopIp} vrf ${pbr_line.nextHopVrf}
%                            else:
    ${pbr_line.seqNumber} match vlan ${pbr_line.vlanId} ${pbr_line.vlanMask} ip ${pbr_line.matchSource} ${pbr_line.matchDestination} set nexthop ${pbr_line.nextHopIp}
%                            endif
%                        endif
%                    elif pbr_line.match == "vlan match ipv6":
%                        if pbr_line.nextHopGroup and not pbr_line.nextHopIp:
%                            if pbr_line.nextHopVrf:
    ${pbr_line.seqNumber} match vlan ${pbr_line.vlanId} ${pbr_line.vlanMask} ipv6 ${pbr_line.matchSource} ${pbr_line.matchDestination} set nexthop-group ${pbr_line.nextHopGroup} set nexthop ${pbr_line.nextHopIp} vrf ${pbr_line.nextHopVrf}
%                            else:
    ${pbr_line.seqNumber} match vlan ${pbr_line.vlanId} ${pbr_line.vlanMask} ipv6 ${pbr_line.matchSource} ${pbr_line.matchDestination} set nexthop-group ${pbr_line.nextHopGroup} set nexthop ${pbr_line.nextHopIp}
%                            endif
%                        elif not pbr_line.nextHopGroup and pbr_line.nextHopIp:
%                            if pbr_line.nextHopVrf:
    ${pbr_line.seqNumber} match vlan ${pbr_line.vlanId} ${pbr_line.vlanMask} ipv6 ${pbr_line.matchSource} ${pbr_line.matchDestination} set nexthop ${pbr_line.nextHopIp} vrf ${pbr_line.nextHopVrf}
%                            else:
    ${pbr_line.seqNumber} match vlan ${pbr_line.vlanId} ${pbr_line.vlanMask} ipv6 ${pbr_line.matchSource} ${pbr_line.matchDestination} set nexthop ${pbr_line.nextHopIp}
%                            endif
%                        endif
%                    elif pbr_line.classMap:
%                        if not pbr_line.nextHopGroup and pbr_line.nextHopIp:
%                            if pbr_line.nextHopVrf:
    ${pbr_line.seqNumber} class ${pbr_line.classMap}
        set nexthop ${pbr_line.nextHopIp} vrf ${pbr_line.nextHopVrf}
        exit
%                            else:
    ${pbr_line.seqNumber} class ${pbr_line.classMap}
        set nexthop ${pbr_line.nextHopIp}
%                            endif
%                        elif pbr_line.nextHopGroup and not pbr_line.nextHopIp:
%                            if pbr_line.nextHopVrf:
    ${pbr_line.seqNumber} class ${pbr_line.classMap}
        set nexthop-group ${pbr_line.nextHopGroup} vrf ${pbr_line.nextHopVrf}
        exit
%                            else:
    ${pbr_line.seqNumber} class ${pbr_line.classMap}
        set nexthop-group ${pbr_line.nextHopGroup}
        exit
%                            endif
%                        endif
%                    endif
!
%                endfor
%            endif
%        endfor
    exit
!
%        endif
##       QOS Profiles
%        if config_qos[qos].get("service_profiles"):
%            for profile in config_qos[qos]["service_profiles"]:
qos profile ${profile.profileName}
%                if profile.policyMap:
    service-policy type qos input ${profile.policyMap}
%            endif
%                if profile.shapeRate:
    shape rate ${profile.shapeRate}
%                endif
%                if profile.cos:
    qos cos ${profile.cos}
%                endif
%                if profile.dscp:
    qos dscp ${profile.dscp}
%                endif
%                if profile.trust == "cos" or profile.trust == "dscp":
    qos trust ${profile.trust}
%                endif
%                for queue in profile["txQueue"]:
    tx-queue ${queue.queue}
%                    if not queue.priorityStrict:
        no priority
%                    endif
%                    if queue.dropPrecedence:
        drop-precedence ${queue.dropPrecedence} drop-threshold percent ${queue.dropPrecedencePercent}
%                    endif
%                    if queue.bandwidthType:
%                        if queue.bandwidthType == "guaranteed":
        bandwidth ${queue.bandwidthType} ${queue.bandwidth}
%                        elif queue.bandwidthType == "percent":
        bandwidth ${queue.bandwidthType} ${queue.bandwidth}
%                        endif
%                    endif
%                    if queue.shapeRate:
        shape rate ${queue.shapeRate}
%                    endif
%                    if queue.randomDetectType == "drop":
        random-detect ${queue.randomDetectType} minimum-threshold ${queue.rdMinThreshold} ${queue.minThresholdMetric} maximum-threshold ${queue.rdMaxThreshold} ${queue.minThresholdMetric} drop-probability ${queue.dropProbability}
%                    elif queue.randomDetectType == "ecn":
        random-detect ${queue.randomDetectType} minimum-threshold ${queue.rdMinThreshold} ${queue.minThresholdMetric} maximum-threshold ${queue.rdMaxThreshold} ${queue.minThresholdMetric}
%                    elif queue.randomDetectType == "non-ect":
        random-detect ${queue.randomDetectType} minimum-threshold ${queue.rdMinThreshold} ${queue.minThresholdMetric} maximum-threshold ${queue.rdMaxThreshold} ${queue.minThresholdMetric}
%                    endif
%                endfor
        exit
    exit
%            endfor
!
%        endif
##       QOS Map Classification
%        if config_qos[qos].get("classification"):
%            for rule in config_qos[qos]["classification"]:
qos map ${rule.type} ${rule.classifierValues} to traffic-class ${rule.trafficClass}
%            endfor
!
%        endif
##       QOS Rewrite
%        if config_qos[qos].get("rewrite_rules"):
%            for rule in config_qos[qos]["rewrite_rules"]:
qos rewrite ${rule.rewriteType}
%            endfor
!
%        endif
##       QOS Map Traffic Class
%        if config_qos[qos].get("traffic_cl_to_q"):
%            for rule in config_qos[qos]["traffic_cl_to_q"]:
%                if rule.queue:
qos map traffic-class ${rule.trafficClass} to tx-queue ${rule.queue}
%                endif
%                if rule.cos:
qos map traffic-class ${rule.trafficClass} to cos ${rule.cos}
%                endif
%                if rule.dscp:
qos map traffic-class ${rule.trafficClass} to dscp ${rule.dscp}
%                endif
%            endfor
!
%        endif
%    endfor
%endif

## IP Locking
%if config_ipl:
%    for ipl in config_ipl:
%       if config_ipl[ipl].get("enabled") != "none":
address locking
%           if config_ipl[ipl].get("localInterface"):
    local-interface ${config_ipl[ipl].get("localInterface")}
%           endif
%           for dhcp_server in config_ipl[ipl]["dhcpServers"]:
%               if dhcp_server.ipProtocol == "ipv4":
    dhcp server ipv4 ${dhcp_server.dhcpServer}
%               endif
%               if dhcp_server.ipProtocol == "ipv6":
    dhcp server ipv6 ${dhcp_server.dhcpServer}
%               endif
%           endfor
%           if config_ipl[ipl].get("enabled") == "disabled":
    disabled
%           endif
%           for line in config_ipl[ipl]["leaseIpAndMac"]:
    lease ${line["leaseIp"]} mac ${line["leaseMac"]}
%           endfor
%           if config_ipl[ipl].get("lockedAddressExpirationMacDisabled"):
    locked-address expiration mac disabled
%           endif
%           if config_ipl[ipl].get("lockedIPv6AddressExpirationMacDisabled"):
    locked-address ipv6 expiration mac disabled
%           endif
%           if config_ipl[ipl].get("lockedAddressIPv4EnforcementDisabled"):
    locked-address ipv4 enforcement disabled
%           endif
%           if config_ipl[ipl].get("lockedAddressIPv6EnforcementDisabled"):
    locked-address ipv6 enforcement disabled
%           endif
    exit
!
%       endif
%   endfor
%endif

## IP Sec
%if config_ipSec:
%    for ipSec in config_ipSec:
ip security
%       if config_ipSec[ipSec].get("ikePolicyName"):
    ike policy ${config_ipSec[ipSec].get("ikePolicyName")}
%       endif
%       if config_ipSec[ipSec].get("encryption"):
        encryption ${config_ipSec[ipSec].get("encryption")}
%       endif
%       if config_ipSec[ipSec].get("integrity"):
        encryption ${config_ipSec[ipSec].get("integrity")}
%       endif
%       if config_ipSec[ipSec].get("version"):
        version ${config_ipSec[ipSec].get("version")}
%       endif
%       if config_ipSec[ipSec].get("dhGroup"):
        ${config_ipSec[ipSec].get("dhGroup")}
%       endif
%       if config_ipSec[ipSec].get("localId"):
        local-id ${config_ipSec[ipSec].get("localId")}
%       endif
        exit
%       if config_ipSec[ipSec].get("saPolicyName"):
    sa policy ${config_ipSec[ipSec].get("saPolicyName")}
%       endif
%       if config_ipSec[ipSec].get("espEncryption"):
        esp encryption ${config_ipSec[ipSec].get("espEncryption")}
%       endif
%       if config_ipSec[ipSec].get("espIntegrity"):
        esp integrity ${config_ipSec[ipSec].get("espIntegrity")}
%       endif
%       if config_ipSec[ipSec].get("perfectForwardSecretcy"):
        pfs ${config_ipSec[ipSec].get("perfectForwardSecretcy")}
%       endif
%       if config_ipSec[ipSec].get("saLifetime"):
        sa lifetime ${config_ipSec[ipSec].get("saLifetime")}
%       endif
        exit
%       if config_ipSec[ipSec].get("ipSecProfileName"):
    profile ${config_ipSec[ipSec].get("ipSecProfileName")}
%           if config_ipSec[ipSec].get("ikePolicyName"):
        ike-policy ${config_ipSec[ipSec].get("ikePolicyName")}
%           endif
%           if config_ipSec[ipSec].get("saPolicyName"):
        sa-policy ${config_ipSec[ipSec].get("saPolicyName")}
%           endif
%           if config_ipSec[ipSec].get("sharedKey"):
        shared-key ${config_ipSec[ipSec].get("sharedKey")}
%           endif
%           if config_ipSec[ipSec].get("mode"):
        mode ${config_ipSec[ipSec].get("mode")}
%           endif
%           if config_ipSec[ipSec].get("dpd"):
        dpd ${config_ipSec[ipSec].get("dpd")}
%           endif
%           if config_ipSec[ipSec].get("connection"):
        connection ${config_ipSec[ipSec].get("connection")}
%           endif
%           if config_ipSec[ipSec].get("acl"):
        ip access-group ${config_ipSec[ipSec].get("acl")}
%           endif
%       endif
        exit
%       if config_ipSec[ipSec].get("ethernetUntaggedAllowed"):
    ethernet untagged allowed
%       endif
    exit
!
%    endfor
%endif

## MAC Sec
%if config_macSec:
%    for macSec in config_macSec:
mac security
%       if config_macSec[macSec].get("fips"):
    fips restrictions
!
%       endif
    profile ${config_macSec[macSec].get("macSecProfileName")}
%       if config_macSec[macSec].get("key"):
        key ${config_macSec[macSec].get("key")}
%       endif
%       if config_macSec[macSec].get("mkaReKeyPeriod"):
        mka session rekey-period ${config_macSec[macSec].get("mkaReKeyPeriod")}
%       endif
%       if config_macSec[macSec].get("trafficUnprotected") == "allow":
        traffic unprotected allow
%       elif config_macSec[macSec].get("trafficUnprotected") == "drop":
        traffic unprotected drop
%       endif
%       if config_macSec[macSec].get("cipher"):
        cipher ${config_macSec[macSec].get("cipher")}
%       endif
%       if config_macSec[macSec].get("l2ProtocolLldp") == "bypass":
        l2-protocol lldp bypass
%       elif config_macSec[macSec].get("l2ProtocolLldp") == "bypass unauthorized":
        l2-protocol lldp bypass unauthorized
%       endif
        exit
%    endfor
    exit
!
%endif

## Multicast RPs
%if config_mc:
router pim sparse-mode
%  for mc, mc_details in config_mc.items():
%    for rp in mc_details["rPs"]:
%      if rp.vrf:
    vrf ${rp.vrf}
%      endif
    ${rp.protocol}
%      if rp.rPacl:
    rp address ${rp.rpAddress} access-list ${rp.rPacl}
%      else:
    rp address ${rp.rpAddress} ${rp.groupPrefix}
%      endif
%    endfor
%    for arp in mc_details["anycastRPs"]:
%      if arp.aVrf:
    vrf ${arp.aVrf}
%      endif
    ${arp.aProtocol}
%      if arp.registerCount == "infinity":
    anycast-rp ${arp.arpAddress} ${arp.aOtherRp} register-count infinity
%      elif arp.registerCount:
    anycast-rp ${arp.arpAddress} ${arp.aOtherRp} register-count ${arp.registerCount}
%      else:
    anycast-rp ${arp.arpAddress} ${arp.aOtherRp}
%      endif
%    endfor
!
%  endfor
%endif

## Multi Homing
%if config_multiH:
%    for multiH in config_multiH:
%        if config_multiH[multiH].get("lacpPortIdRange"):
lacp port-id range ${config_multiH[multiH].get("lacpPortIdRange")}
%        endif
%        if config_multiH[multiH].get("noStpVlanIdRange"):
no spanning-tree vlan-id ${config_multiH[multiH].get("noStpVlanIdRange")}
%        endif
%        if config_multiH[multiH].get("stpSuperRoot"):
spanning-tree root super
%        endif
%    endfor
%endif
${switchGroupCli}
% for vID, vlanCfg in sorted(vlans.items()):
${makeVlanCfg(vID, vlanCfg)}
% endfor

% for groupNum, groupCfg in sorted(groups.items()):
${makeChannelGroupCfg(groupNum, groupCfg)}
% endfor

% for intfName, intfCfg in sorted(interfaces.items()):
%   if intfCfg.groupNum and intfCfg.lacpFallback != "Individual":
${makeChannelMemberCfg(intfName, intfCfg)}
%   elif intfCfg.groupNum and intfCfg.lacpFallback == "Individual":
${makeChannelMemberCfg(intfName, intfCfg)}
${makeIntfCfg(intfName, intfCfg)}
%   else:
${makeIntfCfg(intfName, intfCfg)}

%   endif
% endfor

% for intfName, tunnelCfg in sorted(tunnels.items()):
${makeTunnelCfg(intfName, tunnelCfg)}
% endfor
