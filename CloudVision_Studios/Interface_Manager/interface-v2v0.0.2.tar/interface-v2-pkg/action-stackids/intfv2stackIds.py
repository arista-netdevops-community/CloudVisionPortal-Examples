# Copyright (c) 2024 Arista Networks, Inc.  All rights reserved.
# Arista Networks, Inc. Confidential and Proprietary.
# Subject to Arista Networks, Inc.'s EULA.
# FOR INTERNAL USE ONLY. NOT FOR DISTRIBUTION.
#
# Date written: July 25, 2024
#
# STEPS to USE:
# 1. Install the Action script:
#    Go to the Actions page (cv/provisioning/action), click New Action,
#    provide any Name for the action(eg. Interface Manager V2 StackId),
#    select Action Type of Studio Autofill, click Save.
#    Once in the Action Editor, copy and paste the entire contents of this
#    file as the script.
# 2. Attach the action script to the studio:
#    Open a new workspace.
#    In the workspace go to the InterfaceManagerV2 studio and select Edit.
#    Go to the schema, and on the left click on the Select Devices field,
#    at the top of the schema.
#    Scroll down on the right side to find the Action Configuration, click on
#    Configure Autofill, select the Action, Save, and then Submit the workspace.
# 3. Open a new workspace and a lightning bolt should be visible beside the
#    Select Devices field.  Clicking on it will populate any missing
#    Switch Numbers for switch devices under the Switch Groups.

import json
from pprint import pformat
import re
from typing import List, Tuple

# pylint: disable=import-error
import tagsearch_python.tagsearch_pb2_grpc as tsgr
import tagsearch_python.tagsearch_pb2 as tspb
from arista.tag.v2.tag_pb2 import (
   ELEMENT_TYPE_DEVICE,
   ELEMENT_TYPE_INTERFACE,
)

from cloudvision.cvlib import (
    ActionFailed,
    extractStudioInfoFromArgs,
    InputUpdateException,
    InputRequestException,
    setStudioInputs,
    getStudioInputs,
    IdAllocator,
)


LOGLEVEL = 0


def log(loglevel=0, logstring=''):
   if loglevel <= LOGLEVEL:
      print(logstring)


def convert(text):
   return int(text) if text.isdigit() else text.lower()


def natural_sort(iterable, sort_key=None):
   if iterable is None:
      return []

   def alphanum_key(key):
      if sort_key is not None and isinstance(key, dict):
         return [convert(c) for c in re.split("([0-9]+)",
                 str(key.get(sort_key, key)))]
      return [convert(c) for c in re.split("([0-9]+)", str(key))]
   return sorted(iterable, key=alphanum_key)


# ===========================================================================
# tagsearch utilities
# ===========================================================================
def tagSearchQuery(ctx, query: str, wrkID: str,
                   elType: int = ELEMENT_TYPE_DEVICE,
                   userTagsOnly: bool = True):
   '''
   Gets the list of devices or interfaces matching a tag query.
   '''
   devices = []
   interfaces = []
   tsclient = ctx.getApiClient(tsgr.TagSearchStub)
   tagmr = tspb.TagMatchRequestV2(
                      query=query,
                      workspace_id=wrkID,
                      type=elType-1,
                      topology_studio_request=userTagsOnly
                     )
   tagmresp = tsclient.GetTagMatchesV2(tagmr)
   if elType == ELEMENT_TYPE_INTERFACE:
      for match in tagmresp.matches:
         interfaces.append(match.interface.interface_name)
      return interfaces
   for match in tagmresp.matches:
      if device_id := match.device.device_id:
         devices.append(device_id)
   return devices


# ===========================================================================
# set inputs utilities
# ===========================================================================
inputSettings = []


def setInput(path: List, value: str, remove=False):
   """
   Set the nodeId for the input path device in the inputs
   """
   inputSettings.append((path, value, remove))


def sendInputSettings(stdID: str, wrkID: str, inputs: List[Tuple]):
   """
   Send the input settings to the Inputs Service
   """
   try:
      # pylint: disable=undefined-variable
      setStudioInputs(ctx.getApiClient, stdID, wrkID, inputs)
   except InputUpdateException as error:
      raise ActionFailed(("Failed to update inputs associated with switch Ids. "
                          "Please assign them manually.")) from error

# ===========================================================================
# InterfaceV2 Specifics below here.
# ===========================================================================
# pylint: disable=too-many-arguments


class Selection:
   def __init__(self, site: int, group: int, stack: int):
      self.site = site
      self.group = group
      self.stack = stack


def getStackMemberPath(siteIdx, groupIdx, stackIdx):
   return ['sites', str(siteIdx), 'inputs', 'sitesGroup', 'devices',
            str(groupIdx), 'inputs', 'devicesGroup', 'stack',
            str(stackIdx), 'inputs', 'stackMember']


def getStackTagPath(siteIdx, groupIdx, stackIdx):
   return ['sites', str(siteIdx), 'inputs', 'sitesGroup', 'devices',
            str(groupIdx), 'inputs', 'devicesGroup', 'stack',
            str(stackIdx), 'tags', 'query']


def setStackMembers(ctx, inputs, wrkID, sel: Selection):
   log(1, f'setStackMembers Selection: {vars(sel)}')
   allSites = inputs.get('sites')
   for siteIdx, site in enumerate(allSites):
      if not ( siteInputs := site.get( 'inputs' )) or not (
         siteTags := site.get( 'tags' ) ):
         continue
      if sel.site is not None and siteIdx != sel.site:
         continue
      log(1, f'siteTags: {siteTags}')
      siteDevs = tagSearchQuery(ctx, siteTags.get('query'), wrkID)
      siteGroups = siteInputs.get('sitesGroup', {}).get('devices')
      log(2, f'siteGroups: {pformat(siteGroups, sort_dicts=True)}')
      for groupIdx, siteGroup in enumerate(siteGroups):
         if not ( siteGroupInputs := siteGroup.get( 'inputs' )) or not (
           siteGroupTags := siteGroup.get( 'tags' ) ):
            continue
         stackEntries = siteGroupInputs.get('devicesGroup', {}).get('stack', [])
         if sel.group is not None and groupIdx != sel.group:
            continue
         log(1, f'siteGroupTags: {siteGroupTags}')
         groupDevs = tagSearchQuery(ctx, siteGroupTags.get('query'), wrkID)
         groupDevs = natural_sort(list(set(siteDevs) & set(groupDevs)))
         stackDevs = []
         idAlloc = IdAllocator()
         # add existing Id's to allocator
         for stackIdx, stackEntry in enumerate(stackEntries):
            if not ( stackEntryQuery := stackEntry.get(
               'tags', {} ).get( 'query' ) ):
               continue
            if not (swid := stackEntry.get( 'inputs', {} ).get('stackMember')):
               continue
            devId = stackEntryQuery.split(':')[1]
            stackDevs.append(devId)
            idAlloc.allocate(int(swid), devId)
         # add mising Id's from allocator
         for stackIdx, stackEntry in enumerate(stackEntries):
            if not ( stackEntryQuery := stackEntry.get(
               'tags', {} ).get( 'query' ) ):
               continue
            if sel.stack is not None and stackIdx != sel.stack:
               continue
            if (swid := stackEntry.get( 'inputs', {} ).get('stackMember')):
               continue
            devId = stackEntryQuery.split(':')[1]
            stackDevs.append(devId)
            # allocate an swid
            swid = idAlloc.allocate(name=devId)
            path = getStackMemberPath(siteIdx, groupIdx, stackIdx)
            setInput(path, str(swid))
            if sel.stack is not None:
               return
         # add missing entries, and allocate them an id
         if len(stackDevs) < len(groupDevs):
            for stackIdx, devId in enumerate(groupDevs, start=len(stackDevs)):
               if devId in stackDevs:
                  continue
               # allocate an swid
               swid = idAlloc.allocate(name=devId)
               path_tags = getStackTagPath(siteIdx, groupIdx, stackIdx)
               setInput(path_tags, f"device:{devId}")
               path_input = getStackMemberPath(siteIdx, groupIdx, stackIdx)
               setInput(path_input, str(swid))


def main():
   # pylint: disable=undefined-variable
   stdID, wrkID, input_path = extractStudioInfoFromArgs(ctx.action.args)
   try:
      inputs = getStudioInputs(ctx.getApiClient, stdID, wrkID)
   except InputRequestException as error:
      raise ActionFailed((f"Failed to get input associated with {stdID}.")) from error
   log(3, f"inputs:\n"
          f"{json.dumps(inputs, indent=4)}")
   site_index = None
   group_index = None
   stack_index = None
   if input_path.count('inputs') >= 1:
      site_index = int(input_path[input_path.index('sites')+1])
   if input_path.count('inputs') >= 2:
      group_index = int(input_path[input_path.index('devices')+1])
   if input_path.count('inputs') >= 3:
      stack_index = int(input_path[input_path.index('stack')+1])
   selection = Selection(site_index, group_index, stack_index)
   setStackMembers(ctx, inputs, wrkID, selection)
   if inputSettings:
      sendInputSettings(stdID, wrkID, inputSettings)


if __name__ == "__main__":
   main()
