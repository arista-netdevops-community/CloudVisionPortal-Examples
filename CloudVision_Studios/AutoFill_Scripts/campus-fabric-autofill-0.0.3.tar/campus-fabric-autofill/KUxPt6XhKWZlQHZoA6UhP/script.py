# pylint: disable=import-error

import ast
import json

from cloudvision.cvlib import (
    ActionFailed,
    extractStudioInfoFromArgs,
    InputUpdateException,
    InputNotFoundException,
    getStudioInputs,
    setStudioInput,
)

LOGLEVEL = 2


def log(loglevel=0, logstring=""):
    if loglevel <= LOGLEVEL:
        print(logstring)


def getAndSendLocation():
    # Parse studio info from args
    stdID, wrkID, inputPath = extractStudioInfoFromArgs(ctx.action.args)
    # Fetch current inputs
    try:
        inputs = getStudioInputs(ctx.getApiClient, stdID, wrkID, inputPath)
    except InputNotFoundException:
        inputs = {}
    location = ctx.action.args.get("Location")
    if not location:
        raise ActionFailed("No location provided")
    if " " in location:
        location = '"' + location + '"'
    locationQuery = f"Campus:{location}"
    if locationQuery in [
        campus["tags"]["query"] for campus in inputs.get("campus", [])
    ]:
        raise ActionFailed(f"Location {location} already exists")

    CampusType = ctx.action.args.get("L2 or L3")
    t = 0

    strBuildings = ""
    if CampusType == "L2":
        t = 1
        strBuildings = ctx.action.args.get("BuildingsL2")

    elif CampusType == "L3":
        t = 2
        strBuildings = ctx.action.args.get("BuildingsL3")

 #   buildings = ast.literal_eval(strBuildings)
    buildings = json.loads(strBuildings)

    match int(t):
        case 1:
            # buildings = {
            #     "1": {
            #         "accessPods":{
            #             "1": {
            #                 "floor": 1
            #             }, 
            #             "2": {
            #                 "floor": 2
            #             }
            #         },
            #         "inbandManagementGateway": "1.2.2.1",
            #         "inbandManagementSubnet": "1.2.2.0/24",
            #         "routerIdPool": "1.2.1.0/24",
            #     },
            #     "2": {
            #         "accessPods":{
            #             "1": {
            #                 "floor": 1
            #             }, 
            #             "2": {
            #                 "floor": 2
            #             }
            #         },
            #         "inbandManagementGateway": "1.1.3.1",
            #         "inbandManagementSubnet": "1.1.3.0/24",
            #         "routerIdPool": "1.1.2.0/24",
            #     },
            # }

            campusPods = []

            for building, buildingInfo in buildings.items():
                accessPods = []
                for accessPod, accessPodInfo in buildingInfo.get("accessPods", {}).items():
                    floor = accessPodInfo.get("floor")
                    accessPods.append(
                        {
                            "inputs": {
                                "accessPodFacts": {
                                    "leafs": [
                                        {
                                            "inputs": {"leafsInfo": {}},
                                            "tags": {
                                                "query": f"device:SN-{location}-{building}-{accessPod}-leaf1"
                                            },
                                        },
                                        {
                                            "inputs": {"leafsInfo": {}},
                                            "tags": {
                                                "query": f"device:SN-{location}-{building}-{accessPod}-leaf2"
                                            },
                                        },
                                    ],
                                    "memberLeafMlagPairs": [],
                                    "memberLeafs": [],
                                }
                            },
                            "tags": {
                                "query": f"Access-Pod:{location}-{building}-{accessPod}"
                            },
                        }
                    )

                campusPods.append(
                    {
                        "inputs": {
                            "campusPodFacts": {
                                "accessPodDefaults": {},
                                "accessPods": accessPods,
                                "advancedFabricSettings": {},
                                "campusPodRoutingProtocols": {
                                    "campusPodUnderlayRoutingProtocol": "OSPF"
                                },
                                "design": {
                                    "campusType": "L2",
                                    "vxlanOverlay": False,
                                },
                                "egressConnectivity": {},
                                "fabricConfigurations": {
                                    "inbandManagementDetails": {
                                        "inbandManagementGateway": buildingInfo.get("inbandManagementGateway"),
                                        "inbandManagementSubnet": buildingInfo.get("inbandManagementSubnet"),
                                        "inbandManagementVlan": 2,
                                        "ipHelperAddresses": buildingInfo.get("ipHelperAddresses"),
                                    }
                                },
                                "nodeTypeProperties": {},
                                "spineDefaults": {
                                    "routerIdPool": buildingInfo.get("routerIdPool"),
                                },
                                "spines": [
                                    {
                                        "inputs": {},
                                        "tags": {
                                            "query": f"device:SN-{location}-{building}-agg1"
                                        },
                                    },
                                    {
                                        "inputs": {},
                                        "tags": {
                                            "query": f"device:SN-{location}-{building}-agg2"
                                        },
                                    },
                                ],
                                "thirdPartyDevices": [],
                            }
                        },
                        "tags": {
                            "query": f"Campus-Pod:{location}-{building}"
                        },
                    })

            newLocation = {
                "inputs": {
                    "campus": [
                        {
                            "inputs": {
                                "campusDetails": {
                                    "campusPod": campusPods
                                }
                            },
                            "tags": {"query": f"Campus:{location}"},
                        }
                    ],
                }
            }
        case 2:
            # buildings = {
            #     "1": {
            #         "accessPodRouterIdPool":"2.1.3.0/24", 
            #         "accessPodUplinkIpv4Pool": "2.1.2.0/24",
            #         "accessPods":{
            #             "1": {
            #                 "floor": 1,
            #                 "inbandManagementSubnet":"2.1.4.0/24"
            #             }, 
            #             "2": {
            #                 "floor": 2,
            #                 "inbandManagementSubnet":"2.1.5.0/24"
            #             },
            #             "3": {
            #                 "floor": 3,
            #                 "inbandManagementSubnet":"2.1.6.0/24"
            #             },
            #         },
            #         "ipHelperAddresses": [
            #             {
            #                 "dhcpServer": "45.45.45.45"
            #             },
            #             {
            #                 "dhcpServer": "45.45.45.46"
            #             },
            #         ],
            #         "routerIdPool": "1.2.1.0/24",
            #     },
            #     "2": {
            #         "accessPodRouterIdPool":"2.2.3.0/24", 
            #         "accessPodUplinkIpv4Pool": "2.2.2.0/24",
            #         "accessPods":{
            #             "1": {
            #                 "floor": 1,
            #                 "inbandManagementSubnet":"2.2.4.0/24"
            #             }, 
            #             "2": {
            #                 "floor": 2,
            #                 "inbandManagementSubnet":"2.2.5.0/24"
            #             },
            #             "3": {
            #                 "floor": 3,
            #                 "inbandManagementSubnet":"2.2.6.0/24"
            #             },
            #         },
            #         "ipHelperAddresses": [
            #             {
            #                 "dhcpServer": "23.23.23.23"
            #             },
            #             {
            #                 "dhcpServer": "23.23.23.24"
            #             }
            #         ],
            #         "routerIdPool": "2.2.1.0/24",
            #     },
            # }

            campusPods = []

            for building, buildingInfo in buildings.items():
                accessPods = []
                accessPodsInbandMgmtDetails = []
                for accessPod, accessPodInfo in buildingInfo.get("accessPods", {}).items():
                    floor = accessPodInfo.get("floor")
                    inbandManagementSubnet = accessPodInfo.get("inbandManagementSubnet")
                    accessPods.append(
                        {
                            "inputs": {
                                "accessPodFacts": {
                                    "leafs": [
                                        {
                                            "inputs": {"leafsInfo": {}},
                                            "tags": {
                                                "query": f"device:SN-{location}-{building}-{accessPod}-leaf1"
                                            },
                                        },
                                        {
                                            "inputs": {"leafsInfo": {}},
                                            "tags": {
                                                "query": f"device:SN-{location}-{building}-{accessPod}-leaf2"
                                            },
                                        },
                                    ],
                                    "memberLeafMlagPairs": [],
                                    "memberLeafs": [],
                                }
                            },
                            "tags": {
                                "query": f"Access-Pod:{location}-{building}-{accessPod}"
                            },
                        }
                    )
                    accessPodsInbandMgmtDetails.append(
                        {
                            "inputs": {
                                "inbandManagementDetails": {
                                    "inbandManagementSubnet": inbandManagementSubnet
                                }
                            },
                            "tags": {
                                "query": f"Access-Pod:{location}-{building}-{accessPod}"
                            }
                        },
                    )

                campusPods.append(
                    {
                        "inputs": {
                            "campusPodFacts": {
                                "accessPodDefaults": {
                                    "routerIdPool": buildingInfo.get("accessPodRouterIdPool"),
                                    "uplinkIpv4Pool": buildingInfo.get("accessPodUplinkIpv4Pool"),
                                    "vtepLoopbackIPv4Pool": "172.16.1.0/24"
                                },
                                "accessPods": accessPods,
                                "advancedFabricSettings": {},
                                "campusPodRoutingProtocols": {
                                    "campusPodUnderlayRoutingProtocol": "OSPF"
                                },
                                "design": {
                                    "campusType": "L3",
                                    "vxlanOverlay": False,
                                },
                                "egressConnectivity": {},
                                "fabricConfigurations": {
                                    "inbandManagementDetails": {
                                        "accessPods": accessPodsInbandMgmtDetails,
                                        "inbandManagementVlan": 2,
                                        "ipHelperAddresses": buildingInfo.get("ipHelperAddresses"),
                                    }
                                },
                                "nodeTypeProperties": {},
                                "spineDefaults": {
                                    "routerIdPool": buildingInfo.get("routerIdPool"),
                                },
                                "spines": [
                                    {
                                        "inputs": {},
                                        "tags": {
                                            "query": f"device:SN-{location}-{building}-agg1"
                                        },
                                    },
                                    {
                                        "inputs": {},
                                        "tags": {
                                            "query": f"device:SN-{location}-{building}-agg2"
                                        },
                                    },
                                ],
                                "thirdPartyDevices": [],
                            }
                        },
                        "tags": {
                            "query": f"Campus-Pod:{location}-{building}"
                        },
                    },
                )

            newLocation = {
                "inputs": {
                    "campus": [
                        {
                            "inputs": {
                                "campusDetails": {
                                    "campusPod": campusPods
                                }
                            },
                            "tags": {"query": f"Campus:{location}"},
                        }
                    ],
                }
            }
    campus = inputs.get("campus", [])
    campus.append(newLocation["inputs"]["campus"][0])
    inputs["campus"] = campus
    #   print(inputs)
    try:
        setStudioInput(ctx.getApiClient, stdID, wrkID, inputPath, inputs)
    except InputUpdateException as e:
        raise ActionFailed((f"Failed to add location due to: {e}"))

    # return the index of the new campus for use in populating the studio
    return str(len(campus) - 1), location


def main():
    new_campus_index, location = getAndSendLocation()


if __name__ == "__main__":
    main()
