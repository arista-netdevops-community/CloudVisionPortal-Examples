#!python
# Copyright (c) 2022 Arista Networks, Inc.  All rights reserved.
# Arista Networks, Inc. Confidential and Proprietary.
# Subject to Arista Networks, Inc.'s EULA.
# FOR INTERNAL USE ONLY. NOT FOR DISTRIBUTION.
# pylint: skip-file
# flake8: noqa
"""
action-workspace-prebuild.py

This is a prebuild action running after studio prebuild in a studio build pipeline.
This action is running once per workspace, so it handles all studios and devices.

The purpose of this action is:
 - Run AVD Topology (eos_designs_facts)
 - Store result in cache
"""
import json
from copy import deepcopy
from time import time

from cloudvision.cvlib import Studio
from cloudvision.cvlib.exceptions import InputErrorException, TagTooManyValuesException
from deepmerge import always_merger
from pyavd import (
    get_avd_facts,
    get_device_config,
    get_device_structured_config,
    validate_inputs,
    validate_structured_config,
)
from tagsearch_python.tagsearch_pb2 import TagMatchRequestV2
from tagsearch_python.tagsearch_pb2_grpc import TagSearchStub


ctx.initializeStudioCtxFromArgs()
TAGMAPPINGS = [{"from_tag": "AVD_Fabric_Name", "to_path": ["fabric_name"]}, {"from_tag": "AVD_DC_Name", "to_path": ["dc_name"]}, {"from_tag": "AVD_POD_Name", "to_path": ["pod_name"]}, {"from_tag": "AVD_Role", "to_path": ["type"]}]

runtimes = {"start_time": time(), "devices": {}}

# Hack to get ctx.tags working outside of a studio template:
ctx.studio = Studio(workspaceId=ctx.workspace.id, studioId="")


def __resolve_device_tag_query(query):
    timer = time()
    if query == "":
        return []
    if query is None:
        query = "device:*"
    tsclient = ctx.getApiClient(TagSearchStub)
    search_req = TagMatchRequestV2(query=query, workspace_id=ctx.workspace.id)
    search_res = tsclient.GetTagMatchesV2(search_req)
    runtimes.setdefault("resolve_device_tag_query", []).append(str(time() - timer))
    return [match.device.device_id for match in search_res.matches]


def __get_device_tags(device_id, labels):
    timer = time()
    device_tags = {}
    all_device_tags = ctx.tags._getDeviceTags(device_id)
    for label in labels:
        if value_list := all_device_tags.get(label):
            if len(value_list) > 1:
                raise TagTooManyValuesException(label, device_id, value_list)
            device_tags[label] = value_list[0]
    runtimes["devices"].setdefault(device_id, {})["get_device_tags"] = str(time() - timer)
    return device_tags


class TagMapper:
    def __init__(self, mappings):
        """
        Maps data from studio inputs to AVD data model.

        If "convert_value" is set (Currently only supporting "int"), the data will be converted.

        Parameters
        ----------
        mappings : list[dict]
            List of variable mappings like:
            [
                {
                    "from_tag": "Fabric_Name",
                    "to_path": ["fabric_name"],
                    "convert_value": "int"
                }
            ]
        """
        self.mappings = mappings
        self.labels = [mapping["from_tag"] for mapping in mappings]

    def __convert_value(self, convert_value: str, value):
        """Convert value if supported. Raise if not."""
        # ctx.alog(f"Converting value {value} using {convert_value}")
        if convert_value == "int" and isinstance(value, str):
            return int(value)

        raise ValueError(f"Unsupported convert_value: {convert_value}")

    def __set_value_from_path(self, path: list, data: list | dict, value):
        """Recursive function to walk through data to set value of path, creating any level needed."""
        if not path:
            raise RuntimeError("Path is empty. Something bad happened.")

        if len(path) == 1:
            if isinstance(data, dict):
                data[path[0]] = value
            elif isinstance(data, list) and isinstance(path[0], int):
                # We ignore the actual integer value and just append the item to the list.
                data.append(value)
            else:
                raise RuntimeError(f"Path '{path}' cannot be set on data of type '{type(data)}'")
            return

        # Two or more elements in path.
        if isinstance(data, dict):
            # For dict, create the child key with correct type and call recursively.
            if isinstance(path[1], int):
                data.setdefault(path[0], [])
                self.__set_value_from_path(path[1:], data[path[0]], value)
            else:
                data.setdefault(path[0], {})
                self.__set_value_from_path(path[1:], data[path[0]], value)
        elif isinstance(data, list) and isinstance(path[0], int):
            # For list, append item of correct type and call recursively.
            # Notice that the actual index in path[0] is ignored.
            # TODO: Consider accepting index or lookup based on key, to ensure consistency when updating multiple fields.
            index = len(data)
            if isinstance(path[1], int):
                data.append([])
                self.__set_value_from_path(path[1:], data[index], value)
            else:
                data.append({})
                self.__set_value_from_path(path[1:], data[index], value)

        else:
            raise RuntimeError(f"Path '{path}' cannot be set on data of type '{type(data)}'")

        return None

    def map_device_tags(self, device_tag_values: dict) -> dict:
        """
        Map tags for the given device_id according to mappings given at initilization.

        Returns a dict with values from tags.

        Parameters
        ----------
        device_tag_values : dict
            Dictionary with all device tags and values

        Returns
        -------
        dict
            mapped data from tags for one device
        """
        output = {}
        for mapping in self.mappings:
            if (value := device_tag_values.get(mapping["from_tag"])) is not None:
                if (convert_value := mapping.get("convert_value")) is not None:
                    value = self.__convert_value(convert_value, value)

                self.__set_value_from_path(mapping["to_path"], output, value)

        return output


def __get_avd_lldp_topology(unresolved_topology: dict, hostname_to_device_id_map: dict) -> list:
    """
    Build AVD's "lldp_topology" data model for one device based on "_unresolved_topology"
    which is coming from the prebuild action and looks like this:

    "_unresolved_topology": {
        "device": {
            "hostname": "s2-brdr1",
            "interfaces": [
                {
                    "interface": "Ethernet1",
                    "inputs": {
                        "interface": {
                            "neighborDeviceId": "139F6E9CDABB23D21B54C6E0928D0044",
                            "neighborInterfaceName": "Ethernet1"
                        }
                    }
                },
                ...
            ],
            "macAddress": "00:1c:73:d7:97:d6",
            "modelName": "cEOSLab"
        }
    }
    """
    device_id_to_hostname_map = {v: k for k, v in hostname_to_device_id_map.items()}
    device = unresolved_topology["device"]
    output_device = {
        "hostname": device["hostname"],
        "platform": device["modelName"],
        "interfaces": [],
    }
    for interface in device["interfaces"]:
        device_interface = interface["interface"]
        if_details = interface["inputs"].get("interface")
        if not if_details:
            output_device["interfaces"].append({"name": device_interface})
            continue

        neighbor = device_id_to_hostname_map.get(
            if_details["neighborDeviceId"],
            if_details["neighborDeviceId"],
        )
        neighbor_interface = if_details["neighborInterfaceName"]
        output_device["interfaces"].append(
            {
                "name": device_interface,
                "neighbor": neighbor,
                "neighbor_interface": neighbor_interface,
            }
        )
    return [output_device]


def __build_device_vars(device_list: list, datasets: list[dict]) -> (dict, dict):
    """
    Parse avd_inputs data structure and build a nested dict with all vars for each host
    Then merge data from tag mappings

    Parameters
    ----------
    device_list : list
        List of device IDs
    list
        dict
            Dataset only containing device_query and mapped_vars
            {
                "device_query": "DC_Name:DC2 AND Role:L3leaf",
                "avd_vars": {"network_type": {"defaults": {"bgp_as": "5678"}}}
            }
    Returns
    -------
    dict
        hostname1 : dict
        hostname2 : dict
    dict
        hostname1 : device_id1
        hostname2 : device_id2
    """
    tag_mapper = TagMapper(TAGMAPPINGS)

    # device_id_vars is using device_id as key, since we may not have the hostname yet. Hostname could come from tags.
    device_id_vars = {}

    for dataset in datasets:
        matching_device_ids = __resolve_device_tag_query(dataset["device_query"])
        for device_id in matching_device_ids:
            if device_id not in device_list:
                continue

            one_device_vars = device_id_vars.setdefault(device_id, {})
            always_merger.merge(one_device_vars, deepcopy(dataset["avd_vars"]))

    hostname_to_device_id_map = {}
    device_vars = {}
    for device_id in device_list:
        device_tag_values = __get_device_tags(device_id, tag_mapper.labels)
        mapped_tag_data = tag_mapper.map_device_tags(device_tag_values)
        one_device_vars = device_id_vars.setdefault(device_id, {})
        always_merger.merge(one_device_vars, deepcopy(mapped_tag_data))
        if not one_device_vars.get("type"):
            ctx.alog(f"Ignoring device '{device_id}' since 'type' is not set. 'type' is taken from the CV tag 'AVD_Role'.")
            continue
        hostname = one_device_vars["hostname"]
        device_vars[hostname] = one_device_vars
        hostname_to_device_id_map[hostname] = device_id

    for hostname in hostname_to_device_id_map:
        device_vars[hostname]["lldp_topology"] = __get_avd_lldp_topology(device_vars[hostname].pop("_unresolved_topology"), hostname_to_device_id_map)

    return device_vars, hostname_to_device_id_map


# Get data stored by studio prebuild buildhooks.
retrieval_timer = time()
avd_inputs = json.loads(ctx.retrieve(path=["avd"], customKey="avd_inputs", delete=False))
device_list = json.loads(ctx.retrieve(path=["avd"], customKey="device_list", delete=False))
runtimes["retrieve"] = str(time() - retrieval_timer)

# Build dictionary of AVD vars by resolving the resolvers in avd_inputs for all devices.
device_vars, hostname_to_device_id_map = __build_device_vars(device_list, avd_inputs)
# ctx.store(json.dumps(device_vars), customKey="devices_vars_with_tags", path=["avd"])

# Validate inputs according to AVD eos_designs schema
for hostname, one_device_vars in device_vars.items():
    device_id = hostname_to_device_id_map[hostname]
    runtimes["devices"].setdefault(device_id, {}).update(
        {
            "hostname": hostname,
            "device_id": device_id,
        }
    )

    pyavd_timer = time()
    validation_result = validate_inputs(one_device_vars)
    if validation_result.failed:
        raise InputErrorException(
            message=f"Validation errors for '{hostname}' during validation of converted AVD inputs",
            inputErrors=[error.message for error in validation_result.validation_errors],
        )
    runtimes["devices"][device_id]["pyavd_validate_inputs"] = str(time() - pyavd_timer)

# Run AVD get_avd_facts
pyavd_timer = time()
avd_switch_facts = get_avd_facts(device_vars)
runtimes["pyavd_facts"] = str(time() - pyavd_timer)

for hostname, one_device_vars in device_vars.items():
    device_id = hostname_to_device_id_map[hostname]

    # Run AVD get_device_structured_config
    pyavd_timer = time()
    structured_config = get_device_structured_config(hostname, one_device_vars, avd_switch_facts)
    runtimes["devices"][device_id]["pyavd_struct_cfg"] = str(time() - pyavd_timer)

    # Run AVD get_device_config
    pyavd_timer = time()
    eos_config = get_device_config(structured_config)
    runtimes["devices"][device_id]["pyavd_eos_cfg"] = str(time() - pyavd_timer)

    # Save config using device_id as key, so it can be read from the template.
    storage_timer = time()
    ctx.store(
        eos_config,
        customKey=device_id,
        path=["avd", ctx.workspace.id, "configs"],
    )
    runtimes["devices"][device_id]["store"] = str(time() - storage_timer)

runtimes["total"] = str(time() - runtimes["start_time"])

ctx.alog(f"Completed build-hook 'action-workspace-prebuild' with runtimes {runtimes}.")
