<%
from cloudvision import cvlib

def makeInputError(message, inputPath, fieldId):
  return cvlib.InputError(message=message, inputPath=inputPath, fieldId=fieldId, members=[])

# Template mainline start
if not deviceSets:
  return

_, firstCtx = deviceSets.resolveWithContext()
if firstCtx is None:
  return

currentDevice = firstCtx.device
handlerConfigs = {}

for dev, devSetsCfg, devSetsCtx in deviceSets.resolveAllWithContext(strict=True):
  if dev != currentDevice:
    continue
  if not devSetsCfg or not devSetsCfg.get('config'):
    continue

  inputPath = ["deviceSets", str(devSetsCtx.index)]

  for hndlr in devSetsCfg['config'].get('eventHandlers', []):
    handlerName = hndlr.get('handlerName', '')
    if not handlerName:
      continue

    actionCommand = hndlr.get('actionCommand', '')
    if not actionCommand:
      raise cvlib.InputErrorException(inputErrors=[makeInputError(
        "Action command is required for event handler '%s'" % handlerName,
        inputPath, "actionCommand")])

    triggerType = hndlr.get('triggerType', '')
    if not triggerType:
      raise cvlib.InputErrorException(inputErrors=[makeInputError(
        "Trigger type is required for event handler '%s'" % handlerName,
        inputPath, "triggerType")])

    intfCfg = hndlr.get('onIntfConfig') or {}
    intfName = intfCfg.get('intfName', '')
    if triggerType == 'on-intf' and not intfName:
      raise cvlib.InputErrorException(inputErrors=[makeInputError(
        "Interface name is required for on-intf trigger in event handler '%s'" % handlerName,
        inputPath, "intfName")])

    ctrCfg = hndlr.get('onCountersConfig') or {}
    conditionExpr = ctrCfg.get('conditionExpr', '')
    if triggerType == 'on-counters' and not conditionExpr:
      raise cvlib.InputErrorException(inputErrors=[makeInputError(
        "Condition expression is required for on-counters trigger in event handler '%s'" % handlerName,
        inputPath, "conditionExpr")])

    logCfg = hndlr.get('onLoggingConfig') or {}
    custCfg = hndlr.get('onCustomConditionConfig') or {}
    advCfg = hndlr.get('advancedConfig') or {}

    handlerConfigs[handlerName] = {
      'triggerType': triggerType,
      'actionCommand': actionCommand,
      'delay': hndlr.get('delay'),
      'triggerOnConfigDisabled': hndlr.get('triggerOnConfigDisabled', False),
      'loggingRegex': logCfg.get('loggingRegex', ''),
      'loggingPollInterval': logCfg.get('loggingPollInterval'),
      'intfName': intfName,
      'intfTriggerOn': intfCfg.get('intfTriggerOn', 'operstatus'),
      'conditionExpr': conditionExpr,
      'countersPollInterval': ctrCfg.get('countersPollInterval'),
      'customConditionScript': custCfg.get('customConditionScript', ''),
      'customPollInterval': custCfg.get('customPollInterval'),
      'timeout': advCfg.get('timeout'),
      'timeoutTerminate': advCfg.get('timeoutTerminate', False),
      'asynchronous': advCfg.get('asynchronous', False),
      'thresholdWindow': advCfg.get('thresholdWindow'),
      'thresholdCount': advCfg.get('thresholdCount'),
      'repeatInterval': advCfg.get('repeatInterval'),
      'repeatCount': advCfg.get('repeatCount'),
    }

if not handlerConfigs:
  return
%>
% for hndlr in handlerConfigs:
<% cfg = handlerConfigs[hndlr] %>
event-handler ${hndlr}
% if cfg['triggerType'] == 'on-intf':
   trigger on-intf ${cfg['intfName']} ${cfg['intfTriggerOn']}
% elif cfg['triggerType'] == 'on-logging':
   trigger on-logging
% elif cfg['triggerType'] == 'on-counters':
   trigger on-counters
% elif cfg['triggerType'] == 'on-custom-condition':
   trigger on-custom-condition
% else:
   trigger ${cfg['triggerType']}
% endif
% if cfg['triggerType'] == 'on-logging' and cfg['loggingRegex']:
      regex ${cfg['loggingRegex']}
% endif
% if cfg['triggerType'] == 'on-logging' and cfg['loggingPollInterval']:
      poll interval ${cfg['loggingPollInterval']}
% endif
% if cfg['triggerType'] == 'on-counters' and cfg['countersPollInterval']:
      poll interval ${cfg['countersPollInterval']}
% endif
% if cfg['triggerType'] == 'on-custom-condition' and cfg['customPollInterval']:
      poll interval ${cfg['customPollInterval']}
% endif
% if cfg['triggerType'] == 'on-counters' and cfg['conditionExpr']:
      condition ${cfg['conditionExpr']}
% endif
% if cfg['triggerType'] == 'on-custom-condition' and cfg['customConditionScript']:
      condition bash
% for line in cfg['customConditionScript'].strip().split('\n'):
         ${line}
% endfor
         EOF
% endif
   action bash ${cfg['actionCommand']}
% if cfg['delay'] is not None:
   delay ${cfg['delay']}
% endif
% if cfg['timeout'] is not None:
% if cfg['timeoutTerminate']:
   timeout ${cfg['timeout']} terminate
% else:
   timeout ${cfg['timeout']}
% endif
% endif
% if cfg['asynchronous']:
   asynchronous
% endif
% if cfg['triggerOnConfigDisabled']:
   trigger on-config disabled
% endif
% if cfg['thresholdWindow'] is not None and cfg['thresholdCount'] is not None:
   threshold ${cfg['thresholdWindow']} count ${cfg['thresholdCount']}
% endif
% if cfg['repeatInterval'] is not None:
% if cfg['repeatCount'] is not None:
   repeat interval ${cfg['repeatInterval']} count ${cfg['repeatCount']}
% else:
   repeat interval ${cfg['repeatInterval']}
% endif
% endif
!
% endfor
