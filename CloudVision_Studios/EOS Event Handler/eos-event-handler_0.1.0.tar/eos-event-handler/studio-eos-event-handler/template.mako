<%
  if not ehDeviceSets:
    return
  devSetsCfg, devSetsCtx = ehDeviceSets.resolveWithContext()
  if not devSetsCfg or not devSetsCfg.get('ehConfig'):
    return
  ehConfig = devSetsCfg['ehConfig']
  handlers = ehConfig.get('eventHandlers', [])
  if not handlers:
    return
%>
% for h in handlers:
<%
  handlerName = h['handlerName']
  triggerType = h['triggerType']
  actionCommand = h['actionCommand']
  delay = h.get('delay')
  triggerOnConfigDisabled = h.get('triggerOnConfigDisabled', False)

  logCfg = h.get('onLoggingConfig', {})
  loggingRegex = logCfg.get('loggingRegex', '')
  loggingPollInterval = logCfg.get('loggingPollInterval')

  intfCfg = h.get('onIntfConfig', {})
  intfName = intfCfg.get('intfName', '')
  intfTriggerOn = intfCfg.get('intfTriggerOn', '')

  ctrCfg = h.get('onCountersConfig', {})
  conditionExpr = ctrCfg.get('conditionExpr', '')
  countersPollInterval = ctrCfg.get('countersPollInterval')

  custCfg = h.get('onCustomConditionConfig', {})
  customConditionScript = custCfg.get('customConditionScript', '')
  customPollInterval = custCfg.get('customPollInterval')

  advCfg = h.get('advancedConfig', {})
  timeout = advCfg.get('timeout')
  timeoutTerminate = advCfg.get('timeoutTerminate', False)
  asynchronous = advCfg.get('asynchronous', False)
  thresholdWindow = advCfg.get('thresholdWindow')
  thresholdCount = advCfg.get('thresholdCount')
  repeatInterval = advCfg.get('repeatInterval')
  repeatCount = advCfg.get('repeatCount')
%>
event-handler ${handlerName}
% if triggerType == 'on-intf' and intfName:
   trigger on-intf ${intfName} ${intfTriggerOn}
% elif triggerType == 'on-logging':
   trigger on-logging
% elif triggerType == 'on-counters':
   trigger on-counters
% elif triggerType == 'on-custom-condition':
   trigger on-custom-condition
% else:
   trigger ${triggerType}
% endif
% if triggerType == 'on-logging' and loggingRegex:
      regex ${loggingRegex}
% endif
% if triggerType == 'on-logging' and loggingPollInterval:
      poll interval ${loggingPollInterval}
% endif
% if triggerType == 'on-counters' and countersPollInterval:
      poll interval ${countersPollInterval}
% endif
% if triggerType == 'on-custom-condition' and customPollInterval:
      poll interval ${customPollInterval}
% endif
% if triggerType == 'on-counters' and conditionExpr:
      condition ${conditionExpr}
% endif
% if triggerType == 'on-custom-condition' and customConditionScript:
      condition bash
% for line in customConditionScript.strip().split('\n'):
         ${line}
% endfor
         EOF
% endif
   action bash ${actionCommand}
% if delay is not None:
   delay ${delay}
% endif
% if timeout is not None:
% if timeoutTerminate:
   timeout ${timeout} terminate
% else:
   timeout ${timeout}
% endif
% endif
% if asynchronous:
   asynchronous
% endif
% if triggerOnConfigDisabled:
   trigger on-config disabled
% endif
% if thresholdWindow is not None and thresholdCount is not None:
   threshold ${thresholdWindow} count ${thresholdCount}
% endif
% if repeatInterval is not None:
% if repeatCount is not None:
   repeat interval ${repeatInterval} count ${repeatCount}
% else:
   repeat interval ${repeatInterval}
% endif
% endif
!
% endfor
