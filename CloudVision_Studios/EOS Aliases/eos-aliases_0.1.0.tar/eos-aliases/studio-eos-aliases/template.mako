<%
  if not aliasDeviceSets:
    return
  devSetsCfg, devSetsCtx = aliasDeviceSets.resolveWithContext()
  if not devSetsCfg or not devSetsCfg.get('aliasConfig'):
    return
  aliasConfig = devSetsCfg['aliasConfig']
  aliases = aliasConfig.get('aliases', [])
  if not aliases:
    return
%>
% for a in aliases:
<%
  aName = a.get('aliasName', '')
  aCommand = a.get('aliasCommand', '')
  if not aName or not aCommand:
    continue
%>
alias ${aName} ${aCommand}
% endfor
