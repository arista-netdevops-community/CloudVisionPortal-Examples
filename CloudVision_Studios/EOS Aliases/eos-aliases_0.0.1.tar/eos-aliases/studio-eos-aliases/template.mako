<%
from cloudvision import cvlib

def makeInputError(message, inputPath, fieldId):
  return cvlib.InputError(message=message, inputPath=inputPath, fieldId=fieldId, members=[])

if not deviceSets:
  return

_, firstCtx = deviceSets.resolveWithContext()
if firstCtx is None:
  return

currentDevice = firstCtx.device
aliasCfgs = {}

for dev, devSetsCfg, devSetsCtx in deviceSets.resolveAllWithContext(strict=True):
  if dev != currentDevice:
    continue
  if not devSetsCfg or not devSetsCfg.get('config'):
    continue

  inputPath = ["deviceSets", str(devSetsCtx.index)]

  for aliasDef in devSetsCfg['config'].get('aliases', []):
    name = aliasDef.get('name', '')
    cmd = aliasDef.get('command', '')
    if not name:
      raise cvlib.InputErrorException(inputErrors=[makeInputError(
        "Alias name is required", inputPath, "name")])
    if not cmd:
      raise cvlib.InputErrorException(inputErrors=[makeInputError(
        "Alias command is required for alias '%s'" % name, inputPath, "command")])
    aliasCfgs[name] = cmd

if not aliasCfgs:
  return
%>
% for name in aliasCfgs:
<% cmd = aliasCfgs[name] %>
alias ${name} ${cmd}
% endfor
