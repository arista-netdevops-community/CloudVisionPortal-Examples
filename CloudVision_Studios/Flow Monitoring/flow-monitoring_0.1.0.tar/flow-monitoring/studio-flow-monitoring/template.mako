<%
  from cloudvision import cvlib

  hasIpfix = False
  hasSflow = False

  if ipfixDeviceSets:
    ipfixCfg, ipfixCtx = ipfixDeviceSets.resolveWithContext()
    if ipfixCfg and ipfixCfg.get('ipfixConfig'):
      hasIpfix = True

  if sflowDeviceSets:
    sflowCfg, sflowCtx = sflowDeviceSets.resolveWithContext()
    if sflowCfg and sflowCfg.get('sflowConfig'):
      hasSflow = True

  if hasIpfix and hasSflow:
    message = "This device is assigned to both IPFIX and sFlow. Remove it from one."
    inputPath = ["ipfixDeviceSets", str(ipfixCtx.index)]
    fieldId = "ipfixConfig"
    inputErrors = [cvlib.InputError(message=message, inputPath=inputPath, fieldId=fieldId, members=[])]
    raise cvlib.InputErrorException(inputErrors=inputErrors)

  if not hasIpfix and not hasSflow:
    return
%>
% if hasIpfix:
<%
  cfg = ipfixCfg['ipfixConfig']
  sourceInterface = cfg.get('sourceInterface')
  sampleRate = cfg.get('sampleRate', 1000000)
  collectorAddress = cfg.get('collectorAddress', '127.0.0.1')
  trackerName = cfg.get('trackerName')
  exporterName = cfg.get('exporterName')
  ipfixPort = cfg.get('ipfixPort', 4739)

  if not sourceInterface:
    message = "Source interface is required for IPFIX (e.g. Loopback0)"
    inputPath = ["ipfixDeviceSets", str(ipfixCtx.index)]
    fieldId = "ipfix_sourceInterface"
    inputErrors = [cvlib.InputError(message=message, inputPath=inputPath, fieldId=fieldId, members=[])]
    raise cvlib.InputErrorException(inputErrors=inputErrors)

  if not trackerName or not exporterName:
    message = "Tracker name and exporter name are required for IPFIX"
    inputPath = ["ipfixDeviceSets", str(ipfixCtx.index)]
    fieldId = "trackerName"
    inputErrors = [cvlib.InputError(message=message, inputPath=inputPath, fieldId=fieldId, members=[])]
    raise cvlib.InputErrorException(inputErrors=inputErrors)

  loopbackCfg = cfg.get('loopbackConfig', {})
  createLoopback = loopbackCfg.get('createLoopback', False)
  loopbackNumber = loopbackCfg.get('loopbackNumber')
  loopbackDescription = loopbackCfg.get('loopbackDescription', '')
  loopbackAddress = loopbackCfg.get('loopbackAddress')

  if createLoopback and (loopbackNumber is None or not loopbackAddress):
    message = "Loopback number and IP address are required when Create Loopback is enabled"
    inputPath = ["ipfixDeviceSets", str(ipfixCtx.index)]
    fieldId = "ipfix_loopbackNumber"
    inputErrors = [cvlib.InputError(message=message, inputPath=inputPath, fieldId=fieldId, members=[])]
    raise cvlib.InputErrorException(inputErrors=inputErrors)
%>
% if createLoopback:
interface Loopback${loopbackNumber}
% if loopbackDescription:
   description ${loopbackDescription}
% endif
   ip address ${loopbackAddress}
!
% endif
flow tracking sampled
   sample ${sampleRate}
   tracker ${trackerName}
      exporter ${exporterName}
         collector ${collectorAddress} port ${ipfixPort}
         local interface ${sourceInterface}
   no shutdown
% endif
% if hasSflow:
<%
  cfg = sflowCfg['sflowConfig']
  sourceInterface = cfg.get('sourceInterface')
  sampleRate = cfg.get('sampleRate', 1000000)
  collectorAddress = cfg.get('collectorAddress', '127.0.0.1')
  sflowPollingInterval = cfg.get('sflowPollingInterval', 10)
  sflowPort = cfg.get('sflowPort', 6343)

  if not sourceInterface:
    message = "Source interface is required for sFlow (e.g. Loopback0)"
    inputPath = ["sflowDeviceSets", str(sflowCtx.index)]
    fieldId = "sflow_sourceInterface"
    inputErrors = [cvlib.InputError(message=message, inputPath=inputPath, fieldId=fieldId, members=[])]
    raise cvlib.InputErrorException(inputErrors=inputErrors)

  loopbackCfg = cfg.get('loopbackConfig', {})
  createLoopback = loopbackCfg.get('createLoopback', False)
  loopbackNumber = loopbackCfg.get('loopbackNumber')
  loopbackDescription = loopbackCfg.get('loopbackDescription', '')
  loopbackAddress = loopbackCfg.get('loopbackAddress')

  if createLoopback and (loopbackNumber is None or not loopbackAddress):
    message = "Loopback number and IP address are required when Create Loopback is enabled"
    inputPath = ["sflowDeviceSets", str(sflowCtx.index)]
    fieldId = "sflow_loopbackNumber"
    inputErrors = [cvlib.InputError(message=message, inputPath=inputPath, fieldId=fieldId, members=[])]
    raise cvlib.InputErrorException(inputErrors=inputErrors)
%>
% if createLoopback:
interface Loopback${loopbackNumber}
% if loopbackDescription:
   description ${loopbackDescription}
% endif
   ip address ${loopbackAddress}
!
% endif
sflow sample ${sampleRate}
sflow polling-interval ${sflowPollingInterval}
sflow source-interface ${sourceInterface}
sflow destination ${collectorAddress} ${sflowPort}
sflow run
% endif
