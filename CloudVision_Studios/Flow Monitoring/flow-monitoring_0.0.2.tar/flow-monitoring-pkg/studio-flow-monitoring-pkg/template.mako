<%
from cloudvision import cvlib

def makeInputError(message, inputPath, fieldId):
  return cvlib.InputError(message=message, inputPath=inputPath, fieldId=fieldId, members=[])

# Template mainline start
hasIpfix = False
hasSflow = False
ipfixVars = {}
sflowVars = {}

if ipfixDeviceSets:
  ipfixCfg, ipfixCtx = ipfixDeviceSets.resolveWithContext()
  if ipfixCfg and ipfixCfg.get('ipfixConfig'):
    hasIpfix = True

if sflowDeviceSets:
  sflowCfg, sflowCtx = sflowDeviceSets.resolveWithContext()
  if sflowCfg and sflowCfg.get('sflowConfig'):
    hasSflow = True

if hasIpfix and hasSflow:
  message = "This device is assigned to both IPFIX and sFlow device sets. Remove it from either the IPFIX or sFlow resolver to resolve the conflict."
  raise cvlib.InputErrorException(inputErrors=[
    makeInputError(message, ["ipfixDeviceSets", str(ipfixCtx.index)], "ipfixConfig"),
    makeInputError(message, ["sflowDeviceSets", str(sflowCtx.index)], "sflowConfig"),
  ])

if not hasIpfix and not hasSflow:
  return

if hasIpfix:
  cfg = ipfixCfg['ipfixConfig']
  inputPath = ["ipfixDeviceSets", str(ipfixCtx.index)]

  sourceInterface = (cfg.get('sourceInterface') or '').strip()
  sampleRate = cfg.get('sampleRate')
  if sampleRate is None:
    sampleRate = 1000000
  collectorAddress = cfg.get('collectorAddress') or '127.0.0.1'
  trackerName = (cfg.get('trackerName') or '').strip()
  exporterName = (cfg.get('exporterName') or '').strip()
  port = cfg.get('port') or 4739

  if not sourceInterface:
    raise cvlib.InputErrorException(inputErrors=[makeInputError(
      "Source interface is required for IPFIX (e.g. Loopback0)",
      inputPath, "ipfix_sourceInterface")])

  if not trackerName or not exporterName:
    raise cvlib.InputErrorException(inputErrors=[makeInputError(
      "Tracker name and exporter name are required for IPFIX",
      inputPath, "trackerName")])

  if not isinstance(sampleRate, int) or sampleRate < 1 or sampleRate > 16777215:
    raise cvlib.InputErrorException(inputErrors=[makeInputError(
      "Sample rate must be a positive integer (EOS range: 1-16777215)",
      inputPath, "ipfix_sampleRate")])

  loopbackCfg = cfg.get('loopbackConfig') or {}
  createLoopback = loopbackCfg.get('createLoopback', False)
  loopbackNumber = loopbackCfg.get('loopbackNumber')
  loopbackDescription = loopbackCfg.get('loopbackDescription', '')
  loopbackAddress = loopbackCfg.get('loopbackAddress')

  if createLoopback and (loopbackNumber is None or not loopbackAddress):
    raise cvlib.InputErrorException(inputErrors=[makeInputError(
      "Loopback number and IP address are required when Create Loopback is enabled",
      inputPath, "ipfix_loopbackNumber")])

  if createLoopback and sourceInterface != 'Loopback' + str(loopbackNumber):
    raise cvlib.InputErrorException(inputErrors=[makeInputError(
      "Source interface must match the loopback being created (Loopback" + str(loopbackNumber) + "). Update source interface or disable Create Loopback.",
      inputPath, "ipfix_sourceInterface")])

  ipfixInterfaces = []
  deviceResolver = cfg.get('deviceResolver')
  if deviceResolver:
    devCfg, devCtx = deviceResolver.resolveWithContext()
    if devCfg and devCfg.get('interfaceResolver'):
      intfResolver = devCfg['interfaceResolver']
      for idx, intf in enumerate(intfResolver.resolveAll(strict=True)):
        ipfixInterfaces.append(intf[0])

  ipfixVars = {
    'sourceInterface': sourceInterface,
    'sampleRate': sampleRate,
    'collectorAddress': collectorAddress,
    'trackerName': trackerName,
    'exporterName': exporterName,
    'port': port,
    'createLoopback': createLoopback,
    'loopbackNumber': loopbackNumber,
    'loopbackDescription': loopbackDescription,
    'loopbackAddress': loopbackAddress,
    'interfaces': ipfixInterfaces,
  }

if hasSflow:
  cfg = sflowCfg['sflowConfig']
  inputPath = ["sflowDeviceSets", str(sflowCtx.index)]

  sourceInterface = (cfg.get('sourceInterface') or '').strip()
  sampleRate = cfg.get('sampleRate')
  if sampleRate is None:
    sampleRate = 1000000
  collectorAddress = cfg.get('collectorAddress') or '127.0.0.1'
  pollingInterval = cfg.get('pollingInterval')
  if pollingInterval is None:
    pollingInterval = 10
  port = cfg.get('port') or 6343

  if not sourceInterface:
    raise cvlib.InputErrorException(inputErrors=[makeInputError(
      "Source interface is required for sFlow (e.g. Loopback0)",
      inputPath, "sflow_sourceInterface")])

  if not isinstance(sampleRate, int) or sampleRate < 1 or sampleRate > 4294967295:
    raise cvlib.InputErrorException(inputErrors=[makeInputError(
      "Sample rate must be a positive integer (EOS range: 1-4294967295)",
      inputPath, "sflow_sampleRate")])

  loopbackCfg = cfg.get('loopbackConfig') or {}
  createLoopback = loopbackCfg.get('createLoopback', False)
  loopbackNumber = loopbackCfg.get('loopbackNumber')
  loopbackDescription = loopbackCfg.get('loopbackDescription', '')
  loopbackAddress = loopbackCfg.get('loopbackAddress')

  if createLoopback and (loopbackNumber is None or not loopbackAddress):
    raise cvlib.InputErrorException(inputErrors=[makeInputError(
      "Loopback number and IP address are required when Create Loopback is enabled",
      inputPath, "sflow_loopbackNumber")])

  if createLoopback and sourceInterface != 'Loopback' + str(loopbackNumber):
    raise cvlib.InputErrorException(inputErrors=[makeInputError(
      "Source interface must match the loopback being created (Loopback" + str(loopbackNumber) + "). Update source interface or disable Create Loopback.",
      inputPath, "sflow_sourceInterface")])

  sflowInterfaces = []
  deviceResolver = cfg.get('deviceResolver')
  if deviceResolver:
    devCfg, devCtx = deviceResolver.resolveWithContext()
    if devCfg and devCfg.get('interfaceResolver'):
      intfResolver = devCfg['interfaceResolver']
      for idx, intf in enumerate(intfResolver.resolveAll(strict=True)):
        sflowInterfaces.append(intf[0])

  sflowVars = {
    'sourceInterface': sourceInterface,
    'sampleRate': sampleRate,
    'collectorAddress': collectorAddress,
    'pollingInterval': pollingInterval,
    'port': port,
    'createLoopback': createLoopback,
    'loopbackNumber': loopbackNumber,
    'loopbackDescription': loopbackDescription,
    'loopbackAddress': loopbackAddress,
    'interfaces': sflowInterfaces,
  }
%>
% if hasIpfix:
<% v = ipfixVars %>
% if v['createLoopback']:
interface Loopback${v['loopbackNumber']}
% if v['loopbackDescription']:
   description ${v['loopbackDescription']}
% endif
   ip address ${v['loopbackAddress']}
!
% endif
flow tracking sampled
   sample ${v['sampleRate']}
   tracker ${v['trackerName']}
      exporter ${v['exporterName']}
         collector ${v['collectorAddress']} port ${v['port']}
         local interface ${v['sourceInterface']}
   no shutdown
!
% for intfName in v['interfaces']:
interface ${intfName}
   flow tracker sampled ${v['trackerName']}
% endfor
% endif
% if hasSflow:
<% v = sflowVars %>
% if v['createLoopback']:
interface Loopback${v['loopbackNumber']}
% if v['loopbackDescription']:
   description ${v['loopbackDescription']}
% endif
   ip address ${v['loopbackAddress']}
!
% endif
sflow sample ${v['sampleRate']}
sflow polling-interval ${v['pollingInterval']}
sflow source-interface ${v['sourceInterface']}
sflow destination ${v['collectorAddress']} ${v['port']}
sflow run
% for intfName in v['interfaces']:
interface ${intfName}
   sflow enable
% endfor
% endif
