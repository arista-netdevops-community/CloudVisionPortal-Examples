# pylint: disable=import-error
"""MPLS Service Manager — CloudVision Studios autofill action.

Provisions MPLS circuits by collecting inputs from the Customer Studio,
generating EOS CLI configlets per service type (Direct Internet Access,
VPN-V4, L3-EVPN, L2-EVPN, L2-EVPN + IRB, VPLS, VPWS) and pushing
them to the Configlet Studio.

Also manages interface tags for dashboard visibility and cleans up stale
tags when circuits are re-provisioned.
"""
import re
import ipaddress
from datetime import datetime

from cloudvision.cvlib import (
    ActionFailed,
    extractStudioInfoFromArgs,
    InputUpdateException,
    InputNotFoundException,
    getStudioInputs,
    setStudioInput,
)
from cloudvision.cvlib.tags import Tag

# ID of the Configlet Studio that receives the generated CLI
cliStdID = "efb1783f-fd75-4165-92a9-434ed2edc2c0"


# =============================================================================
# Tag Utilities
# =============================================================================

def splitTagToDeviceNames(tag):
    """Split a tag query string into a list of device names."""
    if "," in tag:
        tagSplit = tag.split(',')
    else:
        tagSplit = tag.split('|')
    deviceNames = []
    for name in tagSplit:
        name = name.strip()
        dev = name.removeprefix('device:')
        deviceNames.append(dev)
    return deviceNames


def interfaceTags(deviceNameList, interface, subinterface, customerName,
                  circuitId, serviceType, connectionType, _vrfName, pendingTags):
    """Accumulate interface tags into pendingTags for batch assignment.

    Tags Customer_Name, Circuit_ID, Service_Type, Link-Type, Last-Modified,
    and Connection_Type onto each interface — used by dashboards to display
    circuit status per device.
    """
    time = datetime.now()
    current_datetime = time.strftime("%Y-%m-%dT%H:%M:%S")
    if subinterface:
        interfaceCat = interface + "." + subinterface
    else:
        interfaceCat = interface
    for deviceId in deviceNameList:
        pendingTags.append((deviceId, interfaceCat, 'Customer_Name', customerName, False))
        pendingTags.append((deviceId, interfaceCat, 'Circuit_ID', circuitId, False))
        pendingTags.append((deviceId, interfaceCat, 'Service_Type', serviceType, False))
        pendingTags.append((deviceId, interface, 'Link-Type', 'Customer', False))
        pendingTags.append((deviceId, interfaceCat, 'Last-Modified', current_datetime, False))
        pendingTags.append((deviceId, interfaceCat, 'Connection_Type', connectionType, False))


def clean_up_interface_tags(deviceId, circuitId, allIntfTags):
    """Remove all interface tags for a given circuit on a device.

    Called before re-provisioning so stale tags from a previous run
    don't persist on interfaces that may have changed.
    """
    listOfTags = []
    device_details = allIntfTags.get(deviceId, {})
    for interface, interface_details in device_details.items():
        foundInterface = False
        for label, label_details in interface_details.items():
            if label == 'Circuit_ID':
                if label_details[0] == circuitId:
                    foundInterface = True
                    break
        # Delete all tags on interfaces previously configured by this tool
        if foundInterface:
            for label, label_details in interface_details.items():
                unTag = (deviceId, interface, label, None)
                listOfTags.append(unTag)
    if listOfTags:
        ctx.tags._unassignInterfaceTags(listOfTags)


# =============================================================================
# CLI Generators
# =============================================================================

def processFlexEncap(flexEncap, clientDot1QVlan, clientDot1QInnerVlan):
    """Generate EOS flexible encapsulation CLI based on the encap type."""
    if not flexEncap:
        return ""
    if flexEncap == "client dot1q vlan":
        if clientDot1QVlan:
            flexEncap = f"""encapsulation vlan
        client dot1q {clientDot1QVlan}"""
        else:
            raise ActionFailed("Please enter a Client Vlan Tag")
    elif flexEncap == "client unmatched":
        flexEncap = """encapsulation vlan
        client unmatched"""
    elif flexEncap == "client untagged":
        flexEncap = """encapsulation vlan
        client untagged"""
    elif flexEncap == "client dot1q outer vlan inner vlan":
        if clientDot1QVlan and clientDot1QInnerVlan:
            flexEncap = f"""encapsulation vlan
        client dot1q outer {clientDot1QVlan} inner {clientDot1QInnerVlan}"""
        else:
            raise ActionFailed("Please enter a Client Vlan Tag and Inner Vlan Tag")
    return flexEncap


def processStaticRoutes(staticRoutes, vrfName):
    """Generate EOS static route CLI lines. Uses VRF syntax for VPN-V4/L3-EVPN, global for Direct Internet Access."""
    srLineCat = ""
    for route in staticRoutes:
        if vrfName:
            if route.get("description"):
                srLine = f"""
ip route vrf {vrfName} {route.get("prefix")} {route.get("nextHop")} name {route.get("description")}
    """
            else:
                srLine = f"""
ip route vrf {vrfName} {route.get("prefix")} {route.get("nextHop")}
    """
        else:
            if route.get("description"):
                srLine = f"""
ip route {route.get("prefix")} {route.get("nextHop")} name {route.get("description")}
    """
            else:
                srLine = f"""
ip route {route.get("prefix")} {route.get("nextHop")}
    """
        srLineCat = srLineCat + srLine
    srLineCat = srLineCat + "\n!"
    return srLineCat


def processPrefixLists(prefixList, remoteAsn, direction, circuitId):
    """Generate EOS ip prefix-list CLI for inbound or outbound filtering."""
    pfLineCat = ""
    if prefixList and direction == "IN":
        pfLineCat = f"""
ip prefix-list PL_AS{remoteAsn}_{circuitId}_IN
    """
    if prefixList and direction == "OUT":
        pfLineCat = f"""
ip prefix-list PL_AS{remoteAsn}_{circuitId}_OUT
    """
    if prefixList:
        for prefix in prefixList:
            mLen = prefix.get("matchType")
            if mLen != "exact":
                pfLine = f"""seq {prefix.get("seqNum")} {prefix.get("permitDeny")} {prefix.get("prefix")} {prefix.get("matchType")} {prefix.get("maskLength")}
        """
            else:
                pfLine = f"""seq {prefix.get("seqNum")} {prefix.get("permitDeny")} {prefix.get("prefix")}
        """
            pfLineCat = pfLineCat + pfLine
    pfLineCat = pfLineCat + "\n    exit\n!"
    return pfLineCat


def processRouteMaps(remoteAsn, direction):
    """Generate EOS route-map CLI referencing a prefix-list for the given direction."""
    rmLine = ""
    if direction == "IN":
        rmLine = f"""route-map RM{remoteAsn}-IN permit 10
    match ip address prefix-list PL_AS{remoteAsn}_IN
    exit
    !
        """
    if direction == "OUT":
        rmLine = f"""route-map RM{remoteAsn}-OUT permit 10
    match ip address prefix-list PL_AS{remoteAsn}_OUT
    exit
    !
        """
    return rmLine


def processDiaRcf(bgpNeighborAsn, circuitId):
    """Generate RCF (Route Control Function) CLI for Direct Internet Access inbound policy."""
    rcfIn = f"""router general
    control-functions
       code unit AS{bgpNeighborAsn}_{circuitId}_RCF
    """
    rcf1 = f"""   function AS{bgpNeighborAsn}_{circuitId}_IN()
    """
    rcf2 = f"""PL_AS{bgpNeighborAsn}_{circuitId});
    """
    rcf3 = """       EOF
       compile
       commit
       exit
    exit
       """
    rcf = rcfIn + rcf1 + "   {\n         return DIA_INBOUND(prefix_list_v4 " + rcf2 + "\n       }\n" + rcf3
    rcf = ""  # RCF disabled — remove this line to enable Direct Internet Access RCF
    return rcf


def processMplsRcfIn():
    """Generate RCF CLI for VPN-V4 inbound policy (LOCAL_PREF community check)."""
    rcf1 = """router general
    control-functions
        code unit CUSTOMER_PEERING
    """
    rcf2 = """     function LOCAL_PREF75_COMMUNITY_IS_PRESENT()
    """
    rcfPart1 = rcf1 + rcf2 + "    {\n" + "        return community has_any {26554:75};\n" + "\n        }\n"
    rcf5 = """        function VPN-V4_CUSTOMER_INBOUND()
    """
    rcf7 = """       EOF
       compile
       commit
       exit
    exit
       """
    rcfPart2 = rcf5 + "    {\n" + """        if LOCAL_PREF75_COMMUNITY_IS_PRESENT() {

              local_preference = 75;

          }

          return true;\n""" + "\n       }\n" + rcf7
    rcf = rcfPart1 + rcfPart2
    rcf = ""  # RCF disabled — remove this line to enable VPN-V4 RCF IN
    return rcf


def processMplsRcfOut(bgpNeighborAsn):
    """Generate RCF CLI for VPN-V4 outbound policy (prefix-list match)."""
    rcf1 = f"""router general
    control-functions
        code unit NET_SOURCE_AS{bgpNeighborAsn}_RCF
    """
    rcf2 = f"""   function NET_SOURCE_AS{bgpNeighborAsn}_OUT()
    """
    rcf3 = """          return prefix match prefix_list_v4 """
    rcf4 = f"""PL_AS{bgpNeighborAsn};
    """
    rcf5 = """       EOF
       compile
       commit
       exit
    exit
       """
    rcf = rcf1 + rcf2 + " {\n " + rcf3 + rcf4 + "\n       }\n" + rcf5
    rcf = ""  # RCF disabled — remove this line to enable VPN-V4 RCF OUT
    return rcf


# =============================================================================
# Interface and ESI Helpers
# =============================================================================

def processPortChannels(interface, dualAttachedPortChannel, otherPortChannelMember, customerName, connectionType):
    """Generate EOS CLI for Port-Channel member Ethernet interfaces."""
    poNum = interface.removeprefix("Port-Channel")
    poMember = poNum
    if connectionType == "NNI":
        description = ""
    else:
        description = f"description {customerName}"
    # Ports above 48 need a slash added in the name
    if int(poNum) > 48:
        poMember = poNum + "/1"
    if dualAttachedPortChannel:
        ethernetPort = f"""
interface Ethernet{poMember}
    {description}
    no switchport
    no lldp transmit
    channel-group {poNum} mode active
!
interface {otherPortChannelMember}
    {description}
    no switchport
    no lldp transmit
    channel-group {poNum} mode active
    """
    else:
        ethernetPort = f"""
interface Ethernet{poMember}
    {description}
    no switchport
    no lldp transmit
    channel-group {poNum} mode active
    """
    return ethernetPort


def calculateEsi(paddedEsi, interface, subinterface):
    """Calculate the EVPN Ethernet Segment Identifier from the ESI prefix, interface, and subinterface."""
    intNum = ""
    if "Ethernet" in interface:
        intNum = interface.removeprefix("Ethernet")
        if "/" in intNum:
            intNumTemp = intNum.replace("/", "")
            intNum = intNumTemp[:-1]
    if "Port-Channel" in interface:
        intNum = interface.removeprefix("Port-Channel")
    intNum = intNum.lstrip()
    index = 0
    while index < 2:
        index = index + 1
        if index > len(intNum):
            intNum = "0" + intNum
    intNum = intNum + ":"
    index = 0
    while index < 4:
        index = index + 1
        if index > len(subinterface):
            subinterface = "0" + subinterface

    esi = paddedEsi + intNum + subinterface
    return esi


def buildEsiPrefix(lo0Address1, lo0Address2):
    """Build the ESI prefix string from the last 2 octets of both PE loopbacks.

    Used for multi-homed circuits to generate a deterministic ESI
    based on both PE router IDs.
    """
    lo0Address1Esi = lo0Address1
    lo0Address2Esi = lo0Address2
    index = lo0Address1.find(".")
    if index != -1:
        lo0Address1Esi = lo0Address1[index + 1:]
    index = lo0Address1Esi.find(".")
    if index != -1:
        lo0Address1Esi = lo0Address1Esi[index + 1:]

    index = lo0Address2.find(".")
    if index != -1:
        lo0Address2Esi = lo0Address2[index + 1:]
    index = lo0Address2Esi.find(".")
    if index != -1:
        lo0Address2Esi = lo0Address2Esi[index + 1:]

    lo0CatList = lo0Address1Esi.split('.') + lo0Address2Esi.split('.')
    lo0Cat = "00" + "".join(lo0CatList)
    index = 0
    while index < 14:
        index = index + 1
        if index > len(lo0Cat):
            lo0Cat = lo0Cat + "0"
    paddedEsi = ""
    index = 0
    for char in lo0Cat:
        if index % 4 == 0 and index != 0:
            paddedEsi = paddedEsi + ":"
        paddedEsi = paddedEsi + char
        index = index + 1
    return paddedEsi


# =============================================================================
# Service-Type Interface Processors
# =============================================================================

def processL2EvpnInterfaces(deviceNameList, l2EvpnInterfaces, paddedEsi, multiHoming, customerName, bgpSessionTrackingCLI, circuitId, serviceType, vlan, flexEncap, serviceLevelConfig, dualAttachedPortChannel, otherPortChannelMember, connectionType, pendingTags):
    """Generate interface CLI and multi-homing config for L2-EVPN / L2-EVPN + IRB circuits.

    Returns (interfacesListCat1, interfacesListCat2, autoRT) — separate CLI
    for device 1 and device 2 in multi-homed scenarios, plus the auto-RT config.
    """
    interfacesListCat1 = ""
    interfacesListCat2 = ""
    autoRT = ""
    vrfName = ""
    if vlan:
        vlanId = f"vlan id {vlan}"
    else:
        raise ActionFailed("Please enter a Vlan ID")
    if connectionType == "NNI":
        description = ""
    else:
        description = f"description {customerName}"
    if l2EvpnInterfaces is not None:
        for l2EvpnInterface in l2EvpnInterfaces:
            interface = l2EvpnInterface.get("interface")
            if not ("Port-Channel" in interface or "Ethernet" in interface):
                raise ActionFailed("Check the spelling of Ethernet or Port-Channel")
            subinterface = l2EvpnInterface.get("subInterface")
            if not subinterface:
                raise ActionFailed("Please enter a sub interface number")
            interfaceTags(deviceNameList, interface, subinterface, customerName, circuitId, serviceType, connectionType, vrfName, pendingTags)
            esi = calculateEsi(paddedEsi, interface, subinterface)
            lldp = ""
            if "Port-Channel" in interface:
                ethernetPort = processPortChannels(interface, dualAttachedPortChannel, otherPortChannelMember, customerName, connectionType)
                if multiHoming in ("Active Active Multi Homing", "Single Active Multi Homing"):
                    lacpSysId = "lacp system-id aaaa.bbbb.cccc"
                else:
                    lacpSysId = ""
            else:
                lldp = "no lldp transmit"
                lacpSysId = ""
                ethernetPort = ""
            multiHomingConfig1 = ""
            multiHomingConfig2 = ""
            if multiHoming != "Single Homed":
                autoRT = """
address-family evpn
   route type ethernet-segment route-target auto
   exit
                """
            if multiHoming == "Active Active Multi Homing":
                if "Port-Channel" not in interface:
                    raise ActionFailed("Active Active Multi Homing requires Port-Channel")
                multiHomingConfig1 = f"""evpn ethernet-segment
    identifier {esi}
!"""
                multiHomingConfig2 = f"""evpn ethernet-segment
    identifier {esi}
!"""
            elif multiHoming == "Single Active Multi Homing":
                if "Ethernet" not in interface:
                    raise ActionFailed("Single Active Multi Homing requires Ethernet Interface")
                multiHomingConfig1 = f"""evpn ethernet-segment
    identifier {esi}
    redundancy single-active
    designated-forwarder election algorithm preference 2000 dont-preempt
!"""
                multiHomingConfig2 = f"""evpn ethernet-segment
    identifier {esi}
    redundancy single-active
    designated-forwarder election algorithm preference 1000 dont-preempt
!"""
            interfacesList1 = f"""
{ethernetPort}
!
interface {interface}
    {description}
    {bgpSessionTrackingCLI}
    no switchport
    {lacpSysId}
    {lldp}
!
interface {interface}.{subinterface}
    description {customerName}/{circuitId}/{serviceType}
    {vlanId}
    !
    {flexEncap}
    !
    {serviceLevelConfig}
    {multiHomingConfig1}
    exit
"""
            interfacesList2 = f"""
{ethernetPort}
!
interface {interface}
    {description}
    {bgpSessionTrackingCLI}
    no switchport
    {lacpSysId}
    {lldp}
!
interface {interface}.{subinterface}
    description {customerName}/{circuitId}/{serviceType}
    {vlanId}
    !
    {flexEncap}
    !
    {serviceLevelConfig}
    {multiHomingConfig2}
    exit
"""
            interfacesListCat1 = interfacesListCat1 + interfacesList1
            interfacesListCat2 = interfacesListCat2 + interfacesList2
    return interfacesListCat1, interfacesListCat2, autoRT


def processMplsInterfaces(deviceNameList, vlanInterfaces, ipVpnInterfaces, paddedEsi, multiHoming, customerName, bgpSessionTrackingCLI, circuitId, serviceType, serviceLevelConfig, vrfName, dualAttachedPortChannel, _routingType, l3Encap, otherPortChannelMember, _prefixList, _prefixListOut, connectionType, bgpPolicy, defaultOriginate, flexEncap, clientDot1QVlan, clientDot1QInnerVlan, pendingTags):
    """Generate interface, VLAN SVI, and BGP neighbor CLI for Direct Internet Access / VPN-V4 / L3-EVPN circuits.

    Handles both L3 subinterfaces (ipVpnInterfaces) and VLAN SVI interfaces
    (vlanInterfaces with L2 subinterfaces bridged to the SVI). Produces
    separate CLI for device 1 and device 2 in multi-homed scenarios.
    """
    vlanInterfaceConfigCat1 = ""
    vlanInterfaceConfigCat2 = ""
    vlanNum = None
    if vrfName and serviceType != "Direct Internet Access":
        vrfConfig = f"vrf {vrfName}"
    elif not vrfName and serviceType != "Direct Internet Access":
        raise ActionFailed("Please enter a VRF Name")
    else:
        vrfConfig = ""
    if connectionType == "NNI":
        description = ""
    else:
        description = f"description {customerName}"
    if vlanInterfaces is not None:
        for vlan in vlanInterfaces:
            vlanSubnet = vlan.get("ipAddress")
            firstIP, secondIP, thirdIP, subnetMask = "", "", "", ""
            if vlanSubnet:
                n = ipaddress.IPv4Network(vlanSubnet, strict=False)
                firstIP, secondIP, thirdIP = n[1], n[2], n[3]
                subnetMask = n.prefixlen
            else:
                raise ActionFailed("Please enter a Subnet Address")
            l2SubInterfaceConfig1Cat1 = ""
            l2SubInterfaceConfig1Cat2 = ""
            vlanNum = vlan.get("vlanNumber")
            if not vlanNum:
                raise ActionFailed("Please enter a Vlan Number")
            interface = "Vlan" + str(vlanNum)
            subinterface = ""
            interfaceTags(deviceNameList, interface, subinterface, customerName, circuitId, serviceType, connectionType, vrfName, pendingTags)
            for l2SubInterface in vlan.get("l2SubInterfaces"):
                interface = l2SubInterface.get("interface")
                if not ("Port-Channel" in interface or "Ethernet" in interface):
                    raise ActionFailed("Check the spelling of Ethernet or Port-Channel")
                subInterfaceNumber = l2SubInterface.get("subInterfaceNumber")
                if not subInterfaceNumber:
                    raise ActionFailed("Please enter a sub interface number")
                if vlanNum:
                    vlanId = f"vlan id {vlanNum}"
                else:
                    vlanId = ""
                interfaceTags(deviceNameList, interface, subInterfaceNumber, customerName, circuitId, serviceType, connectionType, vrfName, pendingTags)
                l2FlexEncap = l2SubInterface.get("flexEncap")
                clientDot1QVlan = l2SubInterface.get("clientDot1QVlan")
                clientDot1QInnerVlan = l2SubInterface.get("clientDot1QInnerVlan")
                l2FlexEncap = processFlexEncap(l2FlexEncap, clientDot1QVlan, clientDot1QInnerVlan)
                lldp = ""
                esi = calculateEsi(paddedEsi, interface, subInterfaceNumber)
                if "Port-Channel" in interface:
                    ethernetPort = processPortChannels(interface, dualAttachedPortChannel, otherPortChannelMember, customerName, connectionType)
                    if multiHoming in ("Active Active Multi Homing", "Single Active Multi Homing"):
                        lacpSysId = "lacp system-id aaaa.bbbb.cccc"
                    else:
                        lacpSysId = ""
                else:
                    ethernetPort = ""
                    lldp = "no lldp transmit"
                    lacpSysId = ""
                if multiHoming != "Single Homed":
                    autoRT = """
address-family evpn
    route type ethernet-segment route-target auto
    exit
                    """
                multiHomingConfig1 = ""
                multiHomingConfig2 = ""
                if multiHoming == "Active Active Multi Homing":
                    if "Port-Channel" not in interface:
                        raise ActionFailed("Active Active Multi Homing requires Port-Channel")
                    multiHomingConfig1 = f"""evpn ethernet-segment
    identifier {esi}
!"""
                    multiHomingConfig2 = f"""evpn ethernet-segment
    identifier {esi}
!"""
                elif multiHoming == "Single Active Multi Homing":
                    if "Ethernet" not in interface:
                        raise ActionFailed("Single Active Multi Homing requires Ethernet Interface")
                    multiHomingConfig1 = f"""evpn ethernet-segment
    identifier {esi}
    redundancy single-active
    designated-forwarder election algorithm preference 2000 dont-preempt
!"""
                    multiHomingConfig2 = f"""evpn ethernet-segment
    identifier {esi}
    redundancy single-active
    designated-forwarder election algorithm preference 1000 dont-preempt
!"""
                l2SubInterfaceConfig1 = f"""
{ethernetPort}
!
interface {interface}
    {description}
    {bgpSessionTrackingCLI}
    no switchport
    {lacpSysId}
    {lldp}
!
interface {interface}.{subInterfaceNumber}
    description {customerName}/{circuitId}/{serviceType}
    {vlanId}
    !
    {l2FlexEncap}
    !
    {serviceLevelConfig}
    {multiHomingConfig1}
"""
                l2SubInterfaceConfig2 = f"""
{ethernetPort}
!
interface {interface}
    {description}
    {bgpSessionTrackingCLI}
    no switchport
    {lacpSysId}
    {lldp}
!
interface {interface}.{subInterfaceNumber}
    description {customerName}/{circuitId}/{serviceType}
    {vlanId}
    !
    {l2FlexEncap}
    !
    {serviceLevelConfig}
    {multiHomingConfig2}
"""
                l2SubInterfaceConfig1Cat1 = l2SubInterfaceConfig1Cat1 + l2SubInterfaceConfig1
                l2SubInterfaceConfig1Cat2 = l2SubInterfaceConfig1Cat2 + l2SubInterfaceConfig2
            virtualRouterAddress = f"""ip virtual-router address {firstIP}"""
            vRouterMac = "ip virtual-router mac-address 00:1c:73:00:00:01"
            vlanInterfaceConfig1 = f"""
vlan {vlanNum}
    name {customerName}/{circuitId}/{serviceType}
!
{l2SubInterfaceConfig1Cat1}
!
interface Vlan{vlanNum}
    description {customerName}/{circuitId}/{serviceType}
    {vrfConfig}
    ip address {secondIP}/{subnetMask}
    {virtualRouterAddress}
    {serviceLevelConfig}
!
{vRouterMac}
!
"""
            vlanInterfaceConfig2 = f"""
vlan {vlanNum}
    name {customerName}/{circuitId}/{serviceType}
!
{l2SubInterfaceConfig1Cat2}
!
interface Vlan{vlanNum}
    description {customerName}/{circuitId}/{serviceType}
    {vrfConfig}
    ip address {thirdIP}/{subnetMask}
    {virtualRouterAddress}
    {serviceLevelConfig}
!
{vRouterMac}
!
"""
            vlanInterfaceConfigCat1 = vlanInterfaceConfigCat1 + vlanInterfaceConfig1
            vlanInterfaceConfigCat2 = vlanInterfaceConfigCat2 + vlanInterfaceConfig2
    ipVpnInterfacesListCat = ""
    vrfNeighborCat = " "
    rcfBgpCat = ""
    rcfConfig = ""
    rcfBgpCatOut = ""
    rcfConfigMplsOut = ""
    addressFamilyNeighborCat = " "
    encapConfig = ""
    routeMapIn = ""
    routeMapOut = ""
    autoRT = ""
    if ipVpnInterfaces is not None:
        for ipInterface in ipVpnInterfaces:
            interface = ipInterface.get("interface")
            subinterface = ipInterface.get("subInterface")
            if l3Encap == "Dot1q":
                encapConfig = f"encapsulation dot1q vlan {subinterface}"
            elif l3Encap == "FlexEncap":
                encapConfig = processFlexEncap(flexEncap, clientDot1QVlan, clientDot1QInnerVlan)
            lldp = ""
            if not ("Port-Channel" in interface or "Ethernet" in interface):
                raise ActionFailed("Check the spelling of Ethernet or Port-Channel")
            if "Port-Channel" in interface:
                ethernetPort = processPortChannels(interface, dualAttachedPortChannel, otherPortChannelMember, customerName, connectionType)
            else:
                lldp = "no lldp transmit"
                ethernetPort = ""
            interfaceTags(deviceNameList, interface, subinterface, customerName, circuitId, serviceType, connectionType, vrfName, pendingTags)
            ipVpnInterfacesList = f"""
{ethernetPort}
!
interface {interface}
    {description}
    {bgpSessionTrackingCLI}
    no switchport
    {lldp}
!
interface {interface}.{subinterface}
    description {customerName}/{circuitId}/{serviceType}
    {vrfConfig}
    ip address {ipInterface.get("ipAddress")}
    {encapConfig}
    {serviceLevelConfig}
!
"""
            ipVpnInterfacesListCat = ipVpnInterfacesListCat + ipVpnInterfacesList
            bgpNeighborIp = ipInterface.get("bgpNeighborIp")
            bgpNeighborAsn = ipInterface.get("remoteAsn")
            rcfPolicy = ipInterface.get("rcfOutPolicy")
            if bgpNeighborIp is not None and serviceType == "Direct Internet Access":
                vrfNeighbor = f"""neighbor {bgpNeighborIp} remote-as {bgpNeighborAsn}
         neighbor {bgpNeighborIp} description {customerName}/{circuitId}/{serviceType}
                """
                vrfNeighborCat = vrfNeighborCat + vrfNeighbor
                addressFamilyNeighbor = f"""neighbor {bgpNeighborIp} activate
                """
                addressFamilyNeighborCat = addressFamilyNeighborCat + addressFamilyNeighbor
                if bgpPolicy != "No":
                    rcf = f""" neighbor {bgpNeighborIp} rcf in AS{bgpNeighborAsn}_{circuitId}_IN()
            neighbor {bgpNeighborIp} rcf out {rcfPolicy}
                    """
                    rcfBgpCat = rcfBgpCat + rcf
                    rcfConfig = processDiaRcf(bgpNeighborAsn, circuitId)
            elif bgpNeighborIp is not None and serviceType == "VPN-V4":
                if defaultOriginate:
                    vrfNeighbor = f"""
         neighbor {bgpNeighborIp} remote-as {bgpNeighborAsn}
         neighbor {bgpNeighborIp} description {customerName}/{circuitId}/{serviceType}
         neighbor {bgpNeighborIp} default-originate
         """
                else:
                    vrfNeighbor = f"""
         neighbor {bgpNeighborIp} remote-as {bgpNeighborAsn}
         neighbor {bgpNeighborIp} description {customerName}/{circuitId}/{serviceType}
                """
                vrfNeighborCat = vrfNeighborCat + vrfNeighbor
                addressFamilyNeighbor = f"""neighbor {bgpNeighborIp} activate
         """
                addressFamilyNeighborCat = addressFamilyNeighborCat + addressFamilyNeighbor
                if bgpPolicy != "No":
                    rcf = f"""  neighbor {bgpNeighborIp} rcf in CUSTOMER_PEERING()
                    """
                    rcfOut = f"""  neighbor {bgpNeighborIp} rcf out NET_SOURCE_AS{bgpNeighborAsn}_RCF()
                    """
                    if bgpPolicy in ("In", "In and Out"):
                        rcfBgpCat = rcfBgpCat + rcf
                        rcfConfig = processMplsRcfIn()
                    if bgpPolicy in ("Out", "In and Out"):
                        rcfBgpCatOut = rcfBgpCatOut + rcfOut
                        rcfConfigMplsOut = processMplsRcfOut(bgpNeighborAsn)
    return vlanInterfaceConfigCat1, vlanInterfaceConfigCat2, ipVpnInterfacesListCat, vrfNeighborCat, addressFamilyNeighborCat, rcfBgpCat, rcfConfig, routeMapIn, routeMapOut, rcfBgpCatOut, rcfConfigMplsOut, autoRT


# =============================================================================
# Service-Type Template Builders
# =============================================================================

def _circuitType(cx):
    """Build the circuitType metadata dict used in every service configlet."""
    return {
        "circuitState": cx["circuitState"],
        "multiHoming": cx["multiHoming"],
        "customerName": cx["customerName"],
        "connectionType": cx["connectionType"],
        "currentDatetime": cx["current_datetime"],
        "serviceType": cx["serviceType"],
    }


def _serviceEntry(cx, cli):
    """Build a single service entry dict with generated CLI."""
    return {
        "cliGroup": {
            "circuitType": _circuitType(cx),
            "cli": re.sub(r'\n\s*\n', '\n', cli),
        },
        "serviceType": cx["serviceType"],
        "customerName": cx["customerName"],
        "currentDatetime": cx["current_datetime"],
        "circuitId": cx["circuitId"],
    }


def buildDiaCli(cx):
    """Generate CLI configlets for Direct Internet Access circuits."""
    s = cx["svcSettings"]
    mplsResult = processMplsInterfaces(
        cx["deviceNameList"], s["vlanInterfaces"], s["ipVpnInterfaces"],
        cx["paddedEsi"], cx["multiHoming"], cx["customerName"],
        cx["bgpSessionTrackingCLI"], cx["circuitId"], cx["serviceType"],
        cx["serviceLevelConfig"], cx["vrfName"], s["dualAttachedPortChannel"],
        s["routingType"], s["l3Encap"], s["otherPortChannelMember"],
        s["prefixList"], s["prefixListOut"], s["connectionType"],
        s["bgpPolicy"], cx["defaultOriginate"], s["flexEncap"],
        s["clientDot1QVlan"], s["clientDot1QInnerVlan"], cx["pendingTags"])
    vlanCfg1, vlanCfg2, ipVpnCfg, vrfNbr, afNbr, rcfBgp, rcfCfg, _, _, _, _, _ = mplsResult

    pfLineCat = ""
    srLineCat = ""
    remoteAsn = ""
    if s["ipVpnInterfaces"]:
        for asn in s["ipVpnInterfaces"]:
            remoteAsn = asn.get("remoteAsn")
    if s.get("staticRoutes"):
        srLineCat = processStaticRoutes(s["staticRoutes"], cx["vrfName"])
    pfLineCat = processPrefixLists(s["prefixList"], remoteAsn, "OUT", cx["circuitId"])
    bgpAs = cx["bgpAs"]

    if s["routingType"] == "BGP":
        cx["cliList1"].append(_serviceEntry(cx, f"""
{ipVpnCfg}
{vlanCfg1}
{pfLineCat}
router bgp {bgpAs}
!
    {vrfNbr}
    !
    address-family ipv4
        {afNbr}
        {rcfBgp}
        exit
    exit
!
{rcfCfg}
                """))
    elif s["routingType"] == "Directly Connected":
        cx["cliList1"].append(_serviceEntry(cx, f"""
{ipVpnCfg}
{vlanCfg1}
{srLineCat}
!
                """))
        cx["cliList2"].append(_serviceEntry(cx, f"""
{ipVpnCfg}
{vlanCfg2}
{srLineCat}
router bgp {bgpAs}
!
                """))


def buildVpnV4Cli(cx):
    """Generate CLI configlets for VPN-V4 / L3-EVPN circuits."""
    s = cx["svcSettings"]
    mplsResult = processMplsInterfaces(
        cx["deviceNameList"], s["vlanInterfaces"], s["ipVpnInterfaces"],
        cx["paddedEsi"], cx["multiHoming"], cx["customerName"],
        cx["bgpSessionTrackingCLI"], cx["circuitId"], cx["serviceType"],
        cx["serviceLevelConfig"], cx["vrfName"], s["dualAttachedPortChannel"],
        s["routingType"], s["l3Encap"], s["otherPortChannelMember"],
        s["prefixList"], s["prefixListOut"], s["connectionType"],
        s["bgpPolicy"], cx["defaultOriginate"], s["flexEncap"],
        s["clientDot1QVlan"], s["clientDot1QInnerVlan"], cx["pendingTags"])
    vlanCfg1, vlanCfg2, ipVpnCfg, vrfNbr, afNbr, rcfBgp, rcfCfg, routeMapIn, routeMapOut, rcfBgpOut, rcfMplsOut, autoRT = mplsResult

    pfLineCat = ""
    pfLineOutCat = ""
    srLineCat = ""
    remoteAsn = ""
    rtImport = ""
    rtExport = ""
    bgpAs = cx["bgpAs"]
    vrfName = cx["vrfName"]
    evi = cx["evi"]
    lo0Address1 = cx["lo0Address1"]
    serviceType = cx["serviceType"]

    leftSideOfRd = f"rd {lo0Address1}"
    if serviceType == "VPN-V4":
        leftSideOfRd = f"rd {bgpAs}"
    if serviceType == "VPN-V4":
        rtImport = "vpn-ipv4"
        rtExport = "vpn-ipv4"
    elif serviceType == "L3-EVPN":
        rtImport = "evpn"
        rtExport = "evpn"
    if s["ipVpnInterfaces"]:
        for asn in s["ipVpnInterfaces"]:
            remoteAsn = asn.get("remoteAsn")
    if s["staticRoutes"]:
        srLineCat = processStaticRoutes(s["staticRoutes"], vrfName)
    if s["prefixList"]:
        pfLineCat = processPrefixLists(s["prefixList"], remoteAsn, "IN", cx["circuitId"])
        routeMapIn = processRouteMaps(remoteAsn, "IN")
    if s["prefixListOut"]:
        pfLineOutCat = processPrefixLists(s["prefixListOut"], remoteAsn, "OUT", cx["circuitId"])
        routeMapOut = processRouteMaps(remoteAsn, "OUT")

    if s["routingType"] == "BGP":
        cx["cliList1"].append(_serviceEntry(cx, f"""
vrf instance {vrfName}
!
ip routing vrf {vrfName}
!
{ipVpnCfg}
{vlanCfg2}
{srLineCat}
{pfLineCat}
{pfLineOutCat}
router bgp {bgpAs}
    {routeMapIn}
    {routeMapOut}
    !
    vrf {vrfName}
         {leftSideOfRd}:{evi}
         route-target import {rtImport} {bgpAs}:{evi}
         route-target export {rtExport} {bgpAs}:{evi}
        {vrfNbr}
    address-family ipv4
        {afNbr}
        {rcfBgp}
        {rcfBgpOut}
         redistribute connected
         redistribute static
         exit
    {autoRT}
    exit
exit
!
{rcfCfg}
{rcfMplsOut}
                """))
        cx["cliList2"].append(_serviceEntry(cx, f"""

vrf instance {vrfName}
!
ip routing vrf {vrfName}
!
{ipVpnCfg}
{vlanCfg2}
{srLineCat}
{pfLineCat}
{pfLineOutCat}
router bgp {bgpAs}
    {routeMapIn}
    {routeMapOut}
   !
   vrf {vrfName}
       {leftSideOfRd}:{evi}
       route-target import {rtImport} {bgpAs}:{evi}
       route-target export {rtExport} {bgpAs}:{evi}
     {vrfNbr}
   address-family ipv4
     {afNbr}
     {rcfBgp}
     {rcfBgpOut}
       redistribute connected
       redistribute static
       exit
   {autoRT}
   exit
exit
!
{rcfCfg}
{rcfMplsOut}
        """))
    elif s["routingType"] == "Directly Connected":
        cx["cliList1"].append(_serviceEntry(cx, f"""
vrf instance {vrfName}
!
ip routing vrf {vrfName}
!
{ipVpnCfg}
{vlanCfg1}
{srLineCat}
router bgp {bgpAs}
    {routeMapIn}
    {routeMapOut}
    !
    vrf {vrfName}
         {leftSideOfRd}:{evi}
         route-target import {rtImport} {bgpAs}:{evi}
         route-target export {rtExport} {bgpAs}:{evi}
        {vrfNbr}
    address-family ipv4
        {afNbr}
         redistribute connected
         redistribute static
         exit
    {autoRT}
    exit
exit
                """))
        cx["cliList2"].append(_serviceEntry(cx, f"""

vrf instance {vrfName}
!
ip routing vrf {vrfName}
!
{ipVpnCfg}
{vlanCfg2}
{srLineCat}
router bgp {bgpAs}
    {routeMapIn}
    {routeMapOut}
   !
   vrf {vrfName}
       {leftSideOfRd}:{evi}
       route-target import {rtImport} {bgpAs}:{evi}
       route-target export {rtExport} {bgpAs}:{evi}
     {vrfNbr}
   address-family ipv4
     {afNbr}
       redistribute connected
       redistribute static
       exit
   {autoRT}
   exit
exit
        """))


def buildL2EvpnCli(cx):
    """Generate CLI configlets for L2-EVPN / L2-EVPN + IRB circuits."""
    s = cx["svcSettings"]
    interfacesListCat1, interfacesListCat2, autoRT = processL2EvpnInterfaces(
        cx["deviceNameList"], s["l2EvpnInterfaces"], cx["paddedEsi"],
        cx["multiHoming"], cx["customerName"], cx["bgpSessionTrackingCLI"],
        cx["circuitId"], cx["serviceType"], s["vlan"], s["flexEncap"],
        cx["serviceLevelConfig"], s["dualAttachedPortChannel"],
        s["otherPortChannelMember"], s["connectionType"], cx["pendingTags"])

    bgpAs = cx["bgpAs"]
    evi = cx["evi"]
    customerName = cx["customerName"]
    circuitId = cx["circuitId"]
    serviceType = cx["serviceType"]
    vlan = s["vlan"]
    lo0Address1 = cx["lo0Address1"]
    lo0Address2 = cx["lo0Address2"]

    if serviceType == "L2-EVPN + IRB":
        sviCfg = f"""
ip virtual-router mac-address 00:1c:73:00:00:01
!
vrf instance {s['ipAddressVirtualVrf']}
!
interface Vlan{vlan}
    description {customerName}/{circuitId}/{serviceType}
    mtu 9016
    vrf {s['ipAddressVirtualVrf']}
    ip address virtual {s['ipAddressVirtual']}
    exit
                """
    else:
        sviCfg = ""

    cx["cliList1"].append(_serviceEntry(cx, f"""
vlan {vlan}
   name {customerName}/{circuitId}/{serviceType}
!
{interfacesListCat1}
!
router bgp {bgpAs}
   !
   vlan {vlan}
      rd {lo0Address1}:{evi}
      route-target both {bgpAs}:{evi}
      redistribute learned
      !
      {autoRT}
      exit
   exit
!
{sviCfg}
        """))
    cx["cliList2"].append(_serviceEntry(cx, f"""
vlan {vlan}
   name {customerName}/{circuitId}/{serviceType}
!
{interfacesListCat2}
router bgp {bgpAs}
   !
   vlan {vlan}
      rd {lo0Address2}:{evi}
      route-target both {bgpAs}:{evi}
      redistribute learned
      !
      {autoRT}
      exit
   exit
!
{sviCfg}
        """))


def buildVplsCli(cx):
    """Generate CLI configlets for VPLS circuits."""
    s = cx["svcSettings"]
    interface = s["interface"]
    subInterface = s["subInterface"]
    if "Ethernet" not in interface:
        raise ActionFailed("Check the spelling of Ethernet")
    if not subInterface:
        raise ActionFailed("Please enter a sub interface number")
    interfaceTags(cx["deviceNameList"], interface, subInterface, cx["customerName"],
                  cx["circuitId"], cx["serviceType"], s["connectionType"], "", cx["pendingTags"])
    vlanId = f"vlan id {s['vlan']}" if s["vlan"] else ""
    customerName = cx["customerName"]
    circuitId = cx["circuitId"]
    serviceType = cx["serviceType"]
    vlan = s["vlan"]
    flexEncap = s["flexEncap"]
    serviceLevelConfig = cx["serviceLevelConfig"]

    cx["cliList1"].append(_serviceEntry(cx, f"""
vlan {vlan}
   name {customerName}/{circuitId}/{serviceType}
!
interface {interface}
   description {customerName}
   no switchport
   no lldp transmit
!
interface {interface}.{subInterface}
   description {customerName}/{circuitId}/{serviceType}
   {vlanId}
      {flexEncap}
   !
   {serviceLevelConfig}
!
mpls ldp
   !
   pseudowires
      profile {circuitId}
         mtu 9000
         control-word
         label flow
         exit
      exit
   exit
!
router vpls
   vpls {circuitId}
      ldp mac withdrawal trigger interface
      !
      vlan bundle {vlan}
      !
      pseudowire ldp {circuitId} split-horizon
         bgp auto-discovery profile {circuitId} id 1
         exit
      exit
   exit
        """))


def buildVpwsCli(cx):
    """Generate CLI configlets for VPWS (point-to-point) circuits."""
    s = cx["svcSettings"]
    interface = s["interface"]
    subInterface = s["subInterface"]
    multiHoming = cx["multiHoming"]
    paddedEsi = cx["paddedEsi"]
    bgpAs = cx["bgpAs"]
    evi = cx["evi"]
    customerName = cx["customerName"]
    circuitId = cx["circuitId"]
    serviceType = cx["serviceType"]
    autoRT = cx["autoRT"]
    bgpSessionTrackingCLI = cx["bgpSessionTrackingCLI"]
    serviceLevelConfig = cx["serviceLevelConfig"]
    lo0Address1 = cx["lo0Address1"]
    lo0Address2 = cx["lo0Address2"]
    flexEncap = s["flexEncap"]

    if not ("Port-Channel" in interface or "Ethernet" in interface):
        raise ActionFailed("Check the spelling of Ethernet or Port-Channel")
    if not subInterface:
        raise ActionFailed("Please enter a sub interface number")
    if s["connectionType"] == "NNI":
        description = ""
    else:
        description = f"description {customerName}"
    interfaceTags(cx["deviceNameList"], interface, subInterface, customerName,
                  circuitId, serviceType, s["connectionType"], "", cx["pendingTags"])
    esi = calculateEsi(paddedEsi, interface, subInterface)
    lldp = ""
    if "Port-Channel" in interface:
        ethernetPort = processPortChannels(interface, s["dualAttachedPortChannel"],
                                           s["otherPortChannelMember"], customerName, s["connectionType"])
        if multiHoming in ("Active Active Multi Homing", "Single Active Multi Homing"):
            lacpSysId = "lacp system-id aaaa.bbbb.cccc"
        else:
            lacpSysId = ""
    else:
        lldp = "no lldp transmit"
        lacpSysId = ""
        ethernetPort = ""
    if multiHoming != "Single Homed":
        autoRT = """
   address-family evpn
      route type ethernet-segment route-target auto
      exit
                """
    multiHomingConfig1 = ""
    multiHomingConfig2 = ""
    if multiHoming == "Active Active Multi Homing":
        if "Port-Channel" not in interface:
            raise ActionFailed("Active Active Multi Homing requires Port-Channel")
        multiHomingConfig1 = f"""
   evpn ethernet-segment
      identifier {esi}
   !"""
        multiHomingConfig2 = f"""
   evpn ethernet-segment
      identifier {esi}
   !"""
    elif multiHoming == "Single Active Multi Homing":
        if "Ethernet" not in interface:
            raise ActionFailed("Single Active Multi Homing requires Ethernet Interface")
        multiHomingConfig1 = f"""
   evpn ethernet-segment
      identifier {esi}
      redundancy single-active
      designated-forwarder election algorithm preference 2000 dont-preempt
   !"""
        multiHomingConfig2 = f"""
   evpn ethernet-segment
      identifier {esi}
      redundancy single-active
      designated-forwarder election algorithm preference 1000 dont-preempt
   !"""

    cx["cliList1"].append(_serviceEntry(cx, f"""
{ethernetPort}
!
interface {interface}
   {description}
   {bgpSessionTrackingCLI}
   no switchport
   {lacpSysId}
   {lldp}
!
interface {interface}.{subInterface}
   description {customerName}/{circuitId}/{serviceType}
      {flexEncap}
   !
   {serviceLevelConfig}
   {multiHomingConfig1}
!
patch panel
   patch {circuitId}
      connector 1 interface {interface}.{subInterface}
      connector 2 pseudowire bgp vpws {circuitId} pseudowire {evi}
!
router bgp {bgpAs}
   !
   vpws {circuitId}
      rd {lo0Address1}:{evi}
      route-target import export evpn {bgpAs}:{evi}
      mpls control-word
      !
      pseudowire {evi}
         evpn vpws id local 1 remote 1
         exit
      exit
      {autoRT}
   exit
        """))
    cx["cliList2"].append(_serviceEntry(cx, f"""
{ethernetPort}
!
interface {interface}
   {description}
   {bgpSessionTrackingCLI}
   no switchport
   {lacpSysId}
   {lldp}
!
interface {interface}.{subInterface}
   description {customerName}/{circuitId}/{serviceType}
      {flexEncap}
   !
   {serviceLevelConfig}
   {multiHomingConfig2}
!
patch panel
   patch {circuitId}
      connector 1 interface {interface}.{subInterface}
      connector 2 pseudowire bgp vpws {circuitId} pseudowire {evi}
!
router bgp {bgpAs}
   !
   vpws {circuitId}
      rd {lo0Address2}:{evi}
      route-target import export evpn {bgpAs}:{evi}
      mpls control-word
      !
      pseudowire {evi}
         evpn vpws id local 1 remote 1
         exit
      exit
      {autoRT}
   exit
        """))


# =============================================================================
# Input Extraction
# =============================================================================

def getCustomerStdInputs(inputPath, customerStdInputs):
    """Extract circuit and PE info from the Customer Studio for the selected path."""
    customerIdx = int(inputPath[1])
    circuitIdx = int(inputPath[3])
    peIdx = int(inputPath[5])
    customer = customerStdInputs['customers'][customerIdx].get('customerName')
    circuit = customerStdInputs['customers'][customerIdx]['circuits'][circuitIdx]
    circuitInfo = circuit['pEs'][peIdx]
    circuitInfo['customer'] = customer
    circuitInfo['serviceType'] = circuit.get("serviceType")
    circuitInfo['serviceLevel'] = circuit.get("serviceLevel")
    circuitInfo['circuitId'] = circuit.get("circuitId")
    circuitInfo['evi'] = circuit.get("evi")
    circuitInfo['vrfName'] = circuit.get("vrfName")
    globalSettings = customerStdInputs.get("globalSettings", {})
    return circuitInfo, globalSettings


def extractServiceSettings(serviceType, circuitInfo):
    """Extract service-type-specific settings from the circuit info.

    Returns a dict with all the settings needed by the template builder
    for the given service type.
    """
    settings = circuitInfo.get("settings", {})
    group = settings.get("group", {})
    result = {
        "lockCircuit": False,
        "circuitState": None,
        "routingType": "Directly Connected",
        "connectionType": group.get("connectionType", "UNI"),
        "interfaceType": group.get("interfaceType"),
    }

    if serviceType == "Direct Internet Access":
        dia = settings.get("diaSettings", {})
        result.update({
            "circuitState": dia.get("circuitState"),
            "lockCircuit": dia.get("lockCircuit"),
            "routingType": group.get("routingType"),
            "dualAttachedPortChannel": dia.get("dualAttachedPortChannel"),
            "otherPortChannelMember": dia.get("otherPortChannelMember"),
            "ipVpnInterfaces": settings.get("ipVpnInterfaces"),
            "prefixList": settings.get("prefixList"),
            "staticRoutes": settings.get("staticRoutes"),
            "vlanInterfaces": settings.get("vlanInterfaces"),
            "l3Encap": group.get("l3Encap"),
            "flexEncap": group.get("flexEncap"),
            "clientDot1QVlan": group.get("clientDot1QVlan"),
            "clientDot1QInnerVlan": group.get("clientDot1QInnerVlan"),
            "prefixListOut": "",
            "bgpPolicy": group.get("bgpPolicy"),
        })
    elif serviceType == "VPN-V4":
        ipvpn = settings.get("ipVpnSettings", {})
        result.update({
            "circuitState": ipvpn.get("circuitState"),
            "lockCircuit": ipvpn.get("lockCircuit"),
            "dualAttachedPortChannel": ipvpn.get("dualAttachedPortChannel"),
            "otherPortChannelMember": ipvpn.get("otherPortChannelMember"),
            "defaultOriginate": ipvpn.get("defaultOriginate"),
            "routingType": group.get("routingType"),
            "bgpPolicy": group.get("bgpPolicy"),
            "ipVpnInterfaces": settings.get("ipVpnInterfaces"),
            "prefixList": settings.get("prefixList"),
            "prefixListOut": settings.get("prefixListOut"),
            "staticRoutes": settings.get("staticRoutes"),
            "vlanInterfaces": settings.get("vlanInterfaces"),
            "l3Encap": group.get("l3Encap"),
            "flexEncap": group.get("flexEncap"),
            "clientDot1QVlan": group.get("clientDot1QVlan"),
            "clientDot1QInnerVlan": group.get("clientDot1QInnerVlan"),
        })
    elif serviceType == "L3-EVPN":
        l3evpn = settings.get("l3EvpnSettings", {})
        result.update({
            "circuitState": l3evpn.get("circuitState"),
            "lockCircuit": l3evpn.get("lockCircuit"),
            "dualAttachedPortChannel": l3evpn.get("dualAttachedPortChannel"),
            "otherPortChannelMember": l3evpn.get("otherPortChannelMember"),
            "routingType": group.get("routingType"),
            "ipVpnInterfaces": settings.get("ipVpnInterfaces"),
            "prefixList": settings.get("prefixList"),
            "prefixListOut": settings.get("prefixListOut"),
            "staticRoutes": settings.get("staticRoutes"),
            "vlanInterfaces": settings.get("vlanInterfaces"),
            "l3Encap": group.get("l3Encap"),
            "flexEncap": group.get("flexEncap"),
            "clientDot1QVlan": group.get("clientDot1QVlan"),
            "clientDot1QInnerVlan": group.get("clientDot1QInnerVlan"),
            "bgpPolicy": "",
        })
    elif serviceType in ("L2-EVPN", "L2-EVPN + IRB"):
        l2 = settings.get("l2EvpnWIrb", {})
        flexEncapInput = group.get("l2FlexEncap")
        cVlan = group.get("l2ClientDot1QVlan")
        cInnerVlan = group.get("l2ClientDot1QInnerVlan")
        result.update({
            "circuitState": l2.get("circuitState"),
            "lockCircuit": l2.get("lockCircuit"),
            "dualAttachedPortChannel": l2.get("dualAttachedPortChannel"),
            "otherPortChannelMember": l2.get("otherPortChannelMember"),
            "l2EvpnInterfaces": settings.get("l2EvpnInterfaces"),
            "vlan": l2.get("vlanId"),
            "ipAddressVirtual": l2.get("ipAddress"),
            "ipAddressVirtualVrf": l2.get("l3Vrf"),
            "flexEncap": processFlexEncap(flexEncapInput, cVlan, cInnerVlan),
        })
    elif serviceType == "VPLS":
        vpls = settings.get("vpls", {})
        flexEncapInput = group.get("l2FlexEncap")
        cVlan = group.get("l2ClientDot1QVlan")
        cInnerVlan = group.get("l2ClientDot1QInnerVlan")
        result.update({
            "circuitState": vpls.get("circuitState"),
            "lockCircuit": vpls.get("lockCircuit"),
            "vlan": vpls.get("vlan"),
            "interface": vpls.get("interface", ""),
            "subInterface": vpls.get("subInterface", ""),
            "flexEncap": processFlexEncap(flexEncapInput, cVlan, cInnerVlan),
        })
    elif serviceType == "VPWS":
        vpws = settings.get("vpws", {})
        eline = settings.get("elineInterface", {})
        flexEncapInput = group.get("l2FlexEncap")
        cVlan = group.get("l2ClientDot1QVlan")
        cInnerVlan = group.get("l2ClientDot1QInnerVlan")
        result.update({
            "circuitState": vpws.get("circuitState"),
            "lockCircuit": vpws.get("lockCircuit"),
            "dualAttachedPortChannel": vpws.get("dualAttachedPortChannel"),
            "otherPortChannelMember": vpws.get("otherPortChannelMember"),
            "interface": eline.get("interface", ""),
            "subInterface": eline.get("subInterface"),
            "flexEncap": processFlexEncap(flexEncapInput, cVlan, cInnerVlan),
        })
    return result


# =============================================================================
# Orchestrator
# =============================================================================

def processInputs():
    """Orchestrate the full provisioning workflow for a single circuit.

    Steps:
      1. Fetch circuit data from Customer Studio and current state from Configlet Studio
      2. Resolve PE router IDs (Loopback0) for route distinguisher and ESI generation
      3. Validate multi-homing configuration against PE count
      4. Clean up stale interface tags from any previous provisioning run
      5. Extract service-type-specific settings and validate constraints
      6. Generate EOS CLI configlet via the appropriate service-type builder
      7. Merge the new configlet with existing circuits on the target devices
      8. Batch-assign interface tags and push the final result to the Configlet Studio
    """
    current_datetime = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
    pendingTags = []

    # --- Step 1: Fetch inputs from both studios ---
    customerStdID, wrkID, inputPath = extractStudioInfoFromArgs(ctx.action.args)
    try:
        customerStdInputs = getStudioInputs(ctx.getApiClient, customerStdID, wrkID, [])
    except InputNotFoundException:
        customerStdInputs = {}
    circuitInfo, globalSettings = getCustomerStdInputs(inputPath, customerStdInputs)
    try:
        inputs = getStudioInputs(ctx.getApiClient, cliStdID, wrkID, [])
    except InputNotFoundException:
        inputs = {}

    # Unpack the circuit-level fields shared by all service types
    customerName = circuitInfo.get("customer")
    circuitId = circuitInfo.get("circuitId")
    serviceType = circuitInfo.get("serviceType")
    evi = circuitInfo.get("evi")
    vrfName = circuitInfo.get("vrfName")
    multiHoming = circuitInfo.get("multiHoming")
    if len(circuitInfo.get("pe")) == 0:
        raise ActionFailed("Please add an Endpoint")
    tag = circuitInfo.get("pe").get("tags").get("query")

    # --- Step 2: Resolve PE loopback IPs ---
    # These are used as the left side of route distinguishers (RD) and to
    # generate deterministic ESI values for multi-homed circuits.
    deviceNameList = splitTagToDeviceNames(tag)
    devs = ctx.getDevicesByTag(Tag('router_bgp.router_id', None), inTopology=False)
    dids = {dev.id: dev for dev in devs}
    lo0Address1 = ""
    lo0Address2 = ""
    deviceId = deviceNameList[0]
    if deviceId in dids:
        lo0Address1 = dids[deviceId].getSingleTag(ctx, 'router_bgp.router_id').value
    if len(deviceNameList) == 2:
        deviceId = deviceNameList[1]
        if deviceId in dids:
            lo0Address2 = dids[deviceId].getSingleTag(ctx, 'router_bgp.router_id').value

    # --- Step 3: Validate multi-homing vs PE count ---
    if len(deviceNameList) > 1 and multiHoming == "Single Homed":
        raise ActionFailed("Choose only 1 router if the Circuit is Single Homed")
    if len(deviceNameList) < 2 and multiHoming != "Single Homed":
        raise ActionFailed("Choose 2 routers if the Circuit is Multi Homed")

    # --- Step 4: Clean up stale interface tags ---
    # When re-provisioning, delete old tags before creating new ones.
    # Fetch all tags once and pass to each device cleanup call.
    if globalSettings.get("globallyEnableInterfaceTagging") == "Enable":
        allIntfTags = ctx.tags._getAllInterfaceTags()
        for deviceId in deviceNameList:
            clean_up_interface_tags(deviceId, circuitId, allIntfTags)
    else:
        deviceNameList = []

    # Build ESI prefix from both PE loopbacks (multi-homed only)
    paddedEsi = ""
    if multiHoming in ("Active Active Multi Homing", "Single Active Multi Homing"):
        paddedEsi = buildEsiPrefix(lo0Address1, lo0Address2)

    # --- Step 5: Extract and validate service-type settings ---
    svcSettings = extractServiceSettings(serviceType, circuitInfo)
    if svcSettings["lockCircuit"]:
        raise ActionFailed("This circuit is locked from being reprovisioned")
    if svcSettings.get("routingType") == "BGP" and svcSettings.get("interfaceType") == "SVI":
        raise ActionFailed("SVI is not a valid interface type for BGP routing")

    # Normalize circuit state for the configlet display metadata
    circuitState = svcSettings["circuitState"]
    if circuitState is None or circuitState is True:
        circuitState = "Enabled"
    else:
        circuitState = "Disabled"

    # Global settings: local ASN and BGP session tracking
    bgpAs = globalSettings.get("localASN")
    bgpSessionTracking = globalSettings.get("bgpSessionTracking")
    if bgpSessionTracking == "Enabled" or bgpSessionTracking is None:
        bgpSessionTrackingCLI = "bgp session tracker TRACK-EVPN-PEERS"
    else:
        bgpSessionTrackingCLI = ""

    # QoS: build service-profile, shape rate, and policer CLI if configured
    serviceLevel = circuitInfo.get("serviceLevel").get("serviceLevel")
    shapeRate = circuitInfo.get("serviceLevel").get("shapeRate")
    policerProfile = circuitInfo.get("serviceLevel").get("policerProfile")
    qosProfile = f"service-profile USS-QOS-{serviceLevel}" if serviceLevel else ""
    if shapeRate and policerProfile:
        serviceLevelConfig = f"""{qosProfile}
    shape rate {shapeRate}
    policer profile {policerProfile} input
    !"""
    else:
        serviceLevelConfig = ""

    # --- Step 6-7: Collect existing circuits and generate new CLI ---
    # Single pass: separate non-target devices (keep as-is) from target
    # devices (collect their existing circuits, excluding the one being
    # re-provisioned, so we can merge the new CLI alongside them).
    tagList = splitTagToDeviceNames(tag)
    studioStructure = []
    existingCliList1 = []
    existingCliList2 = []
    device1Found = False
    for existingDevice in inputs.get("devices", {}):
        xTag = existingDevice.get("tags", {}).get("query", "")
        xTag = xTag.strip().removeprefix('device:')
        if xTag in tagList:
            services = existingDevice.get("inputs", {}).get("value", {}).get("services")
            if services is not None:
                for service in services:
                    if circuitId != service.get("circuitId"):
                        if not device1Found:
                            existingCliList1.append(service)
                        else:
                            existingCliList2.append(service)
            device1Found = True
        else:
            studioStructure.append(existingDevice)

    # Build context dict shared by all template builders
    cx = {
        "customerName": customerName, "circuitId": circuitId,
        "serviceType": serviceType, "evi": evi, "vrfName": vrfName,
        "multiHoming": multiHoming, "circuitState": circuitState,
        "connectionType": svcSettings["connectionType"],
        "current_datetime": current_datetime, "bgpAs": bgpAs,
        "bgpSessionTrackingCLI": bgpSessionTrackingCLI,
        "serviceLevelConfig": serviceLevelConfig,
        "paddedEsi": paddedEsi, "autoRT": "",
        "defaultOriginate": svcSettings.get("defaultOriginate", False),
        "lo0Address1": lo0Address1, "lo0Address2": lo0Address2,
        "deviceNameList": deviceNameList, "pendingTags": pendingTags,
        "cliList1": [], "cliList2": [],
        "svcSettings": svcSettings,
    }

    # Dispatch to the appropriate service-type CLI builder
    if serviceType == "Direct Internet Access":
        buildDiaCli(cx)
    elif serviceType in ("VPN-V4", "L3-EVPN"):
        buildVpnV4Cli(cx)
    elif serviceType in ("L2-EVPN", "L2-EVPN + IRB"):
        buildL2EvpnCli(cx)
    elif serviceType == "VPLS":
        buildVplsCli(cx)
    elif serviceType == "VPWS":
        buildVpwsCli(cx)

    # --- Step 8: Assemble, tag, and push ---
    # Merge existing circuits with the newly generated CLI for each target device
    cliList0 = []
    index = 0
    for tag in tagList:
        index = index + 1
        if index == 1:
            cliList0 = existingCliList1 + cx["cliList1"]
        elif index == 2:
            cliList0 = existingCliList2 + cx["cliList2"]
        studioStructure.append({
            "inputs": {"value": {"services": cliList0}},
            "tags": {"query": f"device:{tag}"},
        })
    inputs = {"devices": studioStructure}

    # Assign all accumulated interface tags in a single API call
    if pendingTags:
        ctx.tags._assignInterfaceTags(pendingTags)

    # Push the final device list to the Configlet Studio
    try:
        setStudioInput(ctx.getApiClient, cliStdID, wrkID, [], inputs)
    except InputUpdateException as e:
        raise ActionFailed(f"Failed to add location due to: {e}") from e


# =============================================================================
# Entry Point
# =============================================================================

def main():
    ctx.initializeStudioCtxFromArgs()
    ctx.tags._getAllDeviceTags()
    processInputs()

if __name__ == "__main__":
    main()
