# pylint: disable=import-error
"""Delete Circuits — CloudVision Studios autofill action.

Cleans up the MPLS Configlet Studio by removing circuits that no longer
exist in the Customer Studio, and reconciles interface tags so dashboards
stay accurate.

Workflow:
  1. Fetch customer/circuit data from the Customer Studio.
  2. Build a fast lookup of circuitId -> device names.
  3. Rebuild the Configlet Studio inputs, keeping only services whose
     circuitId still maps to a valid device.
  4. Delete stale interface tags and re-assert the tags for circuits
     that are still active.
"""

from cloudvision.cvlib import (
    ActionFailed,
    extractStudioInfoFromArgs,
    InputUpdateException,
    InputNotFoundException,
    getStudioInputs,
    setStudioInput,
)

# ID of the MPLS Configlet Studio that gets cleaned up
cliStdID = "9a0dd312-f056-49fa-a1b9-45b8905bb272"


def getCustomerStdInputs(customerStdInputs):
    """Return the customers list from the Customer Studio inputs."""
    customers = customerStdInputs.get('customers', {})
    return customers


def buildCircuitDeviceLookup(customers):
    """Build a dict mapping circuitId -> set of device names from PE tags.

    Used for O(1) lookups when filtering services and tags, instead of
    re-iterating the full customer/circuit/PE tree on every check.
    """
    lookup = {}
    for customer in customers:
        for circuit in customer.get("circuits") or []:
            circuitId = circuit.get("circuitId")
            if circuitId is None:
                continue
            devices = set()
            for pe in circuit.get("pEs") or []:
                tag = str(pe.get("pe", {}).get("tags", {}).get("query", ""))
                tagStripped = tag.removeprefix("device:")
                for name in tagStripped.replace(',', '|').split('|'):
                    name = name.strip()
                    if name:
                        devices.add(name)
            lookup[circuitId] = devices
    return lookup


def processInputs(circuitLookup, wrkID):
    """Rebuild the Configlet Studio, keeping only services that match active circuits.

    For each device in the Configlet Studio, filter its service list to
    only include services whose circuitId exists in circuitLookup and
    whose device is in the circuit's PE set.
    """
    try:
        inputs = getStudioInputs(ctx.getApiClient, cliStdID, wrkID, [])
    except InputNotFoundException:
        inputs = {}
    studioStructure = []
    for existingDevice in inputs.get("devices", {}):
        cliList = []
        deviceQuery = existingDevice.get("tags", {}).get("query", "")
        services = existingDevice.get("inputs",{}).get("value",{}).get("services")
        if services is not None:
            for existingService in services:
                serviceCircuitId = existingService.get("circuitId")
                if serviceCircuitId in circuitLookup:
                    deviceName = deviceQuery.removeprefix("device:")
                    if deviceName in circuitLookup[serviceCircuitId]:
                        cliList.append(existingService)
        studioStructure.append(
            {
                "inputs": {
                    "value": {
                        "services": cliList
                    }
                },
                "tags": {
                    "query": deviceQuery
                }
            }
        )

    inputs = {}
    inputs["devices"] = studioStructure
    try:
        setStudioInput(ctx.getApiClient, cliStdID, wrkID, [], inputs)
    except InputUpdateException as e:
        raise ActionFailed(f"Failed to add location due to: {e}") from e


def cleanUpTags(circuitLookup, allIntfTags):
    """Reconcile interface tags against active circuits.

    For each interface that has a Service-ID or Customer-Name tag:
      - If the tag's value matches an active circuit on this device,
        re-assert all tags on that interface (keep list).
      - Always queue the Service-ID/Customer-Name tag for deletion first,
        then re-assert the ones that are still valid. This ensures stale
        tags from deleted circuits are removed.
    """
    listOfTags = []
    listOfTagsToDelete = []
    for device, device_details in allIntfTags.items():
        for interface, interface_details in device_details.items():
            for label, label_details in interface_details.items():
                if label in ('Service-ID', 'Customer-Name'):
                    circuitId = label_details[0]
                    if circuitId in circuitLookup and device in circuitLookup[circuitId]:
                        for keep_label, keep_label_details in interface_details.items():
                            keepThisTag = (device, interface, keep_label,
                                          keep_label_details[0], False)
                            listOfTags.append(keepThisTag)
                    deleteThisTag = (device, interface, label, None)
                    listOfTagsToDelete.append(deleteThisTag)
    if listOfTagsToDelete:
        ctx.tags._unassignInterfaceTags(listOfTagsToDelete)
    if listOfTags:
        ctx.tags._assignInterfaceTags(listOfTags)


def main():
    ctx.initializeStudioCtxFromArgs()
    ctx.tags._getAllDeviceTags()

    # Fetch shared data once — used by both processInputs and cleanUpTags
    customerStdID, wrkID, _ = extractStudioInfoFromArgs(ctx.action.args)
    try:
        customerStdInputs = getStudioInputs(ctx.getApiClient, customerStdID, wrkID, [])
    except InputNotFoundException:
        customerStdInputs = {}
    customers = getCustomerStdInputs(customerStdInputs)
    circuitLookup = buildCircuitDeviceLookup(customers)
    allIntfTags = ctx.tags._getAllInterfaceTags()

    processInputs(circuitLookup, wrkID)
    cleanUpTags(circuitLookup, allIntfTags)

if __name__ == "__main__":
    main()
