<%
if not devices:
    return
device = devices.resolve()
services = device.get("value", {}).get("services")
%>
%for service in services:
<%    cli = service.get("cliGroup", {}).get("cli")%>
!
${cli}
%endfor