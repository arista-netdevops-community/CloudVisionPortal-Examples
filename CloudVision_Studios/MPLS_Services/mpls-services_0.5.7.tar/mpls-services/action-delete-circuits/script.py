# pylint: disable=import-error
"""Delete Circuits — CloudVision Studios autofill action.

Cleans up the MPLS Configlet Studio by removing circuits that no longer
exist in the Customer Studio, and reconciles interface tags so dashboards
stay accurate.

Workflow:
  1. Fetch customer/circuit data from the Customer Studio.
  2. Build a fast lookup of circuitId -> device names.
  3. Rebuild the Configlet Studio inputs, keeping only services whose
     circuitId still maps to a valid device.
  4. Delete stale interface tags and re-assert the tags for circuits
     that are still active.
"""

from cloudvision.cvlib import (
    ActionFailed,
    extractStudioInfoFromArgs,
    InputUpdateException,
    InputNotFoundException,
    getStudioInputs,
    setStudioInput,
)

# ID of the MPLS Configlet Studio that gets cleaned up
cliStdID = "studio-mpls-service-configlets"


def buildCircuitDeviceLookup(customers):
    """Build a dict mapping circuitId -> set of device names from PE tags.

    Used for O(1) lookups when filtering services and tags, instead of
    re-iterating the full customer/circuit/PE tree on every check.
    """
    lookup = {}
    for customer in customers:
        for circuit in customer.get("circuits") or []:
            circuitId = circuit.get("circuitId")
            if circuitId is None:
                continue
            devices = set()
            for pe in circuit.get("pEs") or []:
                tag = str(pe.get("pe", {}).get("tags", {}).get("query", ""))
                tagStripped = tag.removeprefix("device:")
                for name in tagStripped.replace(',', '|').split('|'):
                    name = name.strip()
                    if name:
                        devices.add(name)
            lookup[circuitId] = devices
    return lookup


def processInputs(circuitLookup, wrkID):
    """Rebuild the Configlet Studio, keeping only services that match active circuits.

    For each device in the Configlet Studio, filter its service list to
    only include services whose circuitId exists in circuitLookup and
    whose device is in the circuit's PE set.
    """
    try:
        inputs = getStudioInputs(ctx.getApiClient, cliStdID, wrkID, [])
    except InputNotFoundException:
        inputs = {}
    deviceList = []
    for existingDevice in inputs.get("devices", {}):
        deviceQuery = existingDevice.get("tags", {}).get("query", "")
        deviceName = deviceQuery.removeprefix("device:")
        services = existingDevice.get("inputs", {}).get("value", {}).get("services")
        # Filter services: keep only those whose circuit still exists on this device
        filteredServices = []
        if services is not None:
            for service in services:
                serviceCircuitId = service.get("circuitId")
                if serviceCircuitId in circuitLookup and deviceName in circuitLookup[serviceCircuitId]:
                    filteredServices.append(service)
        deviceList.append({
            "inputs": {"value": {"services": filteredServices}},
            "tags": {"query": deviceQuery},
        })

    try:
        setStudioInput(ctx.getApiClient, cliStdID, wrkID, [], {"devices": deviceList})
    except InputUpdateException as e:
        raise ActionFailed(f"Failed to update configlet studio: {e}") from e


def cleanUpTags(circuitLookup, allIntfTags):
    """Reconcile interface tags against active circuits.

    Scans all interface tags looking for Circuit_ID tags. For each interface:
      - If the circuit is still active on this device, keep all tags (no action needed).
      - If the circuit was deleted or moved to a different device, remove all tags
        on that interface.
    This avoids the delete-then-reassert pattern which caused unnecessary API churn.
    """
    tagsToDelete = []
    for device, deviceInterfaces in allIntfTags.items():
        for interface, interfaceTags in deviceInterfaces.items():
            # Check if this interface has a Circuit_ID tag
            circuitId = None
            for label, labelValues in interfaceTags.items():
                if label == 'Circuit_ID':
                    circuitId = labelValues[0]
                    break
            if circuitId is None:
                continue
            # If the circuit is still valid on this device, leave tags alone
            if circuitId in circuitLookup and device in circuitLookup[circuitId]:
                continue
            # Circuit was deleted or device changed — remove all tags on this interface
            for label in interfaceTags:
                tagsToDelete.append((device, interface, label, None))
    if tagsToDelete:
        ctx.tags._unassignInterfaceTags(tagsToDelete)


def main():
    ctx.initializeStudioCtxFromArgs()
    ctx.tags._getAllDeviceTags()

    # Fetch shared data once
    customerStdID, wrkID, _ = extractStudioInfoFromArgs(ctx.action.args)
    try:
        customerStdInputs = getStudioInputs(ctx.getApiClient, customerStdID, wrkID, [])
    except InputNotFoundException:
        customerStdInputs = {}
    customers = customerStdInputs.get('customers', {})
    circuitLookup = buildCircuitDeviceLookup(customers)

    # Rebuild configlet studio
    processInputs(circuitLookup, wrkID)

    # Reconcile interface tags (only if there are tags to check)
    allIntfTags = ctx.tags._getAllInterfaceTags()
    if allIntfTags:
        cleanUpTags(circuitLookup, allIntfTags)

if __name__ == "__main__":
    main()
