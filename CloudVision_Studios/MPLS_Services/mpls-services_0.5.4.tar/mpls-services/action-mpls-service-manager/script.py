# pylint: disable=import-error
"""MPLS Service Manager — CloudVision Studios autofill action.

Provisions MPLS circuits by collecting inputs from the Customer Studio,
generating EOS CLI configlets per service type (Direct Internet Access,
VPN-V4, L3-EVPN, L2-EVPN, L2-EVPN + IRB, VPLS, VPWS) and pushing
them to the Configlet Studio.

Also manages interface tags for dashboard visibility and cleans up stale
tags when circuits are re-provisioned.
"""
import re
import ipaddress
from datetime import datetime

from cloudvision.cvlib import (
    ActionFailed,
    extractStudioInfoFromArgs,
    InputUpdateException,
    InputNotFoundException,
    getStudioInputs,
    setStudioInput,
)
from cloudvision.cvlib.tags import Tag

# ID of the Configlet Studio that receives the generated CLI
cliStdID = "studio-mpls-service-configlets"


# =============================================================================
# Tag Utilities
# =============================================================================

def splitTagToDeviceNames(tag):
    """Split a tag query string into a list of device names."""
    if "," in tag:
        tagSplit = tag.split(',')
    else:
        tagSplit = tag.split('|')
    deviceNames = []
    for name in tagSplit:
        name = name.strip()
        dev = name.removeprefix('device:')
        deviceNames.append(dev)
    return deviceNames


def interfaceTags(deviceNameList, interface, subinterface, customerName,
                  circuitId, serviceType, connectionType, _vrfName, pendingTags):
    """Accumulate interface tags into pendingTags for batch assignment.

    Tags Customer_Name, Circuit_ID, Service_Type, Link-Type, Last-Modified,
    and Connection_Type onto each interface — used by dashboards to display
    circuit status per device.
    """
    time = datetime.now()
    current_datetime = time.strftime("%Y-%m-%dT%H:%M:%S")
    if subinterface:
        interfaceCat = interface + "." + subinterface
    else:
        interfaceCat = interface
    for deviceId in deviceNameList:
        pendingTags.append((deviceId, interfaceCat, 'Customer_Name', customerName, False))
        pendingTags.append((deviceId, interfaceCat, 'Circuit_ID', circuitId, False))
        pendingTags.append((deviceId, interfaceCat, 'Service_Type', serviceType, False))
        pendingTags.append((deviceId, interface, 'Link-Type', 'Customer', False))
        pendingTags.append((deviceId, interfaceCat, 'Last-Modified', current_datetime, False))
        pendingTags.append((deviceId, interfaceCat, 'Connection_Type', connectionType, False))


def clean_up_interface_tags(deviceId, circuitId, allIntfTags):
    """Remove all interface tags for a given circuit on a device.

    Called before re-provisioning so stale tags from a previous run
    don't persist on interfaces that may have changed.
    """
    listOfTags = []
    device_details = allIntfTags.get(deviceId, {})
    for interface, interface_details in device_details.items():
        foundInterface = False
        for label, label_details in interface_details.items():
            if label == 'Circuit_ID':
                if label_details[0] == circuitId:
                    foundInterface = True
                    break
        # Delete all tags on interfaces previously configured by this tool
        if foundInterface:
            for label, label_details in interface_details.items():
                unTag = (deviceId, interface, label, None)
                listOfTags.append(unTag)
    if listOfTags:
        ctx.tags._unassignInterfaceTags(listOfTags)


# =============================================================================
# Validation Helpers
# =============================================================================

def _validateVlan(vlanNum):
    """Validate a VLAN number is present and in range 1-4094. Returns the value if valid."""
    if not vlanNum:
        raise ActionFailed("Please enter a VLAN number")
    try:
        vlanInt = int(vlanNum)
    except (ValueError, TypeError):
        raise ActionFailed(f"VLAN number must be numeric, got: {vlanNum}")
    if vlanInt < 1 or vlanInt > 4094:
        raise ActionFailed(f"VLAN number must be between 1 and 4094, got: {vlanInt}")
    return vlanNum


# =============================================================================
# CLI Generators
# =============================================================================

def processFlexEncap(flexEncap, clientDot1QVlan, clientDot1QInnerVlan):
    """Generate EOS flexible encapsulation CLI based on the encap type."""
    if not flexEncap:
        return ""
    if flexEncap == "client dot1q vlan":
        if clientDot1QVlan:
            flexEncap = f"""encapsulation vlan
        client dot1q {clientDot1QVlan}"""
        else:
            raise ActionFailed("Please enter a Client Vlan Tag")
    elif flexEncap == "client unmatched":
        flexEncap = """encapsulation vlan
        client unmatched"""
    elif flexEncap == "client untagged":
        flexEncap = """encapsulation vlan
        client untagged"""
    elif flexEncap == "client dot1q outer vlan inner vlan":
        if clientDot1QVlan and clientDot1QInnerVlan:
            flexEncap = f"""encapsulation vlan
        client dot1q outer {clientDot1QVlan} inner {clientDot1QInnerVlan}"""
        else:
            raise ActionFailed("Please enter a Client Vlan Tag and Inner Vlan Tag")
    return flexEncap


def processStaticRoutes(staticRoutes, vrfName):
    """Generate EOS static route CLI lines. Uses VRF syntax for VPN-V4/L3-EVPN, global for Direct Internet Access."""
    staticRouteCli = ""
    for route in staticRoutes:
        if vrfName:
            if route.get("description"):
                routeLine = f"""
ip route vrf {vrfName} {route.get("prefix")} {route.get("nextHop")} name {route.get("description")}
    """
            else:
                routeLine = f"""
ip route vrf {vrfName} {route.get("prefix")} {route.get("nextHop")}
    """
        else:
            if route.get("description"):
                routeLine = f"""
ip route {route.get("prefix")} {route.get("nextHop")} name {route.get("description")}
    """
            else:
                routeLine = f"""
ip route {route.get("prefix")} {route.get("nextHop")}
    """
        staticRouteCli = staticRouteCli + routeLine
    staticRouteCli = staticRouteCli + "\n!"
    return staticRouteCli


def processPrefixLists(prefixList, remoteAsn, direction, circuitId):
    """Generate EOS ip prefix-list CLI for inbound or outbound filtering."""
    prefixListCli = ""
    if prefixList and direction == "IN":
        prefixListCli = f"""
ip prefix-list PL_AS{remoteAsn}_{circuitId}_IN
    """
    if prefixList and direction == "OUT":
        prefixListCli = f"""
ip prefix-list PL_AS{remoteAsn}_{circuitId}_OUT
    """
    if prefixList:
        for prefix in prefixList:
            matchType = prefix.get("matchType")
            if matchType != "exact":
                prefixLine = f"""seq {prefix.get("seqNum")} {prefix.get("permitDeny")} {prefix.get("prefix")} {prefix.get("matchType")} {prefix.get("maskLength")}
        """
            else:
                prefixLine = f"""seq {prefix.get("seqNum")} {prefix.get("permitDeny")} {prefix.get("prefix")}
        """
            prefixListCli = prefixListCli + prefixLine
    prefixListCli = prefixListCli + "\n    exit\n!"
    return prefixListCli


def processRouteMaps(remoteAsn, direction):
    """Generate EOS route-map CLI referencing a prefix-list for the given direction."""
    routeMapCli = ""
    if direction == "IN":
        routeMapCli = f"""route-map RM{remoteAsn}-IN permit 10
    match ip address prefix-list PL_AS{remoteAsn}_IN
    exit
    !
        """
    if direction == "OUT":
        routeMapCli = f"""route-map RM{remoteAsn}-OUT permit 10
    match ip address prefix-list PL_AS{remoteAsn}_OUT
    exit
    !
        """
    return routeMapCli


def processDiaRcf(bgpNeighborAsn, circuitId):
    """Generate RCF (Route Control Function) CLI for Direct Internet Access inbound policy."""
    rcfIn = f"""router general
    control-functions
       code unit AS{bgpNeighborAsn}_{circuitId}_RCF
    """
    rcf1 = f"""   function AS{bgpNeighborAsn}_{circuitId}_IN()
    """
    rcf2 = f"""PL_AS{bgpNeighborAsn}_{circuitId});
    """
    rcf3 = """       EOF
       compile
       commit
       exit
    exit
       """
    rcf = rcfIn + rcf1 + "   {\n         return DIA_INBOUND(prefix_list_v4 " + rcf2 + "\n       }\n" + rcf3
    rcf = ""  # RCF disabled — remove this line to enable Direct Internet Access RCF
    return rcf


def processMplsRcfIn():
    """Generate RCF CLI for VPN-V4 inbound policy (LOCAL_PREF community check)."""
    rcf1 = """router general
    control-functions
        code unit CUSTOMER_PEERING
    """
    rcf2 = """     function LOCAL_PREF75_COMMUNITY_IS_PRESENT()
    """
    rcfPart1 = rcf1 + rcf2 + "    {\n" + "        return community has_any {26554:75};\n" + "\n        }\n"
    rcf5 = """        function VPN-V4_CUSTOMER_INBOUND()
    """
    rcf7 = """       EOF
       compile
       commit
       exit
    exit
       """
    rcfPart2 = rcf5 + "    {\n" + """        if LOCAL_PREF75_COMMUNITY_IS_PRESENT() {

              local_preference = 75;

          }

          return true;\n""" + "\n       }\n" + rcf7
    rcf = rcfPart1 + rcfPart2
    rcf = ""  # RCF disabled — remove this line to enable VPN-V4 RCF IN
    return rcf


def processMplsRcfOut(bgpNeighborAsn):
    """Generate RCF CLI for VPN-V4 outbound policy (prefix-list match)."""
    rcf1 = f"""router general
    control-functions
        code unit NET_SOURCE_AS{bgpNeighborAsn}_RCF
    """
    rcf2 = f"""   function NET_SOURCE_AS{bgpNeighborAsn}_OUT()
    """
    rcf3 = """          return prefix match prefix_list_v4 """
    rcf4 = f"""PL_AS{bgpNeighborAsn};
    """
    rcf5 = """       EOF
       compile
       commit
       exit
    exit
       """
    rcf = rcf1 + rcf2 + " {\n " + rcf3 + rcf4 + "\n       }\n" + rcf5
    rcf = ""  # RCF disabled — remove this line to enable VPN-V4 RCF OUT
    return rcf


# =============================================================================
# Interface and ESI Helpers
# =============================================================================

def processPortChannels(interface, dualAttachedPortChannel, otherPortChannelMember, customerName, connectionType):
    """Generate EOS CLI for Port-Channel member Ethernet interfaces."""
    portChannelNum = interface.removeprefix("Port-Channel")
    if not portChannelNum.isdigit():
        raise ActionFailed(f"Port-Channel number must be numeric, got: {portChannelNum}")
    memberPort = portChannelNum
    if connectionType == "NNI":
        description = ""
    else:
        description = f"description {customerName}"
    # Ports above 48 need a slash added in the name
    if int(portChannelNum) > 48:
        memberPort = portChannelNum + "/1"
    if dualAttachedPortChannel:
        ethernetPort = f"""
interface Ethernet{memberPort}
    {description}
    no switchport
    no lldp transmit
    channel-group {portChannelNum} mode active
!
interface {otherPortChannelMember}
    {description}
    no switchport
    no lldp transmit
    channel-group {portChannelNum} mode active
    """
    else:
        ethernetPort = f"""
interface Ethernet{memberPort}
    {description}
    no switchport
    no lldp transmit
    channel-group {portChannelNum} mode active
    """
    return ethernetPort


def calculateEsi(paddedEsi, interface, subinterface):
    """Calculate the EVPN Ethernet Segment Identifier from the ESI prefix, interface, and subinterface."""
    interfaceNum = ""
    if "Ethernet" in interface:
        interfaceNum = interface.removeprefix("Ethernet")
        if "/" in interfaceNum:
            interfaceNumTemp = interfaceNum.replace("/", "")
            interfaceNum = interfaceNumTemp[:-1]
    if "Port-Channel" in interface:
        interfaceNum = interface.removeprefix("Port-Channel")
    interfaceNum = interfaceNum.lstrip()
    index = 0
    while index < 2:
        index = index + 1
        if index > len(interfaceNum):
            interfaceNum = "0" + interfaceNum
    interfaceNum = interfaceNum + ":"
    index = 0
    while index < 4:
        index = index + 1
        if index > len(subinterface):
            subinterface = "0" + subinterface

    esi = paddedEsi + interfaceNum + subinterface
    return esi


def buildEsiPrefix(pe1RouterId, pe2RouterId):
    """Build the ESI prefix string from the last 2 octets of both PE loopbacks.

    Used for multi-homed circuits to generate a deterministic ESI
    based on both PE router IDs.
    """
    pe1EsiOctets = pe1RouterId
    pe2EsiOctets = pe2RouterId
    index = pe1RouterId.find(".")
    if index != -1:
        pe1EsiOctets = pe1RouterId[index + 1:]
    index = pe1EsiOctets.find(".")
    if index != -1:
        pe1EsiOctets = pe1EsiOctets[index + 1:]

    index = pe2RouterId.find(".")
    if index != -1:
        pe2EsiOctets = pe2RouterId[index + 1:]
    index = pe2EsiOctets.find(".")
    if index != -1:
        pe2EsiOctets = pe2EsiOctets[index + 1:]

    esiOctetList = pe1EsiOctets.split('.') + pe2EsiOctets.split('.')
    esiRawString = "00" + "".join(esiOctetList)
    index = 0
    while index < 14:
        index = index + 1
        if index > len(esiRawString):
            esiRawString = esiRawString + "0"
    paddedEsi = ""
    index = 0
    for char in esiRawString:
        if index % 4 == 0 and index != 0:
            paddedEsi = paddedEsi + ":"
        paddedEsi = paddedEsi + char
        index = index + 1
    return paddedEsi


# =============================================================================
# Service-Type Interface Processors
# =============================================================================

def processL2EvpnInterfaces(deviceNameList, l2EvpnInterfaces, paddedEsi, multiHoming, customerName, bgpSessionTrackingCLI, circuitId, serviceType, vlan, flexEncap, serviceLevelConfig, dualAttachedPortChannel, otherPortChannelMember, connectionType, pendingTags):
    """Generate interface CLI and multi-homing config for L2-EVPN / L2-EVPN + IRB circuits.

    Returns (interfacesListCat1, interfacesListCat2, autoRT) — separate CLI
    for device 1 and device 2 in multi-homed scenarios, plus the auto-RT config.
    """
    interfacesListCat1 = ""
    interfacesListCat2 = ""
    autoRT = ""
    serviceTypeLabel = serviceType.replace(" ", "_").replace("+", "and") if serviceType else ""
    vrfName = ""
    if vlan:
        vlanId = f"vlan id {vlan}"
    else:
        raise ActionFailed("Please enter a Vlan ID")
    if connectionType == "NNI":
        description = ""
    else:
        description = f"description {customerName}"
    if l2EvpnInterfaces is not None:
        for l2EvpnInterface in l2EvpnInterfaces:
            interface = l2EvpnInterface.get("interface")
            if not ("Port-Channel" in interface or "Ethernet" in interface):
                raise ActionFailed("Check the spelling of Ethernet or Port-Channel")
            subinterface = l2EvpnInterface.get("subInterface")
            if not subinterface:
                raise ActionFailed("Please enter a sub interface number")
            interfaceTags(deviceNameList, interface, subinterface, customerName, circuitId, serviceType, connectionType, vrfName, pendingTags)
            esi = calculateEsi(paddedEsi, interface, subinterface)
            lldp = ""
            if "Port-Channel" in interface:
                ethernetPort = processPortChannels(interface, dualAttachedPortChannel, otherPortChannelMember, customerName, connectionType)
                if multiHoming in ("Active Active Multi Homing", "Single Active Multi Homing"):
                    lacpSysId = "lacp system-id aaaa.bbbb.cccc"
                else:
                    lacpSysId = ""
            else:
                lldp = "no lldp transmit"
                lacpSysId = ""
                ethernetPort = ""
            multiHomingConfig1 = ""
            multiHomingConfig2 = ""
            if multiHoming != "Single Homed":
                autoRT = """
address-family evpn
   route type ethernet-segment route-target auto
   exit
                """
            if multiHoming == "Active Active Multi Homing":
                if "Port-Channel" not in interface:
                    raise ActionFailed("Active Active Multi Homing requires Port-Channel")
                multiHomingConfig1 = f"""evpn ethernet-segment
    identifier {esi}
!"""
                multiHomingConfig2 = f"""evpn ethernet-segment
    identifier {esi}
!"""
            elif multiHoming == "Single Active Multi Homing":
                if "Ethernet" not in interface:
                    raise ActionFailed("Single Active Multi Homing requires Ethernet Interface")
                multiHomingConfig1 = f"""evpn ethernet-segment
    identifier {esi}
    redundancy single-active
    designated-forwarder election algorithm preference 2000 dont-preempt
!"""
                multiHomingConfig2 = f"""evpn ethernet-segment
    identifier {esi}
    redundancy single-active
    designated-forwarder election algorithm preference 1000 dont-preempt
!"""
            interfacesList1 = f"""
{ethernetPort}
!
interface {interface}
    {description}
    {bgpSessionTrackingCLI}
    no switchport
    {lacpSysId}
    {lldp}
!
interface {interface}.{subinterface}
    description {customerName}/{circuitId}/{serviceTypeLabel}
    {vlanId}
    !
    {flexEncap}
    !
    {serviceLevelConfig}
    {multiHomingConfig1}
    exit
"""
            interfacesList2 = f"""
{ethernetPort}
!
interface {interface}
    {description}
    {bgpSessionTrackingCLI}
    no switchport
    {lacpSysId}
    {lldp}
!
interface {interface}.{subinterface}
    description {customerName}/{circuitId}/{serviceTypeLabel}
    {vlanId}
    !
    {flexEncap}
    !
    {serviceLevelConfig}
    {multiHomingConfig2}
    exit
"""
            interfacesListCat1 = interfacesListCat1 + interfacesList1
            interfacesListCat2 = interfacesListCat2 + interfacesList2
    return interfacesListCat1, interfacesListCat2, autoRT


def processMplsInterfaces(deviceNameList, vlanInterfaces, ipVpnInterfaces, paddedEsi, multiHoming, customerName, bgpSessionTrackingCLI, circuitId, serviceType, serviceLevelConfig, vrfName, dualAttachedPortChannel, _routingType, l3Encap, otherPortChannelMember, _prefixList, _prefixListOut, connectionType, bgpPolicy, defaultOriginate, flexEncap, clientDot1QVlan, clientDot1QInnerVlan, pendingTags):
    """Generate interface, VLAN SVI, and BGP neighbor CLI for Direct Internet Access / VPN-V4 / L3-EVPN circuits.

    Handles both L3 subinterfaces (ipVpnInterfaces) and VLAN SVI interfaces
    (vlanInterfaces with L2 subinterfaces bridged to the SVI). Produces
    separate CLI for device 1 and device 2 in multi-homed scenarios.
    """
    vlanInterfaceConfigCat1 = ""
    vlanInterfaceConfigCat2 = ""
    serviceTypeLabel = serviceType.replace(" ", "_").replace("+", "and") if serviceType else ""
    vlanNum = None
    if vrfName and serviceType != "Direct Internet Access":
        vrfConfig = f"vrf {vrfName}"
    elif not vrfName and serviceType != "Direct Internet Access":
        raise ActionFailed("Please enter a VRF Name")
    else:
        vrfConfig = ""
    if connectionType == "NNI":
        description = ""
    else:
        description = f"description {customerName}"
    if vlanInterfaces is not None:
        for vlan in vlanInterfaces:
            vlanSubnet = vlan.get("ipAddress")
            firstIP, secondIP, thirdIP, subnetMask = "", "", "", ""
            if vlanSubnet:
                network = ipaddress.IPv4Network(vlanSubnet, strict=False)
                firstIP, secondIP, thirdIP = network[1], network[2], network[3]
                subnetMask = network.prefixlen
            else:
                raise ActionFailed("Please enter a Subnet Address")
            l2SubInterfaceConfig1Cat1 = ""
            l2SubInterfaceConfig1Cat2 = ""
            vlanNum = _validateVlan(vlan.get("vlanNumber"))
            interface = "Vlan" + str(vlanNum)
            subinterface = ""
            interfaceTags(deviceNameList, interface, subinterface, customerName, circuitId, serviceType, connectionType, vrfName, pendingTags)
            for l2SubInterface in vlan.get("l2SubInterfaces"):
                interface = l2SubInterface.get("interface")
                if not ("Port-Channel" in interface or "Ethernet" in interface):
                    raise ActionFailed("Check the spelling of Ethernet or Port-Channel")
                subInterfaceNumber = l2SubInterface.get("subInterfaceNumber")
                if not subInterfaceNumber:
                    raise ActionFailed("Please enter a sub interface number")
                if vlanNum:
                    vlanId = f"vlan id {vlanNum}"
                else:
                    vlanId = ""
                interfaceTags(deviceNameList, interface, subInterfaceNumber, customerName, circuitId, serviceType, connectionType, vrfName, pendingTags)
                l2FlexEncap = l2SubInterface.get("flexEncap")
                clientDot1QVlan = l2SubInterface.get("clientDot1QVlan")
                clientDot1QInnerVlan = l2SubInterface.get("clientDot1QInnerVlan")
                l2FlexEncap = processFlexEncap(l2FlexEncap, clientDot1QVlan, clientDot1QInnerVlan)
                lldp = ""
                esi = calculateEsi(paddedEsi, interface, subInterfaceNumber)
                if "Port-Channel" in interface:
                    ethernetPort = processPortChannels(interface, dualAttachedPortChannel, otherPortChannelMember, customerName, connectionType)
                    if multiHoming in ("Active Active Multi Homing", "Single Active Multi Homing"):
                        lacpSysId = "lacp system-id aaaa.bbbb.cccc"
                    else:
                        lacpSysId = ""
                else:
                    ethernetPort = ""
                    lldp = "no lldp transmit"
                    lacpSysId = ""
                if multiHoming != "Single Homed":
                    autoRT = """
address-family evpn
    route type ethernet-segment route-target auto
    exit
                    """
                multiHomingConfig1 = ""
                multiHomingConfig2 = ""
                if multiHoming == "Active Active Multi Homing":
                    if "Port-Channel" not in interface:
                        raise ActionFailed("Active Active Multi Homing requires Port-Channel")
                    multiHomingConfig1 = f"""evpn ethernet-segment
    identifier {esi}
!"""
                    multiHomingConfig2 = f"""evpn ethernet-segment
    identifier {esi}
!"""
                elif multiHoming == "Single Active Multi Homing":
                    if "Ethernet" not in interface:
                        raise ActionFailed("Single Active Multi Homing requires Ethernet Interface")
                    multiHomingConfig1 = f"""evpn ethernet-segment
    identifier {esi}
    redundancy single-active
    designated-forwarder election algorithm preference 2000 dont-preempt
!"""
                    multiHomingConfig2 = f"""evpn ethernet-segment
    identifier {esi}
    redundancy single-active
    designated-forwarder election algorithm preference 1000 dont-preempt
!"""
                l2SubInterfaceConfig1 = f"""
{ethernetPort}
!
interface {interface}
    {description}
    {bgpSessionTrackingCLI}
    no switchport
    {lacpSysId}
    {lldp}
!
interface {interface}.{subInterfaceNumber}
    description {customerName}/{circuitId}/{serviceTypeLabel}
    {vlanId}
    !
    {l2FlexEncap}
    !
    {serviceLevelConfig}
    {multiHomingConfig1}
"""
                l2SubInterfaceConfig2 = f"""
{ethernetPort}
!
interface {interface}
    {description}
    {bgpSessionTrackingCLI}
    no switchport
    {lacpSysId}
    {lldp}
!
interface {interface}.{subInterfaceNumber}
    description {customerName}/{circuitId}/{serviceTypeLabel}
    {vlanId}
    !
    {l2FlexEncap}
    !
    {serviceLevelConfig}
    {multiHomingConfig2}
"""
                l2SubInterfaceConfig1Cat1 = l2SubInterfaceConfig1Cat1 + l2SubInterfaceConfig1
                l2SubInterfaceConfig1Cat2 = l2SubInterfaceConfig1Cat2 + l2SubInterfaceConfig2
            virtualRouterAddress = f"""ip virtual-router address {firstIP}"""
            vRouterMac = "ip virtual-router mac-address 00:1c:73:00:00:01"
            vlanInterfaceConfig1 = f"""
vlan {vlanNum}
    name {customerName}/{circuitId}/{serviceTypeLabel}
!
{l2SubInterfaceConfig1Cat1}
!
interface Vlan{vlanNum}
    description {customerName}/{circuitId}/{serviceTypeLabel}
    {vrfConfig}
    ip address {secondIP}/{subnetMask}
    {virtualRouterAddress}
    {serviceLevelConfig}
!
{vRouterMac}
!
"""
            vlanInterfaceConfig2 = f"""
vlan {vlanNum}
    name {customerName}/{circuitId}/{serviceTypeLabel}
!
{l2SubInterfaceConfig1Cat2}
!
interface Vlan{vlanNum}
    description {customerName}/{circuitId}/{serviceTypeLabel}
    {vrfConfig}
    ip address {thirdIP}/{subnetMask}
    {virtualRouterAddress}
    {serviceLevelConfig}
!
{vRouterMac}
!
"""
            vlanInterfaceConfigCat1 = vlanInterfaceConfigCat1 + vlanInterfaceConfig1
            vlanInterfaceConfigCat2 = vlanInterfaceConfigCat2 + vlanInterfaceConfig2
    ipVpnInterfacesListCat = ""
    vrfNeighborCat = " "
    rcfBgpCat = ""
    rcfConfig = ""
    rcfBgpCatOut = ""
    rcfConfigMplsOut = ""
    addressFamilyNeighborCat = " "
    encapConfig = ""
    routeMapIn = ""
    routeMapOut = ""
    autoRT = ""
    if ipVpnInterfaces is not None:
        for ipInterface in ipVpnInterfaces:
            interface = ipInterface.get("interface")
            subinterface = ipInterface.get("subInterface")
            if l3Encap == "Dot1q":
                encapConfig = f"encapsulation dot1q vlan {subinterface}"
            elif l3Encap == "FlexEncap":
                encapConfig = processFlexEncap(flexEncap, clientDot1QVlan, clientDot1QInnerVlan)
            lldp = ""
            if not ("Port-Channel" in interface or "Ethernet" in interface):
                raise ActionFailed("Check the spelling of Ethernet or Port-Channel")
            if "Port-Channel" in interface:
                ethernetPort = processPortChannels(interface, dualAttachedPortChannel, otherPortChannelMember, customerName, connectionType)
            else:
                lldp = "no lldp transmit"
                ethernetPort = ""
            interfaceTags(deviceNameList, interface, subinterface, customerName, circuitId, serviceType, connectionType, vrfName, pendingTags)
            ipVpnInterfacesList = f"""
{ethernetPort}
!
interface {interface}
    {description}
    {bgpSessionTrackingCLI}
    no switchport
    {lldp}
!
interface {interface}.{subinterface}
    description {customerName}/{circuitId}/{serviceTypeLabel}
    {vrfConfig}
    ip address {ipInterface.get("ipAddress")}
    {encapConfig}
    {serviceLevelConfig}
!
"""
            ipVpnInterfacesListCat = ipVpnInterfacesListCat + ipVpnInterfacesList
            bgpNeighborIp = ipInterface.get("bgpNeighborIp")
            bgpNeighborAsn = ipInterface.get("remoteAsn")
            rcfPolicy = ipInterface.get("rcfOutPolicy")
            if bgpNeighborIp is not None and serviceType == "Direct Internet Access":
                vrfNeighbor = f"""neighbor {bgpNeighborIp} remote-as {bgpNeighborAsn}
         neighbor {bgpNeighborIp} description {customerName}/{circuitId}/{serviceTypeLabel}
                """
                vrfNeighborCat = vrfNeighborCat + vrfNeighbor
                addressFamilyNeighbor = f"""neighbor {bgpNeighborIp} activate
                """
                addressFamilyNeighborCat = addressFamilyNeighborCat + addressFamilyNeighbor
                if bgpPolicy != "No":
                    rcf = f""" neighbor {bgpNeighborIp} rcf in AS{bgpNeighborAsn}_{circuitId}_IN()
            neighbor {bgpNeighborIp} rcf out {rcfPolicy}
                    """
                    rcfBgpCat = rcfBgpCat + rcf
                    rcfConfig = processDiaRcf(bgpNeighborAsn, circuitId)
            elif bgpNeighborIp is not None and serviceType == "VPN-V4":
                if defaultOriginate:
                    vrfNeighbor = f"""
         neighbor {bgpNeighborIp} remote-as {bgpNeighborAsn}
         neighbor {bgpNeighborIp} description {customerName}/{circuitId}/{serviceTypeLabel}
         neighbor {bgpNeighborIp} default-originate
         """
                else:
                    vrfNeighbor = f"""
         neighbor {bgpNeighborIp} remote-as {bgpNeighborAsn}
         neighbor {bgpNeighborIp} description {customerName}/{circuitId}/{serviceTypeLabel}
                """
                vrfNeighborCat = vrfNeighborCat + vrfNeighbor
                addressFamilyNeighbor = f"""neighbor {bgpNeighborIp} activate
         """
                addressFamilyNeighborCat = addressFamilyNeighborCat + addressFamilyNeighbor
                if bgpPolicy != "No":
                    rcf = f"""  neighbor {bgpNeighborIp} rcf in CUSTOMER_PEERING()
                    """
                    rcfOut = f"""  neighbor {bgpNeighborIp} rcf out NET_SOURCE_AS{bgpNeighborAsn}_RCF()
                    """
                    if bgpPolicy in ("In", "In and Out"):
                        rcfBgpCat = rcfBgpCat + rcf
                        rcfConfig = processMplsRcfIn()
                    if bgpPolicy in ("Out", "In and Out"):
                        rcfBgpCatOut = rcfBgpCatOut + rcfOut
                        rcfConfigMplsOut = processMplsRcfOut(bgpNeighborAsn)
    return vlanInterfaceConfigCat1, vlanInterfaceConfigCat2, ipVpnInterfacesListCat, vrfNeighborCat, addressFamilyNeighborCat, rcfBgpCat, rcfConfig, routeMapIn, routeMapOut, rcfBgpCatOut, rcfConfigMplsOut, autoRT


# =============================================================================
# Service-Type Template Builders
# =============================================================================

def _circuitType(context):
    """Build the circuitType metadata dict used in every service configlet."""
    return {
        "circuitState": context["circuitState"],
        "multiHoming": context["multiHoming"],
        "customerName": context["customerName"],
        "connectionType": context["connectionType"],
        "currentDatetime": context["current_datetime"],
        "serviceType": context["serviceType"],
    }


def _serviceEntry(context, cli):
    """Build a single service entry dict with generated CLI."""
    return {
        "cliGroup": {
            "circuitType": _circuitType(context),
            "cli": re.sub(r'\n\s*\n', '\n', cli),
        },
        "serviceType": context["serviceType"],
        "customerName": context["customerName"],
        "currentDatetime": context["current_datetime"],
        "circuitId": context["circuitId"],
    }


def buildDiaCli(context):
    """Generate CLI configlets for Direct Internet Access circuits."""
    settings = context["svcSettings"]
    mplsResult = processMplsInterfaces(
        context["deviceNameList"], settings["vlanInterfaces"], settings["ipVpnInterfaces"],
        context["paddedEsi"], context["multiHoming"], context["customerName"],
        context["bgpSessionTrackingCLI"], context["circuitId"], context["serviceType"],
        context["serviceLevelConfig"], context["vrfName"], settings["dualAttachedPortChannel"],
        settings["routingType"], settings["l3Encap"], settings["otherPortChannelMember"],
        settings["prefixList"], settings["prefixListOut"], settings["connectionType"],
        settings["bgpPolicy"], context["defaultOriginate"], settings["flexEncap"],
        settings["clientDot1QVlan"], settings["clientDot1QInnerVlan"], context["pendingTags"])
    vlanCfg1, vlanCfg2, ipVpnCfg, vrfNbr, afNbr, rcfBgp, rcfCfg, _, _, _, _, _ = mplsResult

    prefixListCli = ""
    staticRouteCli = ""
    remoteAsn = ""
    if settings["ipVpnInterfaces"]:
        for asn in settings["ipVpnInterfaces"]:
            remoteAsn = asn.get("remoteAsn")
    if settings.get("staticRoutes"):
        staticRouteCli = processStaticRoutes(settings["staticRoutes"], context["vrfName"])
    prefixListCli = processPrefixLists(settings["prefixList"], remoteAsn, "OUT", context["circuitId"])
    bgpAs = context["bgpAs"]

    if settings["routingType"] == "BGP":
        context["device1Services"].append(_serviceEntry(context, f"""
{ipVpnCfg}
{vlanCfg1}
{prefixListCli}
router bgp {bgpAs}
!
    {vrfNbr}
    !
    address-family ipv4
        {afNbr}
        {rcfBgp}
        exit
    exit
!
{rcfCfg}
                """))
    elif settings["routingType"] == "Directly Connected":
        context["device1Services"].append(_serviceEntry(context, f"""
{ipVpnCfg}
{vlanCfg1}
{staticRouteCli}
!
                """))
        context["device2Services"].append(_serviceEntry(context, f"""
{ipVpnCfg}
{vlanCfg2}
{staticRouteCli}
router bgp {bgpAs}
!
                """))


def buildVpnV4Cli(context):
    """Generate CLI configlets for VPN-V4 / L3-EVPN circuits."""
    settings = context["svcSettings"]
    mplsResult = processMplsInterfaces(
        context["deviceNameList"], settings["vlanInterfaces"], settings["ipVpnInterfaces"],
        context["paddedEsi"], context["multiHoming"], context["customerName"],
        context["bgpSessionTrackingCLI"], context["circuitId"], context["serviceType"],
        context["serviceLevelConfig"], context["vrfName"], settings["dualAttachedPortChannel"],
        settings["routingType"], settings["l3Encap"], settings["otherPortChannelMember"],
        settings["prefixList"], settings["prefixListOut"], settings["connectionType"],
        settings["bgpPolicy"], context["defaultOriginate"], settings["flexEncap"],
        settings["clientDot1QVlan"], settings["clientDot1QInnerVlan"], context["pendingTags"])
    vlanCfg1, vlanCfg2, ipVpnCfg, vrfNbr, afNbr, rcfBgp, rcfCfg, routeMapIn, routeMapOut, rcfBgpOut, rcfMplsOut, autoRT = mplsResult

    prefixListCli = ""
    prefixListOutCli = ""
    staticRouteCli = ""
    remoteAsn = ""
    rtImport = ""
    rtExport = ""
    bgpAs = context["bgpAs"]
    vrfName = context["vrfName"]
    evi = context["evi"]
    pe1RouterId = context["pe1RouterId"]
    serviceType = context["serviceType"]
    serviceTypeLabel = context["serviceTypeLabel"]

    leftSideOfRd = f"rd {pe1RouterId}"
    if serviceType == "VPN-V4":
        leftSideOfRd = f"rd {bgpAs}"
    if serviceType == "VPN-V4":
        rtImport = "vpn-ipv4"
        rtExport = "vpn-ipv4"
    elif serviceType == "L3-EVPN":
        rtImport = "evpn"
        rtExport = "evpn"
    if settings["ipVpnInterfaces"]:
        for asn in settings["ipVpnInterfaces"]:
            remoteAsn = asn.get("remoteAsn")
    if settings["staticRoutes"]:
        staticRouteCli = processStaticRoutes(settings["staticRoutes"], vrfName)
    if settings["prefixList"]:
        prefixListCli = processPrefixLists(settings["prefixList"], remoteAsn, "IN", context["circuitId"])
        routeMapIn = processRouteMaps(remoteAsn, "IN")
    if settings["prefixListOut"]:
        prefixListOutCli = processPrefixLists(settings["prefixListOut"], remoteAsn, "OUT", context["circuitId"])
        routeMapOut = processRouteMaps(remoteAsn, "OUT")

    if settings["routingType"] == "BGP":
        context["device1Services"].append(_serviceEntry(context, f"""
vrf instance {vrfName}
!
ip routing vrf {vrfName}
!
{ipVpnCfg}
{vlanCfg2}
{staticRouteCli}
{prefixListCli}
{prefixListOutCli}
router bgp {bgpAs}
    {routeMapIn}
    {routeMapOut}
    !
    vrf {vrfName}
         {leftSideOfRd}:{evi}
         route-target import {rtImport} {bgpAs}:{evi}
         route-target export {rtExport} {bgpAs}:{evi}
        {vrfNbr}
    address-family ipv4
        {afNbr}
        {rcfBgp}
        {rcfBgpOut}
         redistribute connected
         redistribute static
         exit
    {autoRT}
    exit
exit
!
{rcfCfg}
{rcfMplsOut}
                """))
        context["device2Services"].append(_serviceEntry(context, f"""

vrf instance {vrfName}
!
ip routing vrf {vrfName}
!
{ipVpnCfg}
{vlanCfg2}
{staticRouteCli}
{prefixListCli}
{prefixListOutCli}
router bgp {bgpAs}
    {routeMapIn}
    {routeMapOut}
   !
   vrf {vrfName}
       {leftSideOfRd}:{evi}
       route-target import {rtImport} {bgpAs}:{evi}
       route-target export {rtExport} {bgpAs}:{evi}
     {vrfNbr}
   address-family ipv4
     {afNbr}
     {rcfBgp}
     {rcfBgpOut}
       redistribute connected
       redistribute static
       exit
   {autoRT}
   exit
exit
!
{rcfCfg}
{rcfMplsOut}
        """))
    elif settings["routingType"] == "Directly Connected":
        context["device1Services"].append(_serviceEntry(context, f"""
vrf instance {vrfName}
!
ip routing vrf {vrfName}
!
{ipVpnCfg}
{vlanCfg1}
{staticRouteCli}
router bgp {bgpAs}
    {routeMapIn}
    {routeMapOut}
    !
    vrf {vrfName}
         {leftSideOfRd}:{evi}
         route-target import {rtImport} {bgpAs}:{evi}
         route-target export {rtExport} {bgpAs}:{evi}
        {vrfNbr}
    address-family ipv4
        {afNbr}
         redistribute connected
         redistribute static
         exit
    {autoRT}
    exit
exit
                """))
        context["device2Services"].append(_serviceEntry(context, f"""

vrf instance {vrfName}
!
ip routing vrf {vrfName}
!
{ipVpnCfg}
{vlanCfg2}
{staticRouteCli}
router bgp {bgpAs}
    {routeMapIn}
    {routeMapOut}
   !
   vrf {vrfName}
       {leftSideOfRd}:{evi}
       route-target import {rtImport} {bgpAs}:{evi}
       route-target export {rtExport} {bgpAs}:{evi}
     {vrfNbr}
   address-family ipv4
     {afNbr}
       redistribute connected
       redistribute static
       exit
   {autoRT}
   exit
exit
        """))


def buildL2EvpnCli(context):
    """Generate CLI configlets for L2-EVPN / L2-EVPN + IRB circuits."""
    settings = context["svcSettings"]
    interfacesListCat1, interfacesListCat2, autoRT = processL2EvpnInterfaces(
        context["deviceNameList"], settings["l2EvpnInterfaces"], context["paddedEsi"],
        context["multiHoming"], context["customerName"], context["bgpSessionTrackingCLI"],
        context["circuitId"], context["serviceType"], settings["vlan"], settings["flexEncap"],
        context["serviceLevelConfig"], settings["dualAttachedPortChannel"],
        settings["otherPortChannelMember"], settings["connectionType"], context["pendingTags"])

    bgpAs = context["bgpAs"]
    evi = context["evi"]
    customerName = context["customerName"]
    circuitId = context["circuitId"]
    serviceType = context["serviceType"]
    serviceTypeLabel = context["serviceTypeLabel"]
    vlan = settings["vlan"]
    pe1RouterId = context["pe1RouterId"]
    pe2RouterId = context["pe2RouterId"]

    if serviceType == "L2-EVPN + IRB":
        sviCfg = f"""
ip virtual-router mac-address 00:1c:73:00:00:01
!
vrf instance {settings['ipAddressVirtualVrf']}
!
interface Vlan{vlan}
    description {customerName}/{circuitId}/{serviceTypeLabel}
    mtu 9016
    vrf {settings['ipAddressVirtualVrf']}
    ip address virtual {settings['ipAddressVirtual']}
    exit
                """
    else:
        sviCfg = ""

    context["device1Services"].append(_serviceEntry(context, f"""
vlan {vlan}
   name {customerName}/{circuitId}/{serviceTypeLabel}
!
{interfacesListCat1}
!
router bgp {bgpAs}
   !
   vlan {vlan}
      rd {pe1RouterId}:{evi}
      route-target both {bgpAs}:{evi}
      redistribute learned
      !
      {autoRT}
      exit
   exit
!
{sviCfg}
        """))
    context["device2Services"].append(_serviceEntry(context, f"""
vlan {vlan}
   name {customerName}/{circuitId}/{serviceTypeLabel}
!
{interfacesListCat2}
router bgp {bgpAs}
   !
   vlan {vlan}
      rd {pe2RouterId}:{evi}
      route-target both {bgpAs}:{evi}
      redistribute learned
      !
      {autoRT}
      exit
   exit
!
{sviCfg}
        """))


def buildVplsCli(context):
    """Generate CLI configlets for VPLS circuits."""
    settings = context["svcSettings"]
    interface = settings["interface"]
    subInterface = settings["subInterface"]
    if "Ethernet" not in interface:
        raise ActionFailed("Check the spelling of Ethernet")
    if not subInterface:
        raise ActionFailed("Please enter a sub interface number")
    interfaceTags(context["deviceNameList"], interface, subInterface, context["customerName"],
                  context["circuitId"], context["serviceType"], settings["connectionType"], "", context["pendingTags"])
    vlanId = f"vlan id {settings['vlan']}" if settings["vlan"] else ""
    customerName = context["customerName"]
    circuitId = context["circuitId"]
    serviceType = context["serviceType"]
    serviceTypeLabel = context["serviceTypeLabel"]
    vlan = settings["vlan"]
    flexEncap = settings["flexEncap"]
    serviceLevelConfig = context["serviceLevelConfig"]

    context["device1Services"].append(_serviceEntry(context, f"""
vlan {vlan}
   name {customerName}/{circuitId}/{serviceTypeLabel}
!
interface {interface}
   description {customerName}
   no switchport
   no lldp transmit
!
interface {interface}.{subInterface}
   description {customerName}/{circuitId}/{serviceTypeLabel}
   {vlanId}
      {flexEncap}
   !
   {serviceLevelConfig}
!
mpls ldp
   !
   pseudowires
      profile {circuitId}
         mtu 9000
         control-word
         label flow
         exit
      exit
   exit
!
router vpls
   vpls {circuitId}
      ldp mac withdrawal trigger interface
      !
      vlan bundle {vlan}
      !
      pseudowire ldp {circuitId} split-horizon
         bgp auto-discovery profile {circuitId} id 1
         exit
      exit
   exit
        """))


def buildVpwsCli(context):
    """Generate CLI configlets for VPWS (point-to-point) circuits."""
    settings = context["svcSettings"]
    interface = settings["interface"]
    subInterface = settings["subInterface"]
    multiHoming = context["multiHoming"]
    paddedEsi = context["paddedEsi"]
    bgpAs = context["bgpAs"]
    evi = context["evi"]
    customerName = context["customerName"]
    circuitId = context["circuitId"]
    serviceType = context["serviceType"]
    serviceTypeLabel = context["serviceTypeLabel"]
    autoRT = context["autoRT"]
    bgpSessionTrackingCLI = context["bgpSessionTrackingCLI"]
    serviceLevelConfig = context["serviceLevelConfig"]
    pe1RouterId = context["pe1RouterId"]
    pe2RouterId = context["pe2RouterId"]
    flexEncap = settings["flexEncap"]

    if not ("Port-Channel" in interface or "Ethernet" in interface):
        raise ActionFailed("Check the spelling of Ethernet or Port-Channel")
    if not subInterface:
        raise ActionFailed("Please enter a sub interface number")
    if settings["connectionType"] == "NNI":
        description = ""
    else:
        description = f"description {customerName}"
    interfaceTags(context["deviceNameList"], interface, subInterface, customerName,
                  circuitId, serviceType, settings["connectionType"], "", context["pendingTags"])
    esi = calculateEsi(paddedEsi, interface, subInterface)
    lldp = ""
    if "Port-Channel" in interface:
        ethernetPort = processPortChannels(interface, settings["dualAttachedPortChannel"],
                                           settings["otherPortChannelMember"], customerName, settings["connectionType"])
        if multiHoming in ("Active Active Multi Homing", "Single Active Multi Homing"):
            lacpSysId = "lacp system-id aaaa.bbbb.cccc"
        else:
            lacpSysId = ""
    else:
        lldp = "no lldp transmit"
        lacpSysId = ""
        ethernetPort = ""
    if multiHoming != "Single Homed":
        autoRT = """
   address-family evpn
      route type ethernet-segment route-target auto
      exit
                """
    multiHomingConfig1 = ""
    multiHomingConfig2 = ""
    if multiHoming == "Active Active Multi Homing":
        if "Port-Channel" not in interface:
            raise ActionFailed("Active Active Multi Homing requires Port-Channel")
        multiHomingConfig1 = f"""
   evpn ethernet-segment
      identifier {esi}
   !"""
        multiHomingConfig2 = f"""
   evpn ethernet-segment
      identifier {esi}
   !"""
    elif multiHoming == "Single Active Multi Homing":
        if "Ethernet" not in interface:
            raise ActionFailed("Single Active Multi Homing requires Ethernet Interface")
        multiHomingConfig1 = f"""
   evpn ethernet-segment
      identifier {esi}
      redundancy single-active
      designated-forwarder election algorithm preference 2000 dont-preempt
   !"""
        multiHomingConfig2 = f"""
   evpn ethernet-segment
      identifier {esi}
      redundancy single-active
      designated-forwarder election algorithm preference 1000 dont-preempt
   !"""

    context["device1Services"].append(_serviceEntry(context, f"""
{ethernetPort}
!
interface {interface}
   {description}
   {bgpSessionTrackingCLI}
   no switchport
   {lacpSysId}
   {lldp}
!
interface {interface}.{subInterface}
   description {customerName}/{circuitId}/{serviceTypeLabel}
      {flexEncap}
   !
   {serviceLevelConfig}
   {multiHomingConfig1}
!
patch panel
   patch {circuitId}
      connector 1 interface {interface}.{subInterface}
      connector 2 pseudowire bgp vpws {circuitId} pseudowire {evi}
!
router bgp {bgpAs}
   !
   vpws {circuitId}
      rd {pe1RouterId}:{evi}
      route-target import export evpn {bgpAs}:{evi}
      mpls control-word
      !
      pseudowire {evi}
         evpn vpws id local 1 remote 1
         exit
      exit
      {autoRT}
   exit
        """))
    context["device2Services"].append(_serviceEntry(context, f"""
{ethernetPort}
!
interface {interface}
   {description}
   {bgpSessionTrackingCLI}
   no switchport
   {lacpSysId}
   {lldp}
!
interface {interface}.{subInterface}
   description {customerName}/{circuitId}/{serviceTypeLabel}
      {flexEncap}
   !
   {serviceLevelConfig}
   {multiHomingConfig2}
!
patch panel
   patch {circuitId}
      connector 1 interface {interface}.{subInterface}
      connector 2 pseudowire bgp vpws {circuitId} pseudowire {evi}
!
router bgp {bgpAs}
   !
   vpws {circuitId}
      rd {pe2RouterId}:{evi}
      route-target import export evpn {bgpAs}:{evi}
      mpls control-word
      !
      pseudowire {evi}
         evpn vpws id local 1 remote 1
         exit
      exit
      {autoRT}
   exit
        """))


# =============================================================================
# Input Extraction
# =============================================================================

def getCustomerStdInputs(inputPath, customerStdInputs):
    """Extract circuit and PE info from the Customer Studio for the selected path."""
    customerIdx = int(inputPath[1])
    circuitIdx = int(inputPath[3])
    peIdx = int(inputPath[5])
    customer = customerStdInputs['customers'][customerIdx].get('customerName')
    circuit = customerStdInputs['customers'][customerIdx]['circuits'][circuitIdx]
    circuitInfo = circuit['pEs'][peIdx]
    circuitInfo['customer'] = customer
    circuitInfo['serviceType'] = circuit.get("serviceType")
    circuitInfo['serviceLevel'] = circuit.get("serviceLevel")
    circuitInfo['circuitId'] = circuit.get("circuitId")
    circuitInfo['evi'] = circuit.get("evi")
    circuitInfo['vrfName'] = circuit.get("vrfName")
    globalSettings = customerStdInputs.get("globalSettings", {})
    # localASN moved to root level in schema 0.3.2; fall back to globalSettings for older versions
    if "localASN" in customerStdInputs:
        globalSettings["localASN"] = customerStdInputs["localASN"]
    return circuitInfo, globalSettings


def extractServiceSettings(serviceType, circuitInfo):
    """Extract service-type-specific settings from the circuit info.

    Returns a dict with all the settings needed by the template builder
    for the given service type.
    """
    settings = circuitInfo.get("settings", {})
    group = settings.get("group", {})
    result = {
        "lockCircuit": False,
        "circuitState": None,
        "routingType": "Directly Connected",
        "connectionType": group.get("connectionType", "UNI"),
        "interfaceType": group.get("interfaceType"),
    }

    if serviceType == "Direct Internet Access":
        dia = settings.get("diaSettings", {})
        result.update({
            "circuitState": dia.get("circuitState"),
            "lockCircuit": dia.get("lockCircuit"),
            "routingType": group.get("routingType"),
            "dualAttachedPortChannel": dia.get("dualAttachedPortChannel"),
            "otherPortChannelMember": dia.get("otherPortChannelMember"),
            "ipVpnInterfaces": settings.get("ipVpnInterfaces"),
            "prefixList": settings.get("prefixList"),
            "staticRoutes": settings.get("staticRoutes"),
            "vlanInterfaces": settings.get("vlanInterfaces"),
            "l3Encap": group.get("l3Encap"),
            "flexEncap": group.get("flexEncap"),
            "clientDot1QVlan": group.get("clientDot1QVlan"),
            "clientDot1QInnerVlan": group.get("clientDot1QInnerVlan"),
            "prefixListOut": "",
            "bgpPolicy": group.get("bgpPolicy"),
        })
    elif serviceType == "VPN-V4":
        ipvpn = settings.get("ipVpnSettings", {})
        result.update({
            "circuitState": ipvpn.get("circuitState"),
            "lockCircuit": ipvpn.get("lockCircuit"),
            "dualAttachedPortChannel": ipvpn.get("dualAttachedPortChannel"),
            "otherPortChannelMember": ipvpn.get("otherPortChannelMember"),
            "defaultOriginate": ipvpn.get("defaultOriginate"),
            "routingType": group.get("routingType"),
            "bgpPolicy": group.get("bgpPolicy"),
            "ipVpnInterfaces": settings.get("ipVpnInterfaces"),
            "prefixList": settings.get("prefixList"),
            "prefixListOut": settings.get("prefixListOut"),
            "staticRoutes": settings.get("staticRoutes"),
            "vlanInterfaces": settings.get("vlanInterfaces"),
            "l3Encap": group.get("l3Encap"),
            "flexEncap": group.get("flexEncap"),
            "clientDot1QVlan": group.get("clientDot1QVlan"),
            "clientDot1QInnerVlan": group.get("clientDot1QInnerVlan"),
        })
    elif serviceType == "L3-EVPN":
        l3evpn = settings.get("l3EvpnSettings", {})
        result.update({
            "circuitState": l3evpn.get("circuitState"),
            "lockCircuit": l3evpn.get("lockCircuit"),
            "dualAttachedPortChannel": l3evpn.get("dualAttachedPortChannel"),
            "otherPortChannelMember": l3evpn.get("otherPortChannelMember"),
            "routingType": group.get("routingType"),
            "ipVpnInterfaces": settings.get("ipVpnInterfaces"),
            "prefixList": settings.get("prefixList"),
            "prefixListOut": settings.get("prefixListOut"),
            "staticRoutes": settings.get("staticRoutes"),
            "vlanInterfaces": settings.get("vlanInterfaces"),
            "l3Encap": group.get("l3Encap"),
            "flexEncap": group.get("flexEncap"),
            "clientDot1QVlan": group.get("clientDot1QVlan"),
            "clientDot1QInnerVlan": group.get("clientDot1QInnerVlan"),
            "bgpPolicy": "",
        })
    elif serviceType in ("L2-EVPN", "L2-EVPN + IRB"):
        l2 = settings.get("l2EvpnWIrb", {})
        flexEncapInput = group.get("l2FlexEncap")
        cVlan = group.get("l2ClientDot1QVlan")
        cInnerVlan = group.get("l2ClientDot1QInnerVlan")
        result.update({
            "circuitState": l2.get("circuitState"),
            "lockCircuit": l2.get("lockCircuit"),
            "dualAttachedPortChannel": l2.get("dualAttachedPortChannel"),
            "otherPortChannelMember": l2.get("otherPortChannelMember"),
            "l2EvpnInterfaces": settings.get("l2EvpnInterfaces"),
            "vlan": _validateVlan(l2.get("vlanId")),
            "ipAddressVirtual": l2.get("ipAddress"),
            "ipAddressVirtualVrf": l2.get("l3Vrf"),
            "flexEncap": processFlexEncap(flexEncapInput, cVlan, cInnerVlan),
        })
    elif serviceType == "VPLS":
        vpls = settings.get("vpls", {})
        flexEncapInput = group.get("l2FlexEncap")
        cVlan = group.get("l2ClientDot1QVlan")
        cInnerVlan = group.get("l2ClientDot1QInnerVlan")
        result.update({
            "circuitState": vpls.get("circuitState"),
            "lockCircuit": vpls.get("lockCircuit"),
            "vlan": _validateVlan(vpls.get("vlan")),
            "interface": vpls.get("interface", ""),
            "subInterface": vpls.get("subInterface", ""),
            "flexEncap": processFlexEncap(flexEncapInput, cVlan, cInnerVlan),
        })
    elif serviceType == "VPWS":
        vpws = settings.get("vpws", {})
        eline = settings.get("elineInterface", {})
        flexEncapInput = group.get("l2FlexEncap")
        cVlan = group.get("l2ClientDot1QVlan")
        cInnerVlan = group.get("l2ClientDot1QInnerVlan")
        result.update({
            "circuitState": vpws.get("circuitState"),
            "lockCircuit": vpws.get("lockCircuit"),
            "dualAttachedPortChannel": vpws.get("dualAttachedPortChannel"),
            "otherPortChannelMember": vpws.get("otherPortChannelMember"),
            "interface": eline.get("interface", ""),
            "subInterface": eline.get("subInterface"),
            "flexEncap": processFlexEncap(flexEncapInput, cVlan, cInnerVlan),
        })
    return result


# =============================================================================
# Orchestrator
# =============================================================================

def processInputs():
    """Orchestrate the full provisioning workflow for a single circuit.

    Steps:
      1. Fetch circuit data from Customer Studio and current state from Configlet Studio
      2. Resolve PE router IDs (Loopback0) for route distinguisher and ESI generation
      3. Validate multi-homing configuration against PE count
      4. Clean up stale interface tags from any previous provisioning run
      5. Extract service-type-specific settings and validate constraints
      6. Generate EOS CLI configlet via the appropriate service-type builder
      7. Merge the new configlet with existing circuits on the target devices
      8. Batch-assign interface tags and push the final result to the Configlet Studio
    """
    current_datetime = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
    pendingTags = []

    # --- Step 1: Fetch inputs from both studios ---
    customerStdID, wrkID, inputPath = extractStudioInfoFromArgs(ctx.action.args)
    try:
        customerStdInputs = getStudioInputs(ctx.getApiClient, customerStdID, wrkID, [])
    except InputNotFoundException:
        customerStdInputs = {}
    circuitInfo, globalSettings = getCustomerStdInputs(inputPath, customerStdInputs)
    try:
        inputs = getStudioInputs(ctx.getApiClient, cliStdID, wrkID, [])
    except InputNotFoundException:
        inputs = {}

    # Unpack the circuit-level fields shared by all service types
    # Replace spaces with underscores — EOS vlan names don't allow spaces
    customerName = circuitInfo.get("customer", "").replace(" ", "_")
    circuitId = circuitInfo.get("circuitId")
    serviceType = circuitInfo.get("serviceType")
    # Sanitized service type for use in CLI names/descriptions (no spaces)
    serviceTypeLabel = serviceType.replace(" ", "_").replace("+", "and") if serviceType else ""
    evi = circuitInfo.get("evi")
    vrfName = circuitInfo.get("vrfName")
    multiHoming = circuitInfo.get("multiHoming")

    # --- Required field validation ---
    if not customerName:
        raise ActionFailed("Please enter a Customer Name")
    if not circuitId:
        raise ActionFailed("Please enter a Circuit/Service ID")
    if not str(circuitId).replace("-", "").replace("_", "").isalnum():
        raise ActionFailed(f"Circuit ID must be alphanumeric (hyphens and underscores allowed), got: {circuitId}")
    validServiceTypes = ("Direct Internet Access", "VPN-V4", "L3-EVPN",
                         "L2-EVPN", "L2-EVPN + IRB", "VPLS", "VPWS")
    if serviceType not in validServiceTypes:
        raise ActionFailed(f"Unknown service type: {serviceType}")
    # EVI is required for all service types that use route distinguishers
    if not evi and serviceType in ("VPN-V4", "L3-EVPN", "L2-EVPN", "L2-EVPN + IRB", "VPWS"):
        raise ActionFailed("Please enter an EVI")

    if len(circuitInfo.get("pe")) == 0:
        raise ActionFailed("Please add an Endpoint")
    tag = circuitInfo.get("pe").get("tags").get("query")

    # --- Step 2: Resolve PE loopback IPs ---
    # These are used as the left side of route distinguishers (RD) and to
    # generate deterministic ESI values for multi-homed circuits.
    deviceNameList = splitTagToDeviceNames(tag)
    devs = ctx.getDevicesByTag(Tag('router_bgp.router_id', None), inTopology=False)
    deviceMap = {dev.id: dev for dev in devs}
    pe1RouterId = ""
    pe2RouterId = ""
    deviceId = deviceNameList[0]
    if deviceId in deviceMap:
        pe1RouterId = deviceMap[deviceId].getSingleTag(ctx, 'router_bgp.router_id').value
    if len(deviceNameList) == 2:
        deviceId = deviceNameList[1]
        if deviceId in deviceMap:
            pe2RouterId = deviceMap[deviceId].getSingleTag(ctx, 'router_bgp.router_id').value

    # --- Step 3: Validate PE router IDs and multi-homing ---
    # Router ID is required for service types that use route distinguishers
    needsRouterId = serviceType in ("VPN-V4", "L3-EVPN", "L2-EVPN", "L2-EVPN + IRB", "VPWS")
    if needsRouterId and not pe1RouterId:
        raise ActionFailed(f"Router ID not found for {deviceNameList[0]}. Please add the router_bgp.router_id tag to this device.")
    if needsRouterId and len(deviceNameList) == 2 and not pe2RouterId:
        raise ActionFailed(f"Router ID not found for {deviceNameList[1]}. Please add the router_bgp.router_id tag to this device.")
    if len(deviceNameList) > 1 and multiHoming == "Single Homed":
        raise ActionFailed("Choose only 1 router if the Circuit is Single Homed")
    if len(deviceNameList) < 2 and multiHoming != "Single Homed":
        raise ActionFailed("Choose 2 routers if the Circuit is Multi Homed")

    # --- Step 4: Clean up stale interface tags ---
    # When re-provisioning, delete old tags before creating new ones.
    # Fetch all tags once and pass to each device cleanup call.
    if globalSettings.get("globallyEnableInterfaceTagging") == "Enable":
        allIntfTags = ctx.tags._getAllInterfaceTags()
        for deviceId in deviceNameList:
            clean_up_interface_tags(deviceId, circuitId, allIntfTags)
    else:
        deviceNameList = []

    # Build ESI prefix from both PE loopbacks (multi-homed only)
    paddedEsi = ""
    if multiHoming in ("Active Active Multi Homing", "Single Active Multi Homing"):
        paddedEsi = buildEsiPrefix(pe1RouterId, pe2RouterId)

    # --- Step 5: Extract and validate service-type settings ---
    svcSettings = extractServiceSettings(serviceType, circuitInfo)
    if svcSettings["lockCircuit"]:
        raise ActionFailed("This circuit is locked from being reprovisioned")
    if svcSettings.get("routingType") == "BGP" and svcSettings.get("interfaceType") == "SVI":
        raise ActionFailed("SVI is not a valid interface type for BGP routing")

    # Normalize circuit state for the configlet display metadata
    circuitState = svcSettings["circuitState"]
    if circuitState is None or circuitState is True:
        circuitState = "Enabled"
    else:
        circuitState = "Disabled"

    # Global settings: local ASN and BGP session tracking
    bgpAs = globalSettings.get("localASN")
    if not bgpAs:
        raise ActionFailed("Please set Local ASN in Global Settings")
    bgpSessionTracking = globalSettings.get("bgpSessionTracking")
    if bgpSessionTracking == "Enabled" or bgpSessionTracking is None:
        bgpSessionTrackingCLI = "bgp session tracker TRACK-EVPN-PEERS"
    else:
        bgpSessionTrackingCLI = ""

    # QoS: build service-profile, shape rate, and policer CLI if configured
    serviceLevel = circuitInfo.get("serviceLevel").get("serviceLevel")
    shapeRate = circuitInfo.get("serviceLevel").get("shapeRate")
    policerProfile = circuitInfo.get("serviceLevel").get("policerProfile")
    if bool(shapeRate) != bool(policerProfile):
        raise ActionFailed("Shape Rate and Policer Profile must both be set, or both be empty")
    qosProfile = f"service-profile USS-QOS-{serviceLevel}" if serviceLevel else ""
    if shapeRate and policerProfile:
        serviceLevelConfig = f"""{qosProfile}
    shape rate {shapeRate}
    policer profile {policerProfile} input
    !"""
    else:
        serviceLevelConfig = ""

    # --- Step 6-7: Collect existing circuits and generate new CLI ---
    # Single pass: separate non-target devices (keep as-is) from target
    # devices (collect their existing circuits, excluding the one being
    # re-provisioned, so we can merge the new CLI alongside them).
    tagList = splitTagToDeviceNames(tag)
    deviceList = []
    existingServicesDevice1 = []
    existingServicesDevice2 = []
    device1Found = False
    for existingDevice in inputs.get("devices", {}):
        deviceTag = existingDevice.get("tags", {}).get("query", "")
        deviceTag = deviceTag.strip().removeprefix('device:')
        if deviceTag in tagList:
            services = existingDevice.get("inputs", {}).get("value", {}).get("services")
            if services is not None:
                for service in services:
                    if circuitId != service.get("circuitId"):
                        if not device1Found:
                            existingServicesDevice1.append(service)
                        else:
                            existingServicesDevice2.append(service)
            device1Found = True
        else:
            deviceList.append(existingDevice)

    # Build context dict shared by all template builders
    context = {
        "customerName": customerName, "circuitId": circuitId,
        "serviceType": serviceType, "serviceTypeLabel": serviceTypeLabel,
        "evi": evi, "vrfName": vrfName,
        "multiHoming": multiHoming, "circuitState": circuitState,
        "connectionType": svcSettings["connectionType"],
        "current_datetime": current_datetime, "bgpAs": bgpAs,
        "bgpSessionTrackingCLI": bgpSessionTrackingCLI,
        "serviceLevelConfig": serviceLevelConfig,
        "paddedEsi": paddedEsi, "autoRT": "",
        "defaultOriginate": svcSettings.get("defaultOriginate", False),
        "pe1RouterId": pe1RouterId, "pe2RouterId": pe2RouterId,
        "deviceNameList": deviceNameList, "pendingTags": pendingTags,
        "device1Services": [], "device2Services": [],
        "svcSettings": svcSettings,
    }

    # Dispatch to the appropriate service-type CLI builder
    if serviceType == "Direct Internet Access":
        buildDiaCli(context)
    elif serviceType in ("VPN-V4", "L3-EVPN"):
        buildVpnV4Cli(context)
    elif serviceType in ("L2-EVPN", "L2-EVPN + IRB"):
        buildL2EvpnCli(context)
    elif serviceType == "VPLS":
        buildVplsCli(context)
    elif serviceType == "VPWS":
        buildVpwsCli(context)

    # --- Step 8: Assemble, tag, and push ---
    # Merge existing circuits with the newly generated CLI for each target device
    mergedServices = []
    index = 0
    for tag in tagList:
        index = index + 1
        if index == 1:
            mergedServices = existingServicesDevice1 + context["device1Services"]
        elif index == 2:
            mergedServices = existingServicesDevice2 + context["device2Services"]
        deviceList.append({
            "inputs": {"value": {"services": mergedServices}},
            "tags": {"query": f"device:{tag}"},
        })
    inputs = {"devices": deviceList}

    # Assign all accumulated interface tags in a single API call
    if pendingTags:
        ctx.tags._assignInterfaceTags(pendingTags)

    # Push the final device list to the Configlet Studio
    try:
        setStudioInput(ctx.getApiClient, cliStdID, wrkID, [], inputs)
    except InputUpdateException as e:
        raise ActionFailed(f"Failed to add location due to: {e}") from e


# =============================================================================
# Entry Point
# =============================================================================

def main():
    ctx.initializeStudioCtxFromArgs()
    ctx.tags._getAllDeviceTags()
    processInputs()

if __name__ == "__main__":
    main()
